/* My New Queries After 05April2019**/
ALTER TABLE `products` ADD `discount_percent` DECIMAL(3,2) NOT NULL DEFAULT '0' AFTER `regular_price`;
ALTER TABLE `products` ADD `available_for_minors` ENUM('Y','N') NOT NULL DEFAULT 'N' AFTER `product_origin`;
ALTER TABLE `products` ADD `manage_stock` ENUM('yes','no') NOT NULL DEFAULT 'yes' AFTER `price`;
ALTER TABLE `products` ADD `sale_period_mode` ENUM('yes','no') NOT NULL DEFAULT 'no' AFTER `available_for_minors`, ADD `sale_period_start_date` DATE NULL DEFAULT NULL AFTER `sale_period_mode`, ADD `sale_period_end_date` DATE NULL DEFAULT NULL AFTER `sale_period_start_date`;
ALTER TABLE `products` ADD `allow_non_bankruptible_deposit` ENUM('Y','N') NOT NULL DEFAULT 'N' AFTER `sale_period_end_date`;


 
 
 




/*This Database table we will use for Time Deal Products Data store.*/
CREATE TABLE `timedeal_products_data` (
 `id` bigint(20) NOT NULL AUTO_INCREMENT,
 `seller_id` bigint(20) NOT NULL,
 `product_id` bigint(20) NOT NULL,
 `deal_start_date_time` datetime NOT NULL,
 `deal_end_date_time` datetime NOT NULL,
 `deal_image` text CHARACTER SET utf8mb4 NOT NULL,
 `deal_discount` float(10,2) NOT NULL,
 `product_deal_price` double(20,2) NOT NULL,
 `created_at_date_time` datetime NOT NULL,
 `created_at_update_time` datetime NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1

/*Table terms has been altered successfully.*/
ALTER TABLE `terms` ADD `display_status` ENUM('all','pmgadmin') NOT NULL DEFAULT 'all' AFTER `updated_at`; 

/* New Tables Added for Register/Modify Product Government Categories.*/
CREATE TABLE `product_government_category` (
  `id` int(11) NOT NULL,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_product_type` enum('N','R','M') NOT NULL DEFAULT 'N',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
CREATE TABLE `product_government_category_rules` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `field_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_msg` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_required` enum('Y','N') NOT NULL DEFAULT 'N',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



/* Update Adv table for adding banner images for mobile screen different */

ALTER TABLE `adv_request` ADD `mobile_file_path` TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL AFTER `file_path`;
UPDATE `adv_request` SET mobile_file_path = file_path
ALTER TABLE `adv_request` CHANGE `file_path` `file_path` VARCHAR(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;
ALTER TABLE `adv_request` CHANGE `adv_content` `adv_content` TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL;
ALTER TABLE `adv_request` CHANGE `file_path` `file_path` VARCHAR(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL;


ALTER TABLE `products` CHANGE `id` `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, CHANGE `regular_price` `regular_price` DOUBLE(20,2) NULL DEFAULT NULL, CHANGE `discount_percent` `discount_percent` DECIMAL(10,2) NOT NULL DEFAULT '0.00', CHANGE `sale_price` `sale_price` DOUBLE(20,2) NULL DEFAULT NULL, CHANGE `price` `price` DOUBLE(20,2) NULL DEFAULT NULL, CHANGE `stock_availability` `stock_availability` VARCHAR(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL, CHANGE `type` `type` VARCHAR(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL;
ALTER TABLE `product_extras` CHANGE `product_extra_id` `product_extra_id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, CHANGE `product_id` `product_id` BIGINT UNSIGNED NOT NULL;
ALTER TABLE `object_relationships` CHANGE `term_id` `term_id` BIGINT UNSIGNED NOT NULL,CHANGE `object_id` `object_id` BIGINT UNSIGNED NOT NULL;
ALTER TABLE `products` ADD `product_point_on_sale` DOUBLE NOT NULL AFTER `price`;
ALTER TABLE `products` CHANGE `stock_qty` `stock_qty` DOUBLE UNSIGNED NOT NULL;
ALTER TABLE `products` ADD `stock_qty_default` DOUBLE NOT NULL AFTER `stock_qty`;
ALTER TABLE `products` ADD `txtProductDescriptionText` TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL AFTER `allow_non_bankruptible_deposit`;
ALTER TABLE `products` CHANGE `status` `status` INT(10) UNSIGNED NOT NULL COMMENT '1:Active, 0:Inactive or deleted';
ALTER TABLE `terms` ADD `intPosition` INT NOT NULL AFTER `display_status`;


##category_icon_images folder in public ko permision dena hai live server par.
UPDATE `terms` SET author_id=1
ALTER TABLE `terms` ADD `category_price_type` ENUM('fixed','percent') NOT NULL DEFAULT 'fixed' AFTER `intPosition`, ADD `category_price` DOUBLE(20,2) NOT NULL DEFAULT '0.00' AFTER `category_price_type`;
CREATE TABLE `categories_rating` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `category_id` int(10) NOT NULL DEFAULT '0',
 `total_sales_quantity` double NOT NULL,
 `total_sales_amount` double(20,2) NOT NULL,
 `created_at` timestamp NULL DEFAULT NULL,
 `updated_at` timestamp NULL DEFAULT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  
ALTER TABLE `user_1_1_consultation_inquiry_data` ADD `txtSelectedFieldLabel` VARCHAR(255) NOT NULL AFTER `varAnswerStatus`;
ALTER TABLE `users` ADD `reason_for_ban_account` TEXT NOT NULL AFTER `vendor_type`;
ALTER TABLE `products` ADD `seller_product_code` VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL AFTER `txtProductDescriptionText`;


CREATE TABLE `user_action_logs` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `action_id` varchar(1000) NOT NULL,
 `action_source` varchar(200) NOT NULL,
 `action_status` varchar(20) NOT NULL,
 `affected_columns` text,
 `action_time` datetime NOT NULL,
 `action_by` int(11) NOT NULL,
 `action_type` varchar(100) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1
 
CREATE TABLE `consultation_request` (
 `bintApplicationId` bigint(20) NOT NULL AUTO_INCREMENT,
 `bintApplicantUserId` bigint(20) NOT NULL,
 `varAvailablePhoneNumber` varchar(20) NOT NULL,
 `varConsultationRequestTime` varchar(255) NOT NULL,
 `varProductColorName` varchar(255) NOT NULL,
 `bintProductId` bigint(20) NOT NULL,
 `created_at` datetime NOT NULL,
 `updated_at` datetime NOT NULL,
 PRIMARY KEY (`bintApplicationId`)
) ENGINE=InnoDB AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8

 
CREATE TABLE `user_1_1_consultation_inquiry_data` (
 `bintInquiryId` bigint(20) NOT NULL AUTO_INCREMENT,
 `bintLoggedInUserId` bigint(20) NOT NULL,
 `txtInquiryTitle` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
 `txtInquiryContent` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
 `varMobilePhoneNumber` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
 `varEmailAddress` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
 `txtContentsFileUrl` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
 `txtUserFieldOfInquiry` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
 `varAnswerStatus` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
 `created_at` datetime NOT NULL,
 `updated_at` datetime NOT NULL,
 PRIMARY KEY (`bintInquiryId`)
) ENGINE=InnoDB AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8
 

CREATE TABLE `faq_search_table` (
 `bintId` bigint(20) NOT NULL AUTO_INCREMENT,
 `varInquiryType` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
 `txtFaqTitle` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
 `txtFaqDescription` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
 `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 `updated_at` timestamp NULL DEFAULT NULL,
 PRIMARY KEY (`bintId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1

CREATE TABLE `refund_account` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `user_id` int(11) NOT NULL,
 `account_holder` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
 `account_number` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
 `bank_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
 `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
 PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1
 

/*New Updates After 27-FEB-2019 For Add Product Page functionality*/
ALTER TABLE `products` ADD `content_mobile` LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL AFTER `content`;
ALTER TABLE `products` ADD `product_sale_mode` VARCHAR(255) NOT NULL AFTER `image_url`, ADD `product_condition_status` VARCHAR(255) NOT NULL AFTER `product_sale_mode`, ADD `product_tax` VARCHAR(255) NOT NULL AFTER `product_condition_status`, ADD `product_model_name` VARCHAR(600) NOT NULL AFTER `product_tax`, ADD `product_manufacturer` VARCHAR(600) NOT NULL AFTER `product_model_name`, ADD `product_origin` VARCHAR(255) NOT NULL AFTER `product_manufacturer`;


ALTER TABLE `terms` ADD `author_id` INT(10) NOT NULL DEFAULT '0' AFTER `term_id`;

