<table>
	<tr>
		<td>Name</td>
		<td>School</td>
	</tr>
</table>