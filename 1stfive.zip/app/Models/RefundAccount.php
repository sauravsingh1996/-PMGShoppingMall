<?php
namespace shopist\Models;

use Illuminate\Database\Eloquent\Model;

class RefundAccount extends Model
{
  protected $table = 'refund_account';
  protected $guarded = ['id']; 
}
