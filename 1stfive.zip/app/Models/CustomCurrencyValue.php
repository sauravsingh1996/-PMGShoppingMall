<?php

namespace shopist\Models;

use Illuminate\Database\Eloquent\Model;

class CustomCurrencyValue extends Model
{
  protected $table = 'custom_currency_values';
}
