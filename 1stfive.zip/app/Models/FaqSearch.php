<?php

namespace shopist\Models;

use Illuminate\Database\Eloquent\Model;

class FaqSearch extends Model
{
  protected $table = 'faq_search_table';
  protected $guarded = ['bintId'];
	protected $primaryKey = 'bintId';  
}
