<?php
namespace shopist\Models;

use Illuminate\Database\Eloquent\Model;

class VendorWithdraw extends Model
{
  protected $table = 'vendor_withdraws';
}
