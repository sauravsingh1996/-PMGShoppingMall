<?php
namespace shopist\Models;

use Illuminate\Database\Eloquent\Model;

class UserRecentActivity extends Model
{
  protected $table = 'user_recent_activity';
}
