<?php
namespace shopist\Models;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Input;
use Validator;
use Request;
use Session;

use Intervention\Image\Facades\Image;
use Illuminate\Http\File;
use Illuminate\Support\Facades\Storage;
/*use Illuminate\Support\Facades\Lang;
use shopist\Models\ManageLanguage;
use shopist\Library\CommonFunction;
use shopist\Models\UserRolePermission;
use shopist\Http\Controllers\OptionController;
use shopist\Library\GetFunction;
use Illuminate\Support\Facades\App;
use shopist\Models\Consultation;
use Illuminate\Support\Facades\URL;*/
class Consultation extends Model
{
	/**
     * The table associated with the model.
     * Eloquent will assume the Consultation model stores records in the consultation table. 
     * You may specify a custom table by defining a table property on your model:
     * @var string
     */
	protected $table = 'consultation_request';

	
	/**
     * IndicatesPrimary Keys
     * Eloquent will also assume that each table has a primary key column named id. 
     * You may define a protected $primaryKey property to override this convention.
     * @var bool
     */
    protected $primaryKey = 'bintApplicationId';

	/**
     * Indicates if the model should be timestamped.
     * By default, Eloquent expects created_at and updated_at columns to exist on your tables. 
     * If you do not wish to have these columns automatically managed by Eloquent,
     * set the $timestamps property on your model to false:
     * @var bool
     */
    //public $timestamps = false;

    /**
     * The attributes that are not mass assignable or updatebale from http request on create or insert or update.
     *
     * @var array
     */
     protected $guarded = ['bintApplicationId']; 
	

 /**
   * 
   * Function to fetch rental product and consultations request data from consultation_request table.
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Last Updated: 06 Feb 2019
   * @param null
   * @return Array
   */
	public function getConsultaionProductData($applicationId = 0)
	{
		// Query to fetch consulation request data.
		$consultationRequestDataQuery = DB::table('consultation_request AS CR')
			->join('products AS P', 'P.id', '=', 'CR.bintProductId')
			->join('users AS U', 'U.id', '=', 'CR.bintApplicantUserId')
			->select('U.display_name','P.id', 'P.title', 'P.image_url', 'P.content', 'P.slug','CR.bintApplicationId', 'CR.varAvailablePhoneNumber', 'CR.varConsultationRequestTime', 'CR.varProductColorName', 'CR.updated_at')
			->orderBy('bintApplicationId', 'ASC');
			
		// If you get $applicationId == 'all', do this, otherwise else.
		if ($applicationId == 'all') 
		{
			// Return all consulation request data.  
			return $consultationRequestDataQuery->where([['P.status', '=', '1']])->get();
		} else
		{
			// Return consulation request data.  
			return $consultationRequestDataQuery->where([['P.status', '=', '1'],['CR.bintApplicationId', '=', $applicationId]])->first();
		}
	}
  
  /**
   * 
   * Function to fetch one to one consultation inquiry data for users from user_1_1_consultation_inquiry_data table.
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Last Updated: 13 Feb 2019
   * @param null
   * @return Array
   */
	public function getOneToOneConsultaionRequestData($callType='', $requestId = 0)
	{
		// Getting logged in User Id.
		$loggedInUserId = (Session::has('shopist_frontend_user_id')) ? Session::get('shopist_frontend_user_id') : 0;
 
		// Query to fetch one to one consultation inquiry request data.
		$consultationRequestDataQuery = DB::table('user_1_1_consultation_inquiry_data AS CR');

		if ($requestId > 0){
			$consultationRequestDataQuery = $consultationRequestDataQuery->where(['CR.bintInquiryId'=>$requestId]);
		}

		$consultationRequestDataQuery->select('CR.bintInquiryId','CR.bintLoggedInUserId', 'CR.txtInquiryTitle', 'CR.txtInquiryContent', 'CR.varMobilePhoneNumber', 'CR.varEmailAddress', 'CR.txtContentsFileUrl', 'CR.txtUserFieldOfInquiry', 'CR.varAnswerStatus', 'CR.txtSelectedFieldLabel','CR.txtAdminResponse', 'CR.created_at')
			->orderBy('bintInquiryId', 'ASC');
		
		if ($callType == 'recent')	{
			$consultationRequestDataQuery->latest()->limit(3);
		}
 
		// Return all consulation request data for logged in user.  
		return $consultationRequestDataQuery->where([['CR.bintLoggedInUserId', '=', $loggedInUserId]])->get()->toArray();
	}

  /**
   * 
   * Function to save 1:1 consultation inquiry page data into consulation request data
   * In user_1_1_consultation_inquiry_data table.
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Last Updated: 12 Feb 2019
   * @param null
   * @return Status String
   */
	public function saveOneToOneConsultaionInquiryPageData( )
	{
	    // Getting logged in User Id.
		$loggedInUserId = (Session::has('shopist_frontend_user_id')) ? Session::get('shopist_frontend_user_id') : 0;

	    // Getting post form data.
		$consultation_field_of_inquiry = trim(Input::get('consultation_field_of_inquiry'));   
		$user_order_payment_type = trim(Input::get('user_order_payment_type'));   
		$user_delivery_type = trim(Input::get('user_delivery_type'));   
		$user_order_cancel_refund_type = trim(Input::get('user_order_cancel_refund_type'));   
		$user_service_other_type = trim(Input::get('user_service_other_type'));   
		$inquiry_title = trim(Input::get('inquiry_title'));   
		$inquiry_content = trim(Input::get('inquiry_content'));   
		$inquiry_email_address = trim(Input::get('inquiry_email_address'));   
		$inquiry_mobile_phone_number = trim(Input::get('inquiry_mobile_phone_number'));    
		$inquiry_contents_file = trim(Input::get('inquiry_contents_file'));    
		$selectedFieldLabel = trim(Input::get('selectedFieldLabel'));    
  
	    $inquiryId = 0;
	  
	    // Storing Inquery Field Type values Json Array to store in DB.
		$picturesAttachment='';
		if(Input::file('inquiry_contents_file'))
		{

			// Tell the validator that this file should be an image
		    $rules = array(
		      'inquiry_contents_file' => 'mimes:jpeg,jpg,png,gif|required|max:10000' // max 10000kb
		    );
		    
		    // Getting all input data
	  		$data = Input::all();
	  		
	  		// Now pass the input and rules into the validator
			$validator = Validator::make($data, $rules);
			 
		    // Check to see if validation fails or passes
		    if ($validator->fails())
		    {
 		        // Return 1:1 Consultation Inquiry Id.
				return $inquiryId; 
		    } else
		    {
				$image = Input::file('inquiry_contents_file');
				$fileName = time()."-"."h-400-".$image->getClientOriginalName();
				$height = 400;
				$img   = Image::make($image);

				$folderPath = 'attachment/1_1_consultation_pictures/'.$loggedInUserId.'/';
				$targetPath = public_path().'/'.$folderPath;
				
				//Create Directory
				createDirectoroy($targetPath);

				if ($img->save($targetPath. $fileName)) 
				{
					$picturesAttachment= $folderPath . $fileName;
				}   
			}
		}
			 
		// Query to insert 1:1 consultation inquiry page into user_1_1_consultation_inquiry_data table.
		$inquiryId = DB::table('user_1_1_consultation_inquiry_data')->insertGetId(
			[
				'bintLoggedInUserId' => $loggedInUserId,
				'txtInquiryTitle' => $inquiry_title,
				'txtInquiryContent' => $inquiry_content,
				'varMobilePhoneNumber' => $inquiry_mobile_phone_number,
				'varEmailAddress' => $inquiry_email_address,
				'txtContentsFileUrl' => $picturesAttachment,
				'varEmailAddress' => $inquiry_email_address,
				'txtUserFieldOfInquiry' => $consultation_field_of_inquiry,
				'varAnswerStatus' => 'waiting',
				'txtSelectedFieldLabel' => $selectedFieldLabel,
				'created_at' => date('Y-m-d h:i:s'),
				'updated_at' => date('Y-m-d h:i:s')
			],'bintInquiryId');
		 

		// Return 1:1 Consultation Inquiry Id.
		return $inquiryId;
	}


  /**
   * 
   * Get admin one to one consultation list view page data 
   *
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Created On : 13 May 2019
   * 
   * @param pagination required. Boolean type TRUE or FALSE, by default false
   * @param search value optional
   * @param status flag by default -1. -1 for all data, 1 for status enable and 0 for disable status
   * @return array
   */
  
  public function getAdminOneToOneCosultaionDataData($pagination = false, $search_val = null, $perPage=5, $orderBy='',$filterType='', $callType='')
  {
  	$where = '';

  	$perPage = ($perPage > 30) ? 30 :$perPage;

  	if($filterType != '')
  	{
  		$where = ['txtUserFieldOfInquiry' => $filterType];
  	}

    // Query to fetch all one to one consultation inquiry request data.
  	if(!empty($search_val))
  	{
		// Query to fetch consultation request data.
  		$get_consultation = DB::table('user_1_1_consultation_inquiry_data')
  		->where(function($q) use ($search_val) {
  			$q->where('txtInquiryTitle', 'LIKE', '%'. $search_val .'%');
  			$q->orWhere('varAnswerStatus', 'LIKE', '%'. $search_val .'%');
  		});
  	} else
  	{
       	// Query to fetch consultation request data.
  		$get_consultation = DB::table('user_1_1_consultation_inquiry_data');
  	}

  	if (!empty($where)){
  		$get_consultation = 	$get_consultation->where($where);
  	} 

  	if ($orderBy =='recent'){
  		$get_consultation = 	$get_consultation->orderBy('bintInquiryId', 'DESC');
  	}else{
  		$get_consultation = 	$get_consultation->orderBy('bintInquiryId', 'ASC');
  	}

  	$get_consultation = $get_consultation->select('bintInquiryId','bintLoggedInUserId', 'txtInquiryTitle', 'txtInquiryContent', 'varMobilePhoneNumber', 'varEmailAddress', 'txtContentsFileUrl', 'txtUserFieldOfInquiry', 'varAnswerStatus', 'txtSelectedFieldLabel','txtAdminResponse', 'created_at');
  	if ($callType=='export'){
  		$get_consultation_data =  $get_consultation->get()->toArray();
  	} else
  	{
  		$get_consultation_data =  $get_consultation->paginate($perPage)->toArray();
  	}
  	return $get_consultation_data;
  }

  /**
   * 
   * Save PMG master admin's one to one consultation respose data. 
   *
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Created On : 13 May 2019
   * 
   * @param pagination required. Boolean type TRUE or FALSE, by default false
   * @param search value optional
   * @param status flag by default -1. -1 for all data, 1 for status enable and 0 for disable status
   * @return array
   */
  
  public function saveOneToOneConsultationReply($consultationId=0, $userInquiryResponse='')
  {
  	$actionStatus = 0;
  	if ($consultationId > 0 && $userInquiryResponse !='')
	{
		// Query to save admin reply on user's 1:1 consultation request data.
  		$data = array(
  			'txtAdminResponse'   =>  $userInquiryResponse,
  			'varAnswerStatus'   =>  'answer_complete',
  			'updated_at'   =>  date('Y-m-d h:i:s')
  		);

  		if(DB::table('user_1_1_consultation_inquiry_data')->where('bintInquiryId', $consultationId)->where('varAnswerStatus', 'waiting')->update($data))
  		{
  			$actionStatus = 1;
  		}  
  	}
  	return $actionStatus;
  }

}
 