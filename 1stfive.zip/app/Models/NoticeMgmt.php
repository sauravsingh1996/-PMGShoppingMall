<?php

namespace shopist\Models;

use Illuminate\Database\Eloquent\Model;

class NoticeMgmt extends Model
{
  protected $table = 'notice_management';
  protected $guarded = ['id']; 
}