<?php

namespace shopist\Models;

use Illuminate\Database\Eloquent\Model;

class VendorOrder extends Model
{
  protected $table = 'vendor_orders';
}
