<?php
namespace shopist\Models;

use Illuminate\Database\Eloquent\Model;

class ObjectRelationship extends Model
{
  protected $table = 'object_relationships';
}
