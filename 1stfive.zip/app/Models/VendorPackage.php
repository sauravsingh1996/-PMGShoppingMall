<?php
namespace shopist\Models;

use Illuminate\Database\Eloquent\Model;

class VendorPackage extends Model
{
  protected $table = 'vendor_packages';
}
