<?php
namespace shopist\Models;

use Illuminate\Database\Eloquent\Model;

class IntruptedUser extends Model
{
  protected $table = 'intrupted_user';
  protected $guarded = ['id']; 
}
