<?php
namespace shopist\Models;

use Illuminate\Database\Eloquent\Model;

class UserActionLogs extends Model
{
  protected $table = 'user_action_logs';
}
