<?php
namespace shopist\Models;

use Illuminate\Database\Eloquent\Model;

class AdvRequest extends Model
{
  protected $table = 'adv_request';
  protected $guarded = ['id']; 
}
