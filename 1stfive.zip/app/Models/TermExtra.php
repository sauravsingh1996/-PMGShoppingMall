<?php
namespace shopist\Models;

use Illuminate\Database\Eloquent\Model;

class TermExtra extends Model
{
  protected $table = 'term_extras';
}
