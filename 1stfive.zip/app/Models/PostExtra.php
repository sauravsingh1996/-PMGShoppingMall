<?php
namespace shopist\Models;

use Illuminate\Database\Eloquent\Model;

class PostExtra extends Model
{
   
  protected $table = 'post_extras';
}
