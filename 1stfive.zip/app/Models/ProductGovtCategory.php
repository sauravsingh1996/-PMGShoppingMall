<?php

namespace shopist\Models;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

class ProductGovtCategory extends Model
{
    protected $table = 'product_government_category';

     
  /**
   * 
   * Function for getting all government categorie field by category id.
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Last Updated: 08 April 2019
   * @param null
   * @return Array
   */
	public function getGovtCategorieFieldByCatId($govtCatId = 0)
	{
		// Query to fetch government categorie field data.
		$getGovtCategoryFieldsDataQuery = DB::table('product_government_category AS GC')
			->join('product_government_category_rules AS GCR', 'GCR.category_id', '=', 'GC.id')
		    ->select('GCR.id','GCR.category_id', 'GCR.field_name', 'GCR.field_msg', 'GCR.is_required')
			->orderBy('GCR.id', 'ASC');
			
		// Return government categorie field data.  
		return $getGovtCategoryFieldsDataQuery->where([['GC.id', '=', $govtCatId]])->get();
	}
}
