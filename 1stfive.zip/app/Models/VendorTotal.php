<?php

namespace shopist\Models;

use Illuminate\Database\Eloquent\Model;

class VendorTotal extends Model
{
  protected $table = 'vendor_totals';
}
