<?php
namespace shopist\Models;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Input;
use Validator;
use Request;
use Session;
 

class CategoryRating extends Model
{
    
	protected $table = 'categories_rating';
	protected $guarded = ['id']; 

}
