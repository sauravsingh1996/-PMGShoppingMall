<?php
namespace shopist\Models;

use Illuminate\Database\Eloquent\Model;

class UserRolePermission extends Model
{
  protected $table = 'user_role_permissions';
}
