<?php
namespace shopist\Models;

use Illuminate\Database\Eloquent\Model;

class SupportTicket extends Model
{
  protected $table = 'support_ticket';
  protected $guarded = ['id']; 
}
