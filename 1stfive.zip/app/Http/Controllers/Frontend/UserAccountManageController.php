<?php
namespace shopist\Http\Controllers\Frontend;

use shopist\Http\Controllers\Controller;
use Request;
use Hash;
use shopist\Models\User;
use Illuminate\Support\Facades\DB;
use shopist\Library\CommonFunction;
use Illuminate\Support\Facades\Lang;
use Validator;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Input;
use Intervention\Image\Facades\Image;
use shopist\Models\Post;
use shopist\Models\PostExtra;
use shopist\Models\OrdersItem;
use shopist\Http\Controllers\ProductsController;
use shopist\Models\UserShippingAddress;
use shopist\Models\WishList;
use shopist\Models\UserRecentActivity;
use shopist\Models\SupportTicket;
use shopist\Models\RefundAccount;
use Carbon\Carbon;
use shopist\Models\Consultation;
use Jenssegers\Agent\Agent;

class UserAccountManageController extends Controller
{
  public $classCommonFunction;
  public $carbonObject;
  public $product;

  public function __construct(){ 
    $this->classCommonFunction  =  new CommonFunction();
    $this->carbonObject         =  new Carbon();
	$this->product              =  new ProductsController();
	
  }
  
  /**
   * 
   * User account page content
   *
   * @param null
   * @return null
   */
  public function userAccountPageContent(){
    $data = array();
    
    $dashboard_total['total_order']   = 0;
    $dashboard_total['todays_order']  = 0;
    $dashboard_total['recent_coupon'] = 0;

    $get_current_user_id = get_current_frontend_user_info();
	

    if(!empty($get_current_user_id) && count($get_current_user_id) > 0){
      $total_order  = Post::where(['post_author_id' => $get_current_user_id['user_id'], 'post_type' => 'shop_order'])->get()->toArray();
      $todays_order = Post::whereDate('created_at', '=', $this->carbonObject->today()->toDateString())->where(['post_author_id' => $get_current_user_id['user_id'], 'post_type' => 'shop_order'])->get()->toArray();
      $recent_coupon = PostExtra::where(['key_name' => '_coupon_allow_role_name', 'key_value' => $get_current_user_id['user_role_slug']])->get()->toArray();

      $dashboard_total['total_order']   = count($total_order);
      $dashboard_total['todays_order']  = count($todays_order);
      $dashboard_total['recent_coupon'] = count($recent_coupon);  
    }
    $get_data_by_user_id = get_user_account_details_by_user_id( $get_current_user_id['user_id'] );
    $get_array_shift_data = array_shift($get_data_by_user_id);
	$product_review = DB::table('order_detail')
					->where('comments.user_id', Session::get('shopist_frontend_user_id'))
					->join('orders', 'orders.id', '=', 'order_detail.order_id')
					->leftjoin('comments', 'comments.order_id', '=', 'order_detail.id')
                    ->orderBy('order_detail.id', 'desc')
                    ->select('order_detail.product_detail', 'comments.*')
					->take(3)
                    ->get()->toArray();
	
    $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
	
	//Query to get  Cancel Return data.
	$get_return_cancel_data = DB::table('order_detail')
			->where('orders.user_id', Session::get('shopist_frontend_user_id'))
			->whereIn('order_detail.status', ['ReturnRequest','ReturnCollection','ReturnRefundProgress','ReturnRefundFailed','ReturnComplete','CancelRequest','CancelProcessing','CancelFailed','CancelComplete'])
			->join('orders', 'orders.id', '=', 'order_detail.order_id')
			->leftjoin('comments', 'comments.order_id', '=', 'order_detail.id')
			->orderBy('order_detail.id', 'desc')
			->select('order_detail.product_detail','order_detail.order_id','order_detail.created_at as order_date')
			->take(3)
			->get()->toArray();
	
	$data['return_cancel_data'] = $get_return_cancel_data;
	$data['product_review']  = $product_review;
    $data['dashboard_data'] =  $dashboard_total;
    $data['login_user_details'] =  get_current_frontend_user_info();
	$data['frontend_account_details'] = WishList::join('products', 'products.id', '=', 'wish_list.product_id')->where( ['user_id' => $get_current_user_id['user_id']] )->where( ['products.status' => 1] )->where('products.stock_availability','!=','hidden' )->orderBy('wish_list.created_at', 'DESC')->get()->toArray();
    $data['WaitDepositCount']=$this->getOrderCount(Session::get('shopist_frontend_user_id'),'WaitDeposit');
	$data['DepositCount']=$this->getOrderCount(Session::get('shopist_frontend_user_id'),'Deposit');
	$data['PreparedCount']=$this->getOrderCount(Session::get('shopist_frontend_user_id'),'Prepared');
	$data['ShippedCount']=$this->getOrderCount(Session::get('shopist_frontend_user_id'),'Shipped');
	$data['DeliveredCount']=$this->getOrderCount(Session::get('shopist_frontend_user_id'),'Delivered');
    // Loading instance of Consultation Model.
    $Consultation = new Consultation;
    
    // Calling this function to get recent 3 one to one consultaion request(s) data for logged in user.  
    $data['recentOneToOneConsultationRequestData'] =  $Consultation->getOneToOneConsultaionRequestData('recent');
	
	
    
    return view('pages.frontend.user-account.user-account-pages', $data);
  }

  /**
   * Function for getting user all consulation request data front end.
   * 
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Created On : 12-Feb-2019  
   *
   * @return array
   */
  public function userOneToOneConsultationPageContent()
  {
    
    $data = array();
    
    $dashboard_total['total_order']   = 0;
    $dashboard_total['todays_order']  = 0;
    $dashboard_total['recent_coupon'] = 0;

    $get_current_user_id = get_current_frontend_user_info();

    if(!empty($get_current_user_id) && count($get_current_user_id) > 0){
      $total_order  = Post::where(['post_author_id' => $get_current_user_id['user_id'], 'post_type' => 'shop_order'])->get()->toArray();
      $todays_order = Post::whereDate('created_at', '=', $this->carbonObject->today()->toDateString())->where(['post_author_id' => $get_current_user_id['user_id'], 'post_type' => 'shop_order'])->get()->toArray();
      $recent_coupon = PostExtra::where(['key_name' => '_coupon_allow_role_name', 'key_value' => $get_current_user_id['user_role_slug']])->get()->toArray();

      $dashboard_total['total_order']   = count($total_order);
      $dashboard_total['todays_order']  = count($todays_order);
      $dashboard_total['recent_coupon'] = count($recent_coupon);  
    }
    
    $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
    $data['dashboard_data'] =  $dashboard_total; 
    $data['login_user_details'] =  get_current_frontend_user_info();
   
    // Loading instance of Consultation Model.
    $Consultation = new Consultation;
    
    // Calling this function to get all one to one consultaion request(s) data for logged in user.  
    $data['oneToOneConsultationRequestData'] =  $Consultation->getOneToOneConsultaionRequestData();

    return view('pages.frontend.user-account.user-account-pages', $data);
  }

  /**
   * Function for getting user consulation request data by request id
   * 
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Created On : 11-May-2019
   *
   * @return array
   */
  public function getUserOneToOneConsultationRequestData()
  {
  	$consultationRequestData = array();
    if( Request::isMethod('post') && Session::token() == Input::get('_token') )
    {
    	// Getting input data.
    	$requestId = (Input::has('requestId') && is_numeric(Input::get('requestId'))) ? Input::get('requestId') : 0;

    	// Loading instance of Consultation Model.
   		$Consultation = new Consultation;
    
    	// Calling this function to get all one to one consultaion request(s) data for logged in user.  
    	$consultationRequestData =  $Consultation->getOneToOneConsultaionRequestData('', $requestId);
    	/*if(!empty($consultationRequestData))
    	{
    		foreach ($consultationRequestData as $row) 
    		{
    			$selectedFieldLabel = (!empty($row->txtSelectedFieldLabel))?$row->txtSelectedFieldLabel : '';
    			if ($selectedFieldLabel !=''){
    				$row->selectedFieldLabel = trans('frontend.lable_1_1_consultation_'.$selectedFieldLabel);
    				echo $row->selectedFieldLabel ;
    			}
    			
    		}
    	}*/

    }
     
    //print_r(addslashes(json_encode($consultationRequestData)));
    print_r(json_encode($consultationRequestData));
  }
  
  /**
   * 
   * User account address add/edit page content
   *
   * @param null
   * @return null
   */
  public function userAccountAddressPageContent(){
    $data = array();
	$days =7;
	$start_date = '';
	$end_date = date("Y.m.d", strtotime("+1 day"));
	$endDate = date("Y.m.d");
	
	if(isset($_GET['day']))
	{
		$days = $_GET['day'];
		$start_date = date("Y.m.d", strtotime("-$days day"));
	}
	
	 if(isset($_POST['start_date'])){
		 $start_date = $_POST['start_date'];
		 $days = '';
	 }
	 if(isset($_POST['end_date'])){
		 $end_date = $_POST['end_date'];
		 $endDate = $end_date;
	 }
 
    $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
    $get_current_user_id = get_current_frontend_user_info();
    $get_data_by_user_id = get_user_account_details_by_user_id( $get_current_user_id['user_id'] );
    $get_array_shift_data = array_shift($get_data_by_user_id);
	$data['frontend_account_address'] = UserShippingAddress::where( ['user_id' => $get_current_user_id['user_id']] )->orderBy('mark_default', 'DESC')->get()->toArray();

    $data['frontend_account_details'] = WishList::join('products', 'products.id', '=', 'wish_list.product_id')->where( ['user_id' => $get_current_user_id['user_id']] )->where( ['products.status' => 1] )->where('products.stock_availability','!=','hidden' )->orderBy('wish_list.created_at', 'DESC')->get()->toArray();
	
    $data['login_user_details'] =  get_current_frontend_user_info();
	
	if(isset($start_date) &&  !empty($start_date) && isset($end_date) && !empty($end_date)){
		$get_cancel_status_data = DB::table('order_detail')
			->where('orders.user_id', Session::get('shopist_frontend_user_id'))
			->whereIn('order_detail.status', ['CancelRequest','CancelProcessing','CancelFailed','CancelComplete'])
			->whereBetween('order_detail.created_at', [$start_date, $end_date])
			->join('orders', 'orders.id', '=', 'order_detail.order_id')
			->leftjoin('comments', 'comments.order_id', '=', 'order_detail.id')
			->orderBy('order_detail.id', 'desc')
			->select('order_detail.*', 'orders.*', 'comments.id as review_id', 'order_detail.id as sub_order_id')
			->get()->toArray();
			
		$get_exchange_status_data = DB::table('order_detail')
			->where('orders.user_id', Session::get('shopist_frontend_user_id'))
			->whereIn('order_detail.status', ['ExchangeRequest','ExchangeCollection','ExchangeCollectionComplete','ExchangeRedeployement','ExchangeComplete'])
			->whereBetween('order_detail.created_at', [$start_date, $end_date])
			->join('orders', 'orders.id', '=', 'order_detail.order_id')
			->leftjoin('comments', 'comments.order_id', '=', 'order_detail.id')
			->orderBy('order_detail.id', 'desc')
			->select('order_detail.*', 'orders.*', 'comments.id as review_id', 'order_detail.id as sub_order_id')
			->get()->toArray();
			
		$get_return_status_data = DB::table('order_detail')
			->where('orders.user_id', Session::get('shopist_frontend_user_id'))
			->whereIn('order_detail.status', ['ReturnRequest','ReturnCollection','ReturnRefundProgress','ReturnRefundFailed','ReturnComplete'])
			->whereBetween('order_detail.created_at', [$start_date, $end_date])
			->join('orders', 'orders.id', '=', 'order_detail.order_id')
			->leftjoin('comments', 'comments.order_id', '=', 'order_detail.id')
			->orderBy('order_detail.id', 'desc')
			->select('order_detail.*', 'orders.*', 'comments.id as review_id', 'order_detail.id as sub_order_id')
			->get()->toArray();
	}
	else
	{
		$get_cancel_status_data = DB::table('order_detail')
			->where('orders.user_id', Session::get('shopist_frontend_user_id'))
			->whereIn('order_detail.status', ['CancelRequest','CancelProcessing','CancelFailed','CancelComplete'])
			->join('orders', 'orders.id', '=', 'order_detail.order_id')
			->leftjoin('comments', 'comments.order_id', '=', 'order_detail.id')
			->orderBy('order_detail.id', 'desc')
			->select('order_detail.*', 'orders.*', 'comments.id as review_id', 'order_detail.id as sub_order_id')
			->get()->toArray();
		
		$get_exchange_status_data = DB::table('order_detail')
			->where('orders.user_id', Session::get('shopist_frontend_user_id'))
			->whereIn('order_detail.status', ['ExchangeRequest','ExchangeCollection','ExchangeCollectionComplete','ExchangeRedeployement','ExchangeComplete'])
			->join('orders', 'orders.id', '=', 'order_detail.order_id')
			->leftjoin('comments', 'comments.order_id', '=', 'order_detail.id')
			->orderBy('order_detail.id', 'desc')
			->select('order_detail.*', 'orders.*', 'comments.id as review_id', 'order_detail.id as sub_order_id')
			->get()->toArray();
		
		$get_return_status_data = DB::table('order_detail')
			->where('orders.user_id', Session::get('shopist_frontend_user_id'))
			->whereIn('order_detail.status', ['ReturnRequest','ReturnCollection','ReturnRefundProgress','ReturnRefundFailed','ReturnComplete'])
			->join('orders', 'orders.id', '=', 'order_detail.order_id')
			->leftjoin('comments', 'comments.order_id', '=', 'order_detail.id')
			->orderBy('order_detail.id', 'desc')
			->select('order_detail.*', 'orders.*', 'comments.id as review_id', 'order_detail.id as sub_order_id')
			->get()->toArray();
		}
		
	$data['return_data'] = $get_return_status_data;
	$data['exchange_data'] = $get_exchange_status_data;
	$data['cancel_data'] = $get_cancel_status_data;
	$data['days'] = $days;
	$data['start_date']= $start_date;
	$data['end_date']= $endDate;
    
	//echo '<pre>'; print_r($data);exit;
    return view('pages.frontend.user-account.user-account-pages', $data);
  }
  
  /**
   * 
   * User account orders page content
   *
   * @param null
   * @return null
   */
  public function userAccountOrdersPageContent(){
    $data = array();
	$PageType ='';
	$condition_array = array();
	$days =15;
	$start_date = '';
	$end_date = date("Y.m.d", strtotime("+1 day"));
	$endDate = date("Y.m.d");
	$status_type = '';
	$condition_array = array('orders.user_id' => Session::get('shopist_frontend_user_id'));
	if(isset($_GET['type']))
	{
		$PageType=$_GET['type'];
	}
	if(isset($_GET['day']))
	{
		$days = $_GET['day'];
		$start_date = date("Y.m.d", strtotime("-$days day"));
	}
	 if(isset($_POST['start_date'])){
		 $start_date = $_POST['start_date'];
		 $days = '';
	 }
	 if(isset($_POST['end_date'])){
		 $end_date = $_POST['end_date'];
		 $endDate = $end_date;
	 }
	 if(isset($_POST['status_type']) && $_POST['status_type'] != 'all'){
		 $status_type= $_POST['status_type'];
		 $condition_array+= array('order_detail.status' => $_POST['status_type']);
		 $days = '';
	 }
	 
    $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
    $data['orders_list_data'] = array();
	
	if(isset($_GET['id'])){
		$id = $_GET['id'];
		$get_order_data = DB::table('order_detail')
			->where('orders.user_id', Session::get('shopist_frontend_user_id'))
			->where('orders.id', $id)
			->join('orders', 'orders.id', '=', 'order_detail.order_id')
			->leftjoin('comments', 'comments.order_id', '=', 'order_detail.id')
			->orderBy('order_detail.id', 'desc')
			->select('order_detail.*', 'orders.*', 'comments.id as review_id', 'order_detail.id as sub_order_id')
			->get()->toArray();
	}else{
		if(isset($start_date) &&  !empty($start_date) && isset($end_date) && !empty($end_date)){
			$get_order_data = DB::table('order_detail')
			->where($condition_array)
			->whereBetween('order_detail.created_at', [$start_date, $end_date])
			->join('orders', 'orders.id', '=', 'order_detail.order_id')
			->leftjoin('comments', 'comments.order_id', '=', 'order_detail.id')
			->orderBy('order_detail.id', 'desc')
			->select('order_detail.*', 'orders.*', 'comments.id as review_id', 'order_detail.id as sub_order_id')
			->get()->toArray();
		}else{
		$get_order_data = DB::table('order_detail')
			->where($condition_array)
			->join('orders', 'orders.id', '=', 'order_detail.order_id')
			->leftjoin('comments', 'comments.order_id', '=', 'order_detail.id')
			->orderBy('order_detail.id', 'desc')
			->select('order_detail.*', 'orders.*', 'comments.id as review_id', 'order_detail.id as sub_order_id')
			->get()->toArray();
		}
	}
	if(count($get_order_data) > 0){
		$data['order_data'] = $get_order_data;
	}
	$data['days'] = $days;
	$data['start_date']= $start_date;
	$data['end_date']= $endDate;
	$data['status_type']= $status_type;
	$data['type'] = $PageType;	
    $data['login_user_details'] =  get_current_frontend_user_info();
	$data['WaitDepositCount']=$this->getOrderCount(Session::get('shopist_frontend_user_id'),'WaitDeposit');
	$data['DepositCount']=$this->getOrderCount(Session::get('shopist_frontend_user_id'),'Deposit');
	$data['PreparedCount']=$this->getOrderCount(Session::get('shopist_frontend_user_id'),'Prepared');
	$data['ShippedCount']=$this->getOrderCount(Session::get('shopist_frontend_user_id'),'Shipped');
	$data['DeliveredCount']=$this->getOrderCount(Session::get('shopist_frontend_user_id'),'Delivered');

   
    return view('pages.frontend.user-account.user-account-pages', $data);
  }
  
  /**
   * 
   * User account coupons page content
   *
   * @param null
   * @return null
   */
  public function userAccountCouponsPageContent(){
    $data = array();
    $coupon_data = array();
    
    $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
    $get_current_user_id = get_current_frontend_user_info();

    if(!empty($get_current_user_id) && count($get_current_user_id) > 0){
      $get_post_meta = PostExtra::where(['key_name' => '_coupon_allow_role_name', 'key_value' => $get_current_user_id['user_role_slug']])->get()->toArray();
      if(!empty($get_post_meta) && count($get_post_meta) > 0){
        foreach($get_post_meta as $row){
          $get_post = Post::where(['id' => $row['post_id']])->first();
          $get_post_meta_all = PostExtra::where(['post_id' => $row['post_id']])->get()->toArray();

          if(!empty($get_post)){
            $data['coupon_code']        = $get_post->post_title;
            $data['coupon_status']      = $get_post->post_status;
            $data['coupon_description'] = $get_post->post_content;
          }

          if(!empty($get_post_meta_all) && count($get_post_meta_all) > 0){
            foreach($get_post_meta_all as $post_meta_row){
              if($post_meta_row['key_name'] == '_coupon_condition_type'){
                if($post_meta_row['key_value'] == 'discount_from_product'){
                  $data['coupon_condition_type'] = Lang::get('frontend.coupon_condition_discount_product');
                }
                elseif($post_meta_row['key_value'] == 'percentage_discount_from_product'){
                  $data['coupon_condition_type'] = Lang::get('frontend.coupon_condition_percentage_discount_product');
                }
                elseif($post_meta_row['key_value'] == 'discount_from_total_cart'){
                  $data['coupon_condition_type'] = Lang::get('frontend.coupon_condition_discount_from_total_cart');
                }
                elseif($post_meta_row['key_value'] == 'percentage_discount_from_total_cart'){
                  $data['coupon_condition_type'] = Lang::get('frontend.coupon_condition_percentage_discount_from_total_cart');
                }

              }
              elseif($post_meta_row['key_name'] == '_coupon_amount'){
                $data['coupon_amount'] = $post_meta_row['key_value'];
              }
              elseif($post_meta_row['key_name'] == '_coupon_min_restriction_amount'){
                $data['coupon_min_restriction_amount'] = $post_meta_row['key_value'];
              }
              elseif($post_meta_row['key_name'] == '_coupon_max_restriction_amount'){
                $data['coupon_max_restriction_amount'] = $post_meta_row['key_value'];
              }
              elseif($post_meta_row['key_name'] == '_coupon_allow_role_name'){
                $data['coupon_allow_role_name'] = $post_meta_row['key_value'];
              }
              elseif($post_meta_row['key_name'] == '_usage_limit_per_coupon'){
                $data['usage_limit_per_coupon'] = $post_meta_row['key_value'];
              }
              elseif($post_meta_row['key_name'] == '_usage_range_end_date'){
                $data['usage_range_end_date'] = $post_meta_row['key_value'];
              }
            }
          }
          array_push($coupon_data, $data);
        }
      }     
    }

    $data['login_user_coupon_data'] =  $coupon_data;
    $data['login_user_details'] =  get_current_frontend_user_info();
    
    return view('pages.frontend.user-account.user-account-pages', $data);
  }
  
  /**
   * 
   * User Refund account  page content
   * <ayushma.jain@gaurish.com>
   * @param null
   * @return null
   */
  public function userRefundAccountPageContent(){
    $data = array();
	
	
	 $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
    $get_current_user_id = get_current_frontend_user_info();
    $get_data_by_user_id = get_user_account_details_by_user_id( $get_current_user_id['user_id'] );
    $get_array_shift_data = array_shift($get_data_by_user_id);
	$data['user_account_info'] = RefundAccount::where( ['user_id' => $get_current_user_id['user_id']] )->get()->toArray();
	$banks = DB::table('bank')->get()->toArray();
	$bank_list=array();
	$bank_arr=array();
	if(count($banks)>0)
	{
		foreach($banks as $rr)
		{
			array_push($bank_list,array('bank_code'=>$rr->bank_code,'bank_name'=>$rr->bank_name));
			$bank_arr[$rr->bank_code]	=	$rr->bank_name;
		}
	}
	$data['banks']=$bank_list;
	$data['bank_name']=$bank_arr;
    $data['frontend_account_details'] = json_decode($get_array_shift_data['details']);
    $data['login_user_details'] =  get_current_frontend_user_info();

    return view('pages.frontend.user-account.user-account-pages', $data);
  }
  
    /**
   * 
   * User Product Review page content
   * <ayushma.jain@gaurish.com>
   * @param null
   * @return null
   */
  public function userProductReviewPageContent(){
    $data = array();
	
	
	 $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
    $get_current_user_id = get_current_frontend_user_info();
    $get_data_by_user_id = get_user_account_details_by_user_id( $get_current_user_id['user_id'] );
    $get_array_shift_data = array_shift($get_data_by_user_id);

    $data['frontend_account_details'] = json_decode($get_array_shift_data['details']);
	$product_review = DB::table('order_detail')
					->where('comments.user_id', Session::get('shopist_frontend_user_id'))
					->join('orders', 'orders.id', '=', 'order_detail.order_id')
					->leftjoin('comments', 'comments.order_id', '=', 'order_detail.id')
                    ->orderBy('order_detail.id', 'desc')
                    ->select('order_detail.product_detail', 'comments.*')
                    ->get()->toArray();
	$data['product_review']  = $product_review;
    $data['login_user_details'] =  get_current_frontend_user_info();
    return view('pages.frontend.user-account.user-account-pages', $data);
  }
  
  
  
  /**
   * Function to save refund account Information
   * Frontend user save Account
   * <ayushma.jain@gaurish.com>
   * @param null
   * @return response
   */
	public function saveAccountInfo(){
		//print_r($_FILES);
		$agent = new Agent();
		if(is_frontend_user_logged_in() && Request::isMethod('post') && Session::token() == Input::get('_token')){
			$input = Request::all(); 
			print_r($input);
			$get_current_user_id	=  get_current_frontend_user_info();

			$refund_account			=  new RefundAccount;
			$refund_account->updateOrCreate(
				[
				  'user_id' => $get_current_user_id['user_id']
	
				],
				[
				  'user_id' => $get_current_user_id['user_id'],
				  'account_holder' => $input['account_holder'],
				  'account_number' =>  $input['account_no'],
				  'bank_name' => $input['bank_name'],
				  'updated_at' => date('Y-m-d h:i:s')
				]
			);
			if($agent->isMobile())
			{
				return redirect()->route('user-account-page');
			}else
			{
				return redirect()->route('account-info');
			}
		}
		
	}
  
  /**
   * 
   * User account profile page content
   *
   * @param null
   * @return null
   */
  public function userAccountProfilePageContent(){
    $data = array();
    
    $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
    $get_current_user_id = get_current_frontend_user_info();
    $data['user_details'] = get_user_details( $get_current_user_id['user_id'] );
    $data['login_user_details'] =  get_current_frontend_user_info();
    
    return view('pages.frontend.user-account.user-account-pages', $data);
  }
  /**
   * 
   * User account support page content
   *
   * @param null
   * @return null
   */
  public function userSupportPageContent(){
    $data = array();
    
    $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
    $get_current_user_id = get_current_frontend_user_info();
    $get_data_by_user_id = get_user_account_details_by_user_id( $get_current_user_id['user_id'] );
    $get_array_shift_data = array_shift($get_data_by_user_id);
	$data['user_support_ticket'] = SupportTicket::where( ['user_id' => $get_current_user_id['user_id']] )->get()->toArray();

    $data['frontend_account_details'] = json_decode($get_array_shift_data['details']);
    $data['login_user_details'] =  get_current_frontend_user_info();
	return view('pages.frontend.user-account.user-account-pages', $data);
  }
  
  /**
   * 
   * User account order details
   *
   * @param order_id, order_process_id
   * @return null
   */
  public function userAccountOrderDetailsContent($params, $params2){
    $data = array();
    $get_order_data = $this->classCommonFunction->get_order_details_by_order_id(array('order_id' => $params, 'order_process_id' => $params2));
    
    $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
    $get_current_user_id = get_current_frontend_user_info();
    $data['user_details'] = get_user_details( $get_current_user_id['user_id'] );
    $data['login_user_details'] =  get_current_frontend_user_info();
      
    if(count($get_order_data) > 0){
      $data['order_details_by_order_id'] = $get_order_data;
    }
    else{
      $data['order_details_by_order_id'] = array();
    }
    
    return view('pages.frontend.user-account.user-account-pages', $data);
  }


  /**
   * 
   * Save/Update frontend user account data
   *
   * @param null
   * @return null
   */
  function saveUserAccountData(){
    if( Request::isMethod('post') && Session::token() == Input::get('_token') ){
      if(Input::get('_account_post_type') == 'address'){
        $rules = [
                 'account_bill_first_name'                  =>  'required',
                 'account_bill_last_name'                   =>  'required',
                 'account_bill_email_address'               =>  'required|email',
                 'account_bill_phone_number'                =>  'required',
                 'account_bill_select_country'              =>  'required',
                 'account_bill_adddress_line_1'             =>  'required',
                 'account_bill_town_or_city'                =>  'required',
                 'account_bill_zip_or_postal_code'          =>  'required',
                 
                 'account_shipping_first_name'              =>  'required',
                 'account_shipping_last_name'               =>  'required',
                 'account_shipping_email_address'           =>  'required|email',
                 'account_shipping_phone_number'            =>  'required',
                 'account_shipping_select_country'          =>  'required',
                 'account_shipping_adddress_line_1'         =>  'required',
                 'account_shipping_town_or_city'            =>  'required',
                 'account_shipping_zip_or_postal_code'      =>  'required',
                 
        ];
        
        $messages = [
                    'account_bill_first_name.required' => Lang::get('validation.account_bill_first_name'),
                    'account_bill_last_name.required' => Lang::get('validation.account_bill_last_name'),
                    'account_bill_email_address.required' => Lang::get('validation.account_bill_email_address'),
                    'account_bill_email_address.email' => Lang::get('validation.account_bill_email_address_is_email'),
                    'account_bill_phone_number.required' => Lang::get('validation.account_bill_phone_number_name'),
                    'account_bill_select_country.required' => Lang::get('validation.account_bill_select_country'),
                    'account_bill_adddress_line_1.required' => Lang::get('validation.account_bill_adddress_line_1'),
                    'account_bill_town_or_city.required' => Lang::get('validation.account_bill_town_or_city'),
                    'account_bill_zip_or_postal_code.required' => Lang::get('validation.account_bill_zip_or_postal_code'),
                    'account_shipping_first_name.required' => Lang::get('validation.account_shipping_first_name'),
                    'account_shipping_last_name.required' => Lang::get('validation.account_shipping_last_name'),
                    'account_shipping_email_address.required' => Lang::get('validation.account_shipping_email_address'),
                    'account_shipping_email_address.email' => Lang::get('validation.account_shipping_email_address_is_email'),
                    'account_shipping_select_country.required' => Lang::get('validation.account_shipping_select_country'),
                    'account_shipping_adddress_line_1.required' => Lang::get('validation.account_shipping_adddress_line_1'),
                    'account_shipping_town_or_city.required' => Lang::get('validation.account_shipping_town_or_city'),
                    'account_shipping_zip_or_postal_code.required' => Lang::get('validation.account_shipping_zip_or_postal_code'),
                    'account_shipping_phone_number.required' => Lang::get('validation.account_shipping_phone_number_name')
        ];
      
        $validator = Validator::make(Input::all(), $rules, $messages);
        
        if($validator->fails()){
          return redirect()-> back()
          ->withInput()
          ->withErrors( $validator );
        }
        else{
          
          $address_data_ary = array();
          $address_data_ary['account_bill_title']                   =         Input::get('account_bill_title');
          $address_data_ary['account_bill_company_name']            =         Input::get('account_bill_company_name');
          $address_data_ary['account_bill_first_name']              =         Input::get('account_bill_first_name');
          $address_data_ary['account_bill_last_name']               =         Input::get('account_bill_last_name');
          $address_data_ary['account_bill_email_address']           =         Input::get('account_bill_email_address');
          $address_data_ary['account_bill_phone_number']            =         Input::get('account_bill_phone_number');
          $address_data_ary['account_bill_select_country']          =         Input::get('account_bill_select_country');
          $address_data_ary['account_bill_adddress_line_1']         =         Input::get('account_bill_adddress_line_1');
          $address_data_ary['account_bill_adddress_line_2']         =         Input::get('account_bill_adddress_line_2');
          $address_data_ary['account_bill_town_or_city']            =         Input::get('account_bill_town_or_city');
          $address_data_ary['account_bill_zip_or_postal_code']      =         Input::get('account_bill_zip_or_postal_code');
          $address_data_ary['account_bill_fax_number']              =         Input::get('account_bill_fax_number');
          
          $address_data_ary['account_shipping_title']               =         Input::get('account_shipping_title');
          $address_data_ary['account_shipping_company_name']        =         Input::get('account_shipping_company_name');
          $address_data_ary['account_shipping_first_name']          =         Input::get('account_shipping_first_name');
          $address_data_ary['account_shipping_last_name']           =         Input::get('account_shipping_last_name');
          $address_data_ary['account_shipping_email_address']       =         Input::get('account_shipping_email_address');
          $address_data_ary['account_shipping_phone_number']        =         Input::get('account_shipping_phone_number');
          $address_data_ary['account_shipping_select_country']      =         Input::get('account_shipping_select_country');
          $address_data_ary['account_shipping_adddress_line_1']     =         Input::get('account_shipping_adddress_line_1');
          $address_data_ary['account_shipping_adddress_line_2']     =         Input::get('account_shipping_adddress_line_2');
          $address_data_ary['account_shipping_town_or_city']        =         Input::get('account_shipping_town_or_city');
          $address_data_ary['account_shipping_zip_or_postal_code']  =         Input::get('account_shipping_zip_or_postal_code');
          $address_data_ary['account_shipping_fax_number']          =         Input::get('account_shipping_fax_number');
          
          $address_data = array('post_type' => 'address', 'details' => $address_data_ary);
          
         
          if($this->classCommonFunction->frontendUserAccountDataProcess( $address_data )){
            Session::flash('message', Lang::get('frontend.address_saved_msg'));
            return redirect()->route('my-address-page');
          }
          
        }
      }
    }
    else{
      return redirect()-> back();
    }
  }
  
  /**
   * 
   * Update frontend user profile data
   *
   * @param null
   * @return void
   */
  public function updateFrontendUserProfile()
  {
    if( Request::isMethod('post') && Session::token() == Input::get('_token') )
    {
      $input = Input::all();
	  $rules = [
               'display_name'                  =>  'required',
               'user_name'                     =>  'required',
               'email_id'                      =>  'required|email',
               ];

      if(Input::get('password'))
      {
        $rules['password']             =   'min:5';                 
      }

      $validator = Validator:: make($input, $rules);

      if($validator->fails())
      {
        return redirect()-> back()
        ->withInput()
        ->withErrors( $validator );
      }
      else
      {
        $is_user_name_exists = User::where(['name' => Input::get('user_name')])->first();
        $is_email_exists     = User::where(['email' => Input::get('email_id')])->first();
        
        if($is_user_name_exists && $is_user_name_exists->id != Session::get('shopist_frontend_user_id'))
        {
          Session::flash('error-message', Lang::get('validation.unique', ['attribute' => 'user name']));
          return redirect()->back();
        } 
        
        if($is_email_exists && $is_email_exists->id != Session::get('shopist_frontend_user_id'))
        {
          Session::flash('error-message', Lang::get('validation.unique', ['attribute' => 'email id']));
          return redirect()->back();
        } 

        $data = array(
                      'display_name'         =>    Input::get('display_name'),
                      'name'                 =>    Input::get('user_name'),
                      'email'                =>    Input::get('email_id')
        );

        if(Input::get('password'))
        {
          $data['password'] = bcrypt(Input::get('password'));
        }

        if(Input::get('hf_frontend_profile_picture'))
        {
          $data['user_photo_url'] = Input::get('hf_frontend_profile_picture');
        }
        else
        {
          $data['user_photo_url'] = '';
        }

        if(User::where('id', Session::get('shopist_frontend_user_id'))->update($data))
        {
          Session::flash('message', Lang::get('frontend.profile_updated_msg'));
          return redirect()->back();
        }
      }
    }
    else 
    {
      return redirect()-> back();
    }
  }
  
  /**
   * 
   * Frontend user logout
   *
   * @param null
   * @return response
   */
  public function userLogout(){
    if(is_frontend_user_logged_in()){
      Session::forget('shopist_frontend_user_id');
      Session::forget('enum_user_type_status');
      return redirect()->route('user-login-page');
    }
  }
  /**
   * 
   * Frontend user save ticket
   *
   * @param null
   * @return response
   */
	public function saveUserTicket(){
		//print_r($_FILES);
		
		if(is_frontend_user_logged_in() && Request::isMethod('post') && Session::token() == Input::get('_token')){
			//echo '<pre>'; print_r(Request::all());
			$input = Request::all(); 
			$attachment='';
			if(Input::file('ticket_attachment'))
			{
				$image = Input::file('ticket_attachment');
				$fileName = time()."-"."h-250-".$image->getClientOriginalName();
				$height = 250;
				$img   = Image::make($image);
				$path  = public_path('uploads/ticket_attachment/' . $fileName);
			  	/*$img->resize(null, $height, function ($constraint) {
						$constraint->aspectRatio();
				});*/
				if ($img->save($path)) 
				{
					$attachment='ticket_attachment/'.$fileName;
				}
			}
			$get_current_user_id	=  get_current_frontend_user_info();
			$support_ticket			=  new SupportTicket;
			$support_ticket->updateOrCreate(
				[
				  'user_id' => $get_current_user_id['user_id'],
				  'type' => $input['ticket_type'],
				  'ticket_name' =>  $input['ticket_head'],
				  'ticket_content' => $input['ticket_content'],
				  'attachment' => $attachment,
				  'product_id' => $input['product_id'],
				  'vendor_id' =>  $input['vendor_id']
				],
				[
				  'user_id' => $get_current_user_id['user_id'],
				  'type' => $input['ticket_type'],
				  'ticket_name' =>  $input['ticket_head'],
				  'ticket_content' => $input['ticket_content'],
				  'attachment' => $attachment,
				  'product_id' => $input['product_id'],
				  'vendor_id' =>  $input['vendor_id'],
				  'updated_at' => date('Y-m-d h:i:s')
				]
			);
			//return redirect()->route('my-support-page');
			return redirect()->back();
		}
		
	}
 

   /**
   * 
   * Function to save 1:1 Consultation inquiry page data into user_1_1_consultation_inquiry_data table.
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Last Updated: 12 Feb 2019
   * @param null
   * @return response
   */

  public function userSaveOneToOneConsultationPageData()
  {
    if(is_frontend_user_logged_in() && Request::isMethod('post') && Session::token() == Input::get('_token')) 
    {
      // Getting all input data
      $postData = Input::all();
       
      $rules = [
        'inquiry_title'  => 'required',
        'inquiry_email_address' => 'required',
        'inquiry_mobile_phone_number'  => 'required' ,
        'selectedFieldLabel'  => 'required' 
      ];

      $messages = [
        'inquiry_title.required' => Lang::get('validation.missing_required_parameter'),
        'inquiry_email_address.required' => Lang::get('validation.missing_required_parameter'),
        'inquiry_mobile_phone_number.required' => Lang::get('validation.missing_required_parameter'),
        'selectedFieldLabel.required' => Lang::get('validation.missing_required_parameter') 
      ];   

      $validator = Validator:: make($postData, $rules, $messages);

      if($validator->fails())
      {
        return redirect()-> back()
        ->withInput()
        ->withErrors( $validator );
      } else {

        // Getting logged in User Id.
        $loggedInUserId = (Session::has('shopist_frontend_user_id')) ? Session::get('shopist_frontend_user_id') : 0;

        // Allow user to make request only when logged in.
        if ($loggedInUserId > 0)
        {
          
          // Loading instance of Consultation Model.
          $Consultation = new Consultation;

          // Calling this function to save 1:1 consultaion request data. 
          $inquiryId = $Consultation->saveOneToOneConsultaionInquiryPageData();

          // If you got $inquiryId > 0, success, do this.
          if ($inquiryId > 0) {
            Session::flash('statusMsg', trans('frontend.lable_saved_successfuly'));
            return redirect()->back();
          } else
          {
          	Session::flash('status-message', 'invalid_file_type_error');
    		return redirect()->back();
          }
           
        } else {
          // Redirecting to Login Page.
          return redirect()->route('user-login-page');
        }
      }
    } else {
      return redirect()->back();
    }
  }
 
	/**
   * 
   * Verify frontend login
   *
   * @param null
   * @return void
   */
  public function verifyFrontendLogin(){
		if( Request::isMethod('post') && Session::token() == Input::get('_token') ){
			$inputData = Input::all();
			if(isset($inputData['login_username']))
			{
				$username       =      Input::get('login_username');
				$password       =      bcrypt(Input::get('recheck_pwd'));
				$userdata       =      ['name' => $username, 'user_status' => 1];
				$dataResponse   =      User::where($userdata)->first();
				
				if(!empty($dataResponse) && isset($dataResponse->password) && isset($dataResponse->id)){
					
					if(Hash::check(Input::get('recheck_pwd'), $password) && Hash::check(Input::get('recheck_pwd'), $dataResponse->password))
					{
						$get_user_role =  get_user_details( $dataResponse->id );
						$data = array();
						$data = $this->classCommonFunction->get_dynamic_frontend_content_data();
						$get_current_user_id = get_current_frontend_user_info();
						$data['user_details'] = get_user_details( $get_current_user_id['user_id'] );
						$data['login_user_details'] =  get_current_frontend_user_info();
						$data['user_profile'] =  $get_user_role;
						$data['user_default_address'] = UserShippingAddress::where( ['user_id' => $get_current_user_id['user_id'],'mark_default' => 'yes'] )->get()->toArray();
						return view('pages.frontend.user-account.user-account-pages', $data);
					}
					else {
					  return redirect()-> back();
					}
				}
				else {
				  return redirect()-> back();
				}
			}
			else
			{
				$input = Input::all();
				$input['email_id']=$input['email_first'].'@'.$input['email_second'];
				$input['contact_number']=$input['contact_code'].'-'.$input['contact_first'].'-'.$input['contact_second'];
				
				$data = array(
						  'gender'         	=>    Input::get('gender'),
						  'dob'            	=>    Input::get('dob'),
						  'email' 			=>    $input['email_id']
				);

				UserShippingAddress::where(['user_id' => Session::get('shopist_frontend_user_id'),'mark_default' => 'yes'])->update(['primary_contact' => $input['contact_number'],'zipcode' => $input['address_number'],'address_line_1' => $input['address_1'],'address_line_2' => $input['address_2']]);

				if(Input::get('new_password'))
				{
					$data['password'] = bcrypt(Input::get('new_password'));
				}
				if(User::where('id', Session::get('shopist_frontend_user_id'))->update($data))
				{
					return redirect()->route('user-account-page');
				}	
			}
		}
	}
	/*Function to get Order Count on the basis of status or user Id.*/
	public function getOrderCount($user_id,$type)
	{
		$total ='';
		$get_order_data = DB::table('order_detail')
					->where('orders.user_id',$user_id)
					->where('status', $type)
					->join('orders', 'orders.id', '=', 'order_detail.order_id')
                    ->select(DB::raw('count(*) as total'))
                    ->get()->toArray();
		if(count($get_order_data) > 0){
			$total = $get_order_data[0]->total;
		}
		return $total;
	}
}