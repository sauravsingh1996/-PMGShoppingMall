<?php
namespace shopist\Http\Controllers\Frontend;

use shopist\Http\Controllers\Controller;
use Request;
use Illuminate\Support\Facades\Input;
use shopist\Library\GetFunction;
use shopist\Models\Post;
use shopist\Models\PostExtra;
use shopist\Models\Product;
use Anam\Phpcart\Cart;
use shopist\Models\DownloadExtra;
use shopist\Models\User;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Lang;
use Cookie;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Response;
use shopist\Http\Controllers\ProductsController;
use shopist\Library\CommonFunction;
use shopist\Http\Controllers\CMSController;
use shopist\Http\Controllers\OptionController;
use shopist\Models\OrdersItem;
use shopist\Http\Controllers\VendorsController;
use shopist\Models\SaveCustomDesign;
use shopist\Models\SupportTicket;
use shopist\Models\UserShippingAddress;
use Illuminate\Support\Facades\Cache;
use shopist\Models\UserRecentActivity;

class FrontendManagerController extends Controller
{
  public $classGetFunction;
  public $cart;
  public $product;
  public $classCommonFunction;
  public $CMS;
  public $option;
  public $vendors;

  public function __construct() {
    $this->product              =  new ProductsController();
    $this->classCommonFunction  =  new CommonFunction();
    $this->cart                 =  new Cart();
    $this->classGetFunction     =  new GetFunction();
    $this->CMS                  =  new CMSController();
    $this->option               =  new OptionController();
    $this->vendors              =  new VendorsController();
  }
  
  /**
   * 
   * Home page content
   *
   * @param null
   * @return void 
   */
  public function homePageContent(){
    $data = array();
    $data = array();
    $sort = null;
    $price_min = null;
    $price_max = null;
    $selected_colors = null;
    $selected_sizes = null;
    $search_term = null;
	
    $data = $this->classCommonFunction->get_dynamic_frontend_content_data(); 
    $data['advancedData']        =   $this->product->getAdvancedProducts();
    $data['brands_data']         =   $this->product->getTermData( 'product_brands', false, null, 1 );
    $data['testimonials_data']   =   get_all_testimonial_data();
	
	$get_product  =  $this->product->getFilterProductsDataWithPagination(array('srch_term' => $search_term));
  
  // Calling this function to get only PMG store products.
  $data['pmgStoreProducts'] = $this->product->pmgStoreProducts();
 
	$data['all_products_details'] =   $get_product;
	$data['vendors_list'] = $this->vendors->getAllVendors( false, null, 1 );
    return view('pages.frontend.frontend-pages.home', $data);
  }
   
  /**
   * 
   * Product categories single page content
   *
   * @param null
   * @return void 
   */
  public function productCategoriesSinglePageContent($params){
    $data = array();
    $sort = null;
    $price_min = null;
    $price_max = null;
    $selected_colors = null;
    $selected_sizes = null;
     
    if(isset($_GET['sort_by'])){
      $sort = $_GET['sort_by'];
    }
      
    if(isset($_GET['price_min'])){
      $price_min = $_GET['price_min'];
    }
      
    if(isset($_GET['price_max'])){
      $price_max = $_GET['price_max'];
    }
      
    if(isset($_GET['selected_colors'])){
      $selected_colors = $_GET['selected_colors'];
    }

    if(isset($_GET['selected_sizes'])){
      $selected_sizes = $_GET['selected_sizes'];
    }
	if(isset($_GET['category'])){
		$selected_cat = $_GET['category'];
	}else{
		$selected_cat = $params;
	}
      
    $get_cat_product_and_breadcrumb  =  $this->product->getProductByCatSlug($params, array('selected_cat'=> $selected_cat));

    if(count($get_cat_product_and_breadcrumb) > 0){
      $data = $this->classCommonFunction->get_dynamic_frontend_content_data(); 
      $data['product_by_cat_id']  =   $get_cat_product_and_breadcrumb;
      $data['brands_data']        =   $this->product->getTermData( 'product_brands', false, null, 1 );
      $data['colors_list_data']   =   $this->product->getTermData( 'product_colors', false, null, 1 );
      $data['sizes_list_data']    =   $this->product->getTermData( 'product_sizes', false, null, 1 );
	
	 
	  
      if(count($data['product_by_cat_id']) > 0){
        $data['product_by_cat_id']['action_url'] = Request::url();
        
        $currentQuery = Request::query();
        
        if(count($currentQuery) > 0){
          if(isset($currentQuery['view'])){
            unset($currentQuery['view']);
          }
          
          if(count($currentQuery) > 0){
            $currentQuery['view'] = 'list';
            $data['product_by_cat_id']['action_url_list_view'] = Request::url(). '?' . http_build_query($currentQuery);
            $currentQuery['view'] = 'grid';
            $data['product_by_cat_id']['action_url_grid_view'] = Request::url(). '?' . http_build_query($currentQuery);
          }
          else{
            $data['product_by_cat_id']['action_url_list_view'] = Request::url(). '?view=list';
            $data['product_by_cat_id']['action_url_grid_view'] = Request::url(). '?view=grid';
          }
        }
        else{
          $data['product_by_cat_id']['action_url_list_view'] = Request::url(). '?view=list';
          $data['product_by_cat_id']['action_url_grid_view'] = Request::url(). '?view=grid';
        }
        
        if(isset($_GET['view']) && $_GET['view'] == 'list'){
          $data['product_by_cat_id']['selected_view'] = 'list'; 
        }
        elseif(isset($_GET['view']) && $_GET['view'] == 'grid'){
          $data['product_by_cat_id']['selected_view'] = 'grid'; 
        }
        else{
          $data['product_by_cat_id']['selected_view'] = 'grid';
        }
      }
	  $selected_cat_id =  DB::table('terms')
			  ->where(['terms.slug' => $params, 'terms.type' => 'product_cat' ])
			  ->select('terms.term_id')        
			  ->get()
			  ->toArray();
	  
	  $data['selected_cat_id']  =  isset($selected_cat_id[0])?$selected_cat_id[0]->term_id:'';
	   $data['sub_category_list']  =   $this->product->getCategoriesByParentCatIdFrontendUser($data['selected_cat_id'],'product_cat');
		$data['selected_category']  =  $selected_cat;
      $data['category_page_advertisement'] = $this->classCommonFunction->getAllAdvertisement('category_page');
	// echo '<pre>'; print_r($data['sub_category_list']);exit;
      //dd($data);
      return view('pages.frontend.frontend-pages.categories-main', $data);
    }
    else{
      return view('errors.no_data');
    }
  }
  
  
  
  /**
   * 
   * Product sub categories single page content
   *
   * @param null
   * @return void 
   */
  public function productSubCategoriesPageContent( $params ){
    $data = array();
    $sort = null;
    $price_min = null;
    $price_max = null;
    $selected_colors = null;
    $selected_sizes = null;
	$view=20;
    $filter ='';
    if(isset($_GET['sort_by'])){
      $sort = $_GET['sort_by'];
    }
	if(isset($_GET['view_by'])){
      $view = $_GET['view_by'];
    }
    if(isset($_GET['price_min'])){
      $price_min = $_GET['price_min'];
    }
     if(isset($_GET['filter_by'])){
      $filter = $_GET['filter_by'];
    }
    if(isset($_GET['price_max'])){
      $price_max = $_GET['price_max'];
    }
      
    if(isset($_GET['selected_colors'])){
      $selected_colors = $_GET['selected_colors'];
    }

    if(isset($_GET['selected_sizes'])){
      $selected_sizes = $_GET['selected_sizes'];
    }
     if(isset($_GET['category'])){
		$selected_cat = $_GET['category'];
	}else{
		$selected_cat = $params;
	}
	 
      $get_cat_product_and_breadcrumb  =  $this->product->getProductByCatSlug($params, array('selected_cat'=> $selected_cat,'view_by'=>$view));
	
    if(count($get_cat_product_and_breadcrumb) > 0){
      $data = $this->classCommonFunction->get_dynamic_frontend_content_data(); 
      $data['product_by_cat_id']  =   $get_cat_product_and_breadcrumb;
      $data['brands_data']        =   $this->product->getTermData( 'product_brands', false, null, 1 );
      $data['colors_list_data']   =   $this->product->getTermData( 'product_colors', false, null, 1 );
      $data['sizes_list_data']    =   $this->product->getTermData( 'product_sizes', false, null, 1 );
	  $data['view_by'] = $view;
	  $data['filter_by'] = $filter;
      if(count($data['product_by_cat_id']) > 0){
        $data['product_by_cat_id']['action_url'] = Request::url();
        
       
      }
	 
	  $selected_cat_id =  DB::table('terms')
			  ->where(['terms.slug' => $params, 'terms.type' => 'product_cat' ])
			  ->select('terms.term_id')        
			  ->get()
			  ->toArray();
	  
	  $data['selected_cat_id']  =  isset($selected_cat_id[0])?$selected_cat_id[0]->term_id:'';
	   $data['sub_category_list']  =   $this->product->getCategoriesByParentCatIdFrontendUser($data['selected_cat_id'],'product_cat');
	 $data['selected_category']  =  $selected_cat;
	  
      $data['sub_page_advertisement'] = $this->classCommonFunction->getAllAdvertisement('sub_page');
      return view('pages.frontend.frontend-pages.sub-categories', $data);
    }
    else{
      return view('errors.no_data');
    }
  }
  
  
  
  /**
   * 
   * Testimonial single page content
   *
   * @param null
   * @return void 
   */
  public function testimonialSinglePageContent( $params ){
    $data = array();
    $testimonial_arr = array();
    
    $get_testimonial = get_testimonial_data_by_slug($params);
    if(count($get_testimonial) > 0 && isset($get_testimonial['post_status']) && $get_testimonial['post_status'] == 1){
      $data = $this->classCommonFunction->get_dynamic_frontend_content_data(); 
      $data['testimonials_data_by_slug'] =  $get_testimonial;
      $get_testimonials_data  =   get_all_testimonial_data(1);

      if(count($get_testimonials_data) > 0){
        foreach($get_testimonials_data as $testimonials_data){
          if($testimonials_data['post_slug'] != $params){
            array_push($testimonial_arr, $testimonials_data);
          }
        }
      }

      if(count($testimonial_arr) > 0){
        $data['testimonials_data'] = $testimonial_arr;
      }
      else{
        $data['testimonials_data'] = array();
      }
      
      return view('pages.frontend.frontend-pages.testimonial-details', $data);
    }
    else{
      return view('errors.no_data');
    }
  }
  
  /**
   * 
   * Blog single page content
   *
   * @param null
   * @return void 
   */
  public function blogSinglePageContent( $params ){
    $data = array();
    $get_blog_details_by_slug = $this->CMS->get_blog_by_slug($params);
      
    if(count($get_blog_details_by_slug) > 0 && isset($get_blog_details_by_slug['post_status']) && $get_blog_details_by_slug['post_status'] == 1){
      $object_id = 0;

      if(isset($get_blog_details_by_slug['id'])){
        $object_id = $get_blog_details_by_slug['id'];
      }
      
      $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
      $data['advanced_data']            =   $this->CMS->get_blog_advanced_data($object_id);
      $data['blog_details_by_slug']     =   $get_blog_details_by_slug;
      $data['comments_details']         =   get_comments_data_by_object_id( $object_id, 'blog' );
      $data['comments_rating_details']  =   get_comments_rating_details( $object_id, 'blog' );

      if(!Session::has('shopist_blog_count') || (Session::has('shopist_blog_count') && Session::get('shopist_blog_count') != $get_blog_details_by_slug['id'])){  
        $get_post_meta =  PostExtra::where(['post_id' => $get_blog_details_by_slug['id'], 'key_name' => '_count_visit'])->first();

        if(!empty($get_post_meta)){
          $new_value = array(
                            'key_value'  =>  $get_post_meta->key_value + 1
          );

          PostExtra::where(['post_id' => $get_blog_details_by_slug['id'], 'key_name' => '_count_visit'])->update($new_value);
        }
        else{
            PostExtra::insert(array(
                    array(
                        'post_id'       =>      $get_blog_details_by_slug['id'],
                        'key_name'      =>      '_count_visit',
                        'key_value'     =>      1,
                        'created_at'    =>      date("y-m-d H:i:s", strtotime('now')),
                        'updated_at'    =>      date("y-m-d H:i:s", strtotime('now'))
                    )
            ));
        }

        Session::put('shopist_blog_count', $get_blog_details_by_slug['id']);
    }

      $get_seo_data = get_seo_data();

      if(isset($get_seo_data['meta_tag']['meta_keywords']) && isset($data['blog_details_by_slug']['blog_seo_keywords'])){
        $data['blog_details_by_slug']['meta_keywords'] = trim( trim($get_seo_data['meta_tag']['meta_keywords'], ','). ',' .trim($data['blog_details_by_slug']['blog_seo_keywords'], ','), ',');
      }
      elseif(!isset($get_seo_data['meta_tag']['meta_keywords']) && isset($data['blog_details_by_slug']['blog_seo_keywords'])){
        $data['blog_details_by_slug']['meta_keywords'] = trim($data['blog_details_by_slug']['blog_seo_keywords'], ',');
      }
      elseif(isset($get_seo_data['meta_tag']['meta_keywords']) && !isset($data['blog_details_by_slug']['blog_seo_keywords'])){
        $data['blog_details_by_slug']['meta_keywords'] = trim($get_seo_data['meta_tag']['meta_keywords'], ',');
      }
      else{
        $data['blog_details_by_slug']['meta_keywords'] = null;
      }
      
      return view('pages.frontend.frontend-pages.blog-single-page', $data);
    }  
    else{
      return view('errors.no_data');
    } 
  }
  
  /**
   * 
   * Brand single page content
   *
   * @param null
   * @return void 
   */
  public function brandSinglePageContent( $params ){
    $data = array();
    $get_brand_details_by_slug = $this->product->getBrandDataBySlug( $params );
     
    if(count($get_brand_details_by_slug) > 0){
      $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
      $data['brand_details_by_slug'] = $get_brand_details_by_slug;
      
      return view('pages.frontend.frontend-pages.brand-single-page', $data);
    }
    else{
      return view('errors.no_data');
    }
  }
  
  /**
   * 
   * Products page content
   *
   * @param null
   * @return void 
   */
  public function productsPageContent($param = null){
    $data = array();
    $sort = null;
    $price_min = null;
    $price_max = null;
    $selected_colors = null;
    $selected_sizes = null;
    $search_term = null;
	$view_by =20;
	 $filter= '';
    if(isset($_GET['srch_term'])){
		$search_term = $_GET['srch_term'];
		//Save user recent search activity.
		if(is_frontend_user_logged_in()){
			$this->classCommonFunction->addUserRecentActivity('search',$search_term);
		}
    }
	else{
		$search_term = $param;
		//Save user recent search activity.
		if(is_frontend_user_logged_in()){
			$this->classCommonFunction->addUserRecentActivity('search',$search_term);
		}
	}
	if(isset($_GET['filter_by'])){
      $filter = $_GET['filter_by'];
    }
   
	if(isset($_GET['view_by'])){
      $view_by = $_GET['view_by'];
    }

    if(isset($_GET['price_min'])){
      $price_min = $_GET['price_min'];
    }

    if(isset($_GET['price_max'])){
      $price_max = $_GET['price_max'];
    }

    if(isset($_GET['selected_colors'])){
      $selected_colors = $_GET['selected_colors'];
    }

    if(isset($_GET['selected_sizes'])){
      $selected_sizes = $_GET['selected_sizes'];
    }

    $get_product  =  $this->product->getFilterProductsDataWithPagination(array('srch_term' => $search_term, 'sort' => $filter),$view_by);

    if(count($get_product) > 0){
      $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
      $data['brands_data']          =   $this->product->getTermData( 'product_brands', false, null, 1 );
      $data['advancedData']         =   $this->product->getAdvancedProducts();
      $data['colors_list_data']     =   $this->product->getTermData( 'product_colors', false, null, 1 );
      $data['sizes_list_data']      =   $this->product->getTermData( 'product_sizes', false, null, 1 );
      $data['all_products_details'] =   $get_product;
	  $data['search_term']  =  $search_term;
	  $data['view_by']  =  $view_by;
	  $data['filter_by']  =  $filter;
      if(count($data['all_products_details']) > 0){
        $data['all_products_details']['action_url'] = Request::url();

        $currentQuery = Request::query();

        if(count($currentQuery) > 0){
          if(isset($currentQuery['view'])){
            unset($currentQuery['view']);
          }

          if(count($currentQuery) > 0){
            $currentQuery['view'] = 'list';
            $data['all_products_details']['action_url_list_view'] = Request::url(). '?' . http_build_query($currentQuery);
            $currentQuery['view'] = 'grid';
            $data['all_products_details']['action_url_grid_view'] = Request::url(). '?' . http_build_query($currentQuery);
          }
          else{
            $data['all_products_details']['action_url_list_view'] = Request::url(). '?view=list';
            $data['all_products_details']['action_url_grid_view'] = Request::url(). '?view=grid';
          }
        }
        else{
          $data['all_products_details']['action_url_list_view'] = Request::url(). '?view=list';
          $data['all_products_details']['action_url_grid_view'] = Request::url(). '?view=grid';
        }

        if(isset($_GET['view']) && $_GET['view'] == 'list'){
          $data['all_products_details']['selected_view'] = 'list'; 
        }
        elseif(isset($_GET['view']) && $_GET['view'] == 'grid'){
          $data['all_products_details']['selected_view'] = 'grid'; 
        }
        else{
          $data['all_products_details']['selected_view'] = 'grid';
        }
      }
    
      return view('pages.frontend.frontend-pages.shop', $data);
    }
    else{
      return view('errors.no_data');
    }
  }
  
  /**
   * 
   * Product single page content
   *
   * @param null
   * @return void 
   */
  public function productSinglePageContent( $params ){
    
	  $saleModeStatus=0;
	  $manageStockStatus =0;
	 $user_filter_arr = ['products.status' => 1,'slug' => $params];
	 if(is_frontend_user_logged_in()){
		 $frontend_user_data = get_current_frontend_user_info();
		 
		 $dob =  new \DateTime($frontend_user_data['dob']);
		 $now =  new \DateTime();

		//Calculate the time difference between the two dates.
		$difference = $now->diff($dob);
				 
		//Get the difference in years, as we are looking for the user's age.
		$age = $difference->y;
		if($age < 19){
			 $user_filter_arr+= ['products.available_for_minors' => 'Y'];
		 }
	 }	  
    $get_product = Product::where( $user_filter_arr)->first();
	
	if(!empty($get_product)){
		 $saleModeStatus = $this->product->check_sale_mode($get_product->id);
		 $manageStockStatus = $this->product->check_manage_stock($get_product->id);
	}

    $rating ='';
    if(!empty($get_product) && $saleModeStatus == 1 &&  $manageStockStatus ==1){
      $data = array();
      $product_id  = $get_product->id;
      $get_current_user_data  =  get_current_frontend_user_info();	
	  if(isset($_GET['rating']))
	  {
		  $rating = $_GET['rating'];
	  }
	   $comments_rating_details =   get_comments_rating_details( $product_id, 'product',array('rating'=>$rating ));
	  //Save user recent product visit.
		if(is_frontend_user_logged_in()){
			$this->classCommonFunction->addUserRecentActivity('visit',$product_id);
		}

      $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
      $data['single_product_details']  =  $this->product->getProductDataById( $product_id ,'admin' );
      
	  	
	  //Condition to Get Government category Rules.
       if(isset($data['single_product_details']['_product_government_category_section_data'])){
			$govt_category_rule_array = convert_json_string_to_array($data['single_product_details']['_product_government_category_section_data']);
			$government_category_array =array();
			
			if(isset($govt_category_rule_array['jsonGovtCatTextFieldData']) && count($govt_category_rule_array['jsonGovtCatTextFieldData'])>0){
				$final_govt_category_array = array();
				
			  foreach($govt_category_rule_array['jsonGovtCatTextFieldData'] as $row){
				
				
				$government_category_name = DB::table('product_government_category_rules')
					->where(['id'=>$row['id']])
					->select(['field_name'])->get()->toArray();
					
				$government_category_array['name'] = isset($government_category_name[0]->field_name)?$government_category_name[0]->field_name:'';
				$government_category_array['value'] = $row['value'];
				 
				 array_push($final_govt_category_array,$government_category_array);
				
			  }
			 
			$data['govt_category_rule_array'] = $final_govt_category_array;
		  }
        }
	//echo '<pre>'; print_r($data['govt_category_rule_array']);echo '</pre>';exit;

      $data['single_product_details']['is_user_login']   = 'no';
      $data['single_product_details']['login_user_slug'] = '';

      if(is_frontend_user_logged_in()){
        $data['single_product_details']['is_user_login'] = 'yes';
      }

      if(count($get_current_user_data) > 0 && isset($get_current_user_data['user_role_slug'])){
        $data['single_product_details']['login_user_slug'] = $get_current_user_data['user_role_slug'];
      }

      if(Cookie::has('shopist_multi_currency')){
        $current_currency_name = get_current_currency_name();
        $to_currency    =  Cookie::get('shopist_multi_currency');
      }

      $product_url = default_placeholder_img_src();
	  
      $data['product_zoom_image'] = $product_url;

      if($data['single_product_details']['_product_related_images_url']->product_image){
        $product_url = $data['single_product_details']['_product_related_images_url']->product_image;
        $data['product_zoom_image'] = $this->classCommonFunction->createZoomImageUrl( $product_url );
      }
	//print_r($data['product_zoom_image']);exit;
      $data['single_product_details']['_product_related_images_url']->product_image = $product_url;
	

      $product = (object) array('id' => time(), 'url' => $product_url);
      //$data['single_product_details']['_product_related_images_url']->product_gallery_images[0] = $product;
		
      $gallery_images = $data['single_product_details']['_product_related_images_url']->product_gallery_images;
      if(count($gallery_images) > 0){
        foreach($gallery_images as $images){
          $images->zoom_img_url = $this->classCommonFunction->createZoomImageUrl( $images->url );
        }
      }

		/** Custom code to merge all images of product **/
		@$productMainImage = (!empty($data['product_zoom_image']))?array($data['product_zoom_image']) : array(); 
		@$productGalleryImages = array_column($gallery_images, 'zoom_img_url');
		@$productGalleryImages = (!empty($productGalleryImages))?$productGalleryImages : array(); 
		@$data['single_product_details']['productAllImages']  = array_merge($productMainImage, $productGalleryImages);
			 
			
		
      $data['attr_lists']               =   $this->product->getAllAttributes( $product_id );
      $data['related_items']            =   $this->product->getRelatedItems( $product_id );  
      $data['related_seller_items']     =   $this->product->getRelatedSellersItems( $product_id );  
      $data['comments_details']         =   get_comments_data_by_object_id( $product_id, 'product' );
	  $data['comments_rating_details']  =   $comments_rating_details;
	  
     
	 
	  if(is_frontend_user_logged_in()){
			$data['user_support_ticket'] = SupportTicket::where( ['product_id' => $product_id,'user_id' => $get_current_user_data['user_id']] )->get()->toArray();
	  }
      $data['vendor_reviews_rating_details']  =   get_comments_rating_details( get_vendor_id_by_product_id($product_id), 'vendor');
	

      $get_seo_data = get_seo_data();

      if(isset($get_seo_data['meta_tag']['meta_keywords']) && isset($data['single_product_details']['_product_seo_keywords'])){
        $data['single_product_details']['meta_keywords'] = trim( trim($get_seo_data['meta_tag']['meta_keywords'], ','). ',' .trim($data['single_product_details']['_product_seo_keywords'], ','), ',');
      }
      elseif(!isset($get_seo_data['meta_tag']['meta_keywords']) && isset($data['single_product_details']['_product_seo_keywords'])){
        $data['single_product_details']['meta_keywords'] = trim($data['single_product_details']['_product_seo_keywords'], ',');
      }
      elseif(isset($get_seo_data['meta_tag']['meta_keywords']) && !isset($data['single_product_details']['_product_seo_keywords'])){
        $data['single_product_details']['meta_keywords'] = trim($get_seo_data['meta_tag']['meta_keywords'], ',');
      }
      else{
        $data['single_product_details']['meta_keywords'] = null;
      }

      $data['upsell_products'] = get_upsell_products( $product_id );
      $get_variation_data = get_product_variations_with_data( $product_id );
      
      if(count($get_variation_data) > 0){
        $variation_data = array();
        
        foreach($get_variation_data as $row){
          if(isset($row['_variation_post_price'])){
            $row['_variation_post_price'] = price_html( get_product_price_html_by_filter(get_role_based_price_by_product_id($row['id'], $row['_variation_post_price'])), get_frontend_selected_currency());
          }
          
          $get_current_user_data  =  get_current_frontend_user_info();
    
          if(is_frontend_user_logged_in() && isset($get_current_user_data['user_role_slug']) ){
            if($row['_is_role_based_pricing_enable'] == true){
              if(isset($row['_role_based_pricing_array'][$get_current_user_data['user_role_slug']])){
                $regular_price =  $row['_role_based_pricing_array'][$get_current_user_data['user_role_slug']]['regular_price'];
                $sale_price    =  $row['_role_based_pricing_array'][$get_current_user_data['user_role_slug']]['sale_price'];
                
                $row['regular_price_comp_val'] = $regular_price;
                $row['sales_price_comp_val']   = $sale_price;
                
                $row['regular_price'] = price_html( get_product_price_html_by_filter(get_role_based_price_by_product_id($row['id'], $regular_price)), get_frontend_selected_currency());
                $row['sales_price']   = price_html( get_product_price_html_by_filter(get_role_based_price_by_product_id($row['id'], $sale_price)), get_frontend_selected_currency());
              }
            }
          } 
          
          array_push($variation_data, $row);
        }
         
        $data['variations_data'] = $variation_data;
      }
      else{
        $data['variations_data'] = $get_variation_data;
      }
		$data['rating']  =  $rating;//print_r($data);
      return view('pages.frontend.frontend-pages.product-details', $data);
    }
    else{
      return view('errors.no_data');
    }
  }
  
  /**
   * 
   * Checkout page content
   *
   * @param null
   * @return void 
   */
  public function checkoutPageContent( $params=''){
    $data = array();
    $vendor_details  = array();
    $is_user_login = false;
	$nomination=$address_1=$address_2=$address_3=$secondary_contact=$primary_contact='';
    $get_user_login_data = get_current_frontend_user_info();
	
    $user_account_parse_data = null;
    $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
	$data['frontend_account_address'] = UserShippingAddress::where( ['user_id' => $get_user_login_data['user_id']] )->orderBy('mark_default', 'DESC')->get()->toArray();
	if(!empty($params)){
		$get_product = Product::where(['slug' => $params])->first();
		$data['single_product_id']  = $get_product->id;
	}

    if(Session::has('shopist_frontend_user_id') && isset($get_user_login_data['user_id'])){
      $is_user_login = true;
      $get_data_by_user_id     =  get_user_account_details_by_user_id( $get_user_login_data['user_id'] ); 
      $get_array_shift_data    =  array_shift($get_data_by_user_id);
      $user_account_parse_data =  json_decode($get_array_shift_data['details']);

      if(!empty($user_account_parse_data)){
        $user_account_parse_data = $user_account_parse_data;
      }
    }

    $data['is_user_login'] = $is_user_login;
    $data['login_user_account_data'] = $user_account_parse_data;
    $data['_settings_data']   = $this->option->getSettingsData();
   
    $cart_data = array();
	$userAddress = 0;
	$i=0;
	$vendor_list_order_price = array();
	if($this->cart->getItems()->count() > 0){
		$zipcode=0;
		if(isset($_GET['address_1']))
		{
			$zipcode=$_GET['address_1'];
			$nomination = '';
			$address_1 = $_GET['address_1'];
			$address_2 = $_GET['address_2'];
			$address_3 = $_GET['address_3'];
			$primary_contact = '';
			$secondary_contact = '';
		}
		else
		{
			if(isset($_GET['userAddress']))
			{
				$shipping_address = DB::table('user_shipping_address')->select('*')->where('id',$_GET['userAddress'])->get()->toArray();
			}
			else
			{
				$shipping_address = $this->classCommonFunction->getUserDefaultAddress(Session::get('shopist_frontend_user_id'));
			}
			if(isset($shipping_address[0]->zipcode))
			{
				$zipcode=$shipping_address[0]->zipcode;
				$userAddress = $shipping_address[0]->id;
				$nomination = $shipping_address[0]->nomination;
				$address_1 = $shipping_address[0]->zipcode;
				$address_2 = $shipping_address[0]->address_line_1;
				$address_3 = $shipping_address[0]->address_line_2;
				$primary_contact = $shipping_address[0]->primary_contact;
				$secondary_contact = $shipping_address[0]->secondary_contact;
			}
			
		}
		$data['userAddress']=$userAddress;
		$data['nomination']=$nomination;
		$data['address_1']=$address_1;
		$data['address_2']=$address_2;
		$data['address_3']=$address_3;
		$data['primary_contact']=$primary_contact;
		$data['secondary_contact']=$secondary_contact;
		
		foreach($this->cart->getItems() as $key => $rr)
		{
			if(!isset($data['single_product_id']) || (isset($data['single_product_id']) && $rr->product_id==$data['single_product_id']))
			{
				$price = $this->classCommonFunction->getProductPrice($rr->product_id,$rr->options['required_option'],$rr->options['option_option'],$rr->quantity);
				if($price!='out_of_stock')
				{
					
					$cart_data[$i]['id'] = $rr->id;
					$cart_data[$i]['key'] = $key;
					$cart_data[$i]['vendor_id'] = $rr->vendor_id;
					$cart_data[$i]['product_id'] = $rr->product_id;
					$cart_data[$i]['name'] = $rr->name;
					$cart_data[$i]['quantity'] = $rr->quantity;
					$cart_data[$i]['description'] = $price['description'];
					$cart_data[$i]['price'] = $price['price'];
					$cart_data[$i]['order_price'] = get_product_price_html_by_filter($price['price']);
					$cart_data[$i]['discount'] = $price['discount'];
					$cart_data[$i]['img_src'] = $rr->img_src;
					$cart_data[$i]['options'] = $rr->options;
					$cart_data[$i]['product_type'] = $rr->product_type;
					$cart_data[$i]['product_tax'] = $price['product_tax'];
					$cart_data[$i]['tax_amount'] = 0;
					if($price['product_tax']=='taxation')
					{
						$tax_amount = ($price['price']*9.09)/100;
						$tax_amount = number_format((float)$tax_amount, 2, '.', '');
						$cart_data[$i]['tax_amount'] = $tax_amount;
					}
					$cart_data[$i]['shipping_cost'] = $this->classCommonFunction->getProductShippingCost($rr->product_id,$rr->quantity,$zipcode,$price['price']);
					$i++;
					$vendor_id=$rr->vendor_id;
					if(isset($vendor_list_order_price[$vendor_id]['order_price']))
					{
						$vendor_list_order_price[$vendor_id]['order_price']=$vendor_list_order_price[$rr->vendor_id]['order_price']+$price['price'];
						array_push($vendor_list_order_price[$vendor_id]['product'],$rr->product_id);
					}
					else
					{
						$vendor_list_order_price[$vendor_id]['order_price']=$price['price'];
						$vendor_list_order_price[$vendor_id]['product']=array();
						array_push($vendor_list_order_price[$vendor_id]['product'],$rr->product_id);
					}
					
				}
				else
				{
					$this->cart->clear();
				}
			}
	  }
	}
	// check bundle price apply or not
	if(count($cart_data)>1)
	{
		foreach($cart_data as $key => $rr)
		{
			$response = $this->classCommonFunction->setFreeShippingCostBasedBundlePrice($vendor_list_order_price,$rr['id'],$rr['vendor_id']);
			if($response)
			{
				$cart_data[$key]['shipping_cost']=0;
			}
		}
	}
	$data['cart_data']=$cart_data;
	$data['user_wallet']=$get_user_login_data['my_wallet'];
    return view('pages.frontend.frontend-pages.checkout', $data);
  }
  
  /**
   * 
   * Cart page content
   *
   * @param null
   * @return void 
   */
  public function cartPageContent(){
    $data = array();
	$result = $this->classCommonFunction->get_dynamic_frontend_content_data();
	$i=0;
	if($this->cart->getItems()->count() > 0){
		$vendor_list_order_price = array();
		$shipping_address = $this->classCommonFunction->getUserDefaultAddress(Session::get('shopist_frontend_user_id'));
      foreach($this->cart->getItems() as $key => $rr)
	  {
			$price = $this->classCommonFunction->getProductPrice($rr->product_id,$rr->options['required_option'],$rr->options['option_option'],$rr->quantity);
			if($price!='out_of_stock')
			{
				
				$data[$i]['id'] = $rr->id;
				$data[$i]['key'] = $key;
				$data[$i]['vendor_id'] = $rr->vendor_id;
				$data[$i]['product_id'] = $rr->product_id;
				$data[$i]['name'] = $rr->name;
				$data[$i]['quantity'] = $rr->quantity;
				$data[$i]['description'] = $price['description'];
				$data[$i]['price'] = $price['price'];
				$data[$i]['order_price'] = get_product_price_html_by_filter($price['price']);
				$data[$i]['discount'] = $price['discount'];
				$data[$i]['img_src'] = $rr->img_src;
				$data[$i]['options'] = $rr->options;
				$data[$i]['product_type'] = $rr->product_type;
				$data[$i]['product_tax'] = $price['product_tax'];
				$zipcode=0;
				if(isset($shipping_address[0]->zipcode))
				{
					$zipcode=$shipping_address[0]->zipcode;
				}
				$data[$i]['shipping_cost'] = $this->classCommonFunction->getProductShippingCost($rr->product_id,$rr->quantity,$zipcode,$price['price']);
				$i++;
				$vendor_id=$rr->vendor_id;
				if(isset($vendor_list_order_price[$vendor_id]['order_price']))
				{
					$vendor_list_order_price[$vendor_id]['order_price']=$vendor_list_order_price[$rr->vendor_id]['order_price']+$price['price'];
					array_push($vendor_list_order_price[$vendor_id]['product'],$rr->product_id);
				}
				else
				{
					$vendor_list_order_price[$vendor_id]['order_price']=$price['price'];
					$vendor_list_order_price[$vendor_id]['product']=array();
					array_push($vendor_list_order_price[$vendor_id]['product'],$rr->product_id);
				}
			}
			else
			{
				$this->cart->clear();
			}
	  }
	}
	// check bundle price apply or not
	if(count($data)>1)
	{
		foreach($data as $key => $rr)
		{
			$response = $this->classCommonFunction->setFreeShippingCostBasedBundlePrice($vendor_list_order_price,$rr['id'],$rr['vendor_id']);
			if($response)
			{
				$data[$key]['shipping_cost']=0;
			}
		}
	}
	$result['data']=$data;
    return view('pages.frontend.frontend-pages.cart', $result);
  }
  
  /**
   * 
   * Blogs page content
   *
   * @param null
   * @return void 
   */
  public function blogsPageContent(){
    $data = array();
    
    $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
    $data['blogs_all_data']  =   get_all_blogs_data(1);
    $data['categoriesTree']  =   $this->product->get_categories(0, 'blog_cat');
    $data['advanced_data']   =   $this->CMS->get_blog_advanced_data();
     
    return view('pages.frontend.frontend-pages.blogs-main', $data);
  }
  
  /**
   * 
   * Blog categories page content
   *
   * @param null
   * @return void 
   */
  public function blogCategoriesPageContent( $params ){
    $data = array();
    
    $get_cat_post  =   $this->CMS->getBlogPostByCatSlug( $params );
      
    if(count($get_cat_post) > 0){
      $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
      $data['blogs_cat_post']  =   $get_cat_post;
      $data['advanced_data']   =   $this->CMS->get_blog_advanced_data();
      $data['categoriesTree']  =   $this->product->get_categories(0, 'blog_cat');
      
      return view('pages.frontend.frontend-pages.blog-categories-post', $data);
    }
    else{
      return view('errors.no_data');
    }
  }
  
  /**
   * 
   * Single page content
   *
   * @param null
   * @return void 
   */
  public function singlePageContent( $params ){
    $data = array();
    $get_page_by_filter = Post :: where(['post_slug' => $params, 'post_status' => 1, 'post_type' => 'page'])->first();

    if(!empty($get_page_by_filter)){
      $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
      $data['page_data'] = $get_page_by_filter;
      
      return view('pages.frontend.frontend-pages.custom-single-page', $data);
    }
    else{
      return view('errors.no_data');
    }
  }
  
  /**
   * 
   * Multivendor store list page content
   *
   * @param null
   * @return void 
   */
  public function multivendorStoreListPageContent(){
    $data = array();
    
    $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
    $data['vendors_list'] = $this->vendors->getAllVendors( false, null, 1 );
    
    return view('pages.frontend.vendors.vendors-list', $data);
  }
  
  /**
   * 
   * Multivendor store single page home content
   *
   * @param null
   * @return void 
   */
  public function multivendorStoreSinglePageHomeContent( $params = 'all' ){
    $data = array();
    $user = $params;
	$search_term = null;
	$user_id= null;
	$get_user = null;
	$view = 20;
	$filter = '';
	 if(isset($_GET['view_by'])){
      $view = $_GET['view_by'];
    }
	 if(isset($_GET['filter_by'])){
      $filter = $_GET['filter_by'];
    }
	if(isset($user) && !empty($user) && $user != 'all' )
	{
		$get_user = User::where(['name' => $user, 'user_status' => 1])->first();
		$user_id=$get_user['id'];
	}
	else if($user == 'all'){
		$get_user = 'all';
	}
	
    if(empty($get_user)){
      return view('errors.vendor_not_active');
    }
	 
    $get_product = $this->product->getFilterProductsDataWithPagination(array('srch_term' => $search_term, 'sort' => $filter, 'author_id' => $user_id ),$view);
	
    $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
	$data['all_products_details'] =   $get_product;
    $data['vendor_settings'] = null;
    $data['vendor_selected_cats_id'] = array();
	$data['view_by'] = $view;
	$data['filter_by'] = $filter;
    $get_user = User::where(['name' => $user])->first();
	
    if(!empty($get_user)){
      /*if(is_vendor_expired( $get_user->id )){
        return view('errors.vendor_expired');
      }
      
      $data['vendor_package_details'] = get_package_details_by_vendor_id($get_user->id);
      $data['vendor_settings'] = null;*/
      $get_user_details = null;
      $user_details = get_user_account_details_by_user_id( $get_user->id );

      if(count($user_details) > 0){
        $get_user_details = json_decode($user_details[0]['details']);
      } 

     
      $data['vendor_info'] = $get_user;
      $data['vendor_settings'] = $get_user_details;
     
      return view('pages.frontend.vendors.vendor-details', $data);
    }
    else{
      return view('pages.frontend.vendors.vendor-details', $data);
    }
  }
  
  /**
   * 
   * Multivendor store single page products content
   *
   * @param null
   * @return void 
   */
  public function multivendorStoreSinglePageProductsContent( $params ){
    $data = array();
    $user = $params;
    
    $get_user = User::where(['name' => $user, 'user_status' => 1])->first();
    if(empty($get_user)){
      return view('errors.vendor_not_active');
    }
    
    $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
    $data['vendor_settings'] = null;
    $data['vendor_selected_cats_id'] = array();
    
    $get_user = User::where(['name' => $user])->first();
    if(!empty($get_user)){
      if(is_vendor_expired( $get_user->id )){
        return view('errors.vendor_expired');
      }
      
      $data['vendor_package_details'] = get_package_details_by_vendor_id($get_user->id);
      $data['vendor_settings'] = null;
      $get_user_details = null;
      $user_details = get_user_account_details_by_user_id( $get_user->id );

      if(count($user_details) > 0){
        $get_user_details = json_decode($user_details[0]['details']);
      } 

      $data['vendor_info'] = $get_user;
      $data['vendor_settings'] = $get_user_details;
      
      $get_global_seo = get_seo_data();
      $store_seo = $get_user_details->seo;

      $data['store_seo_meta_keywords'] = null;
      $data['store_seo_meta_description'] = null;

      if(isset($get_global_seo['meta_tag']['meta_keywords']) && !empty($store_seo->meta_keywords)){
        $data['store_seo_meta_keywords'] = trim($get_global_seo['meta_tag']['meta_keywords'].', '.$store_seo->meta_keywords, ',');
      }
      elseif(isset($get_global_seo['meta_tag']['meta_keywords']) && empty($store_seo->meta_keywords)){
        $data['store_seo_meta_keywords'] = $get_global_seo['meta_tag']['meta_keywords'];
      }
      else{
        $data['store_seo_meta_keywords'] = $store_seo->meta_keywords;
      }

      if(!empty($store_seo->meta_decription)){
        $data['store_seo_meta_description'] = $store_seo->meta_decription;
      }
      
      $data['vendor_home_page_cats'] = array();
      if(!empty($get_user_details->general_details->vendor_home_page_cats)){
        $vendor_home_cats = json_decode($get_user_details->general_details->vendor_home_page_cats);
        
        if(count($vendor_home_cats) > 0){
          foreach($vendor_home_cats as $cat){
            $explod_val = explode('#', $cat);
            $get_id = end($explod_val);
            $parent_cat = $this->product->getTermDataById( $get_id );
            array_push($data['vendor_selected_cats_id'], $get_id);
            array_push($data['vendor_home_page_cats'], array('parent_cat' => array_shift($parent_cat), 'child_cat' => $this->product->get_categories($get_id, 'product_cat')));
          }
        }
      }

      $data['vendor_advanced_items'] = $this->product->getVendorAdvancedProducts( $get_user->id );
      $data['vendor_reviews_rating_details']  =  get_comments_rating_details( $get_user->id, 'vendor' );
      
      //
      $sort = null;
      $price_min = null;
      $price_max = null;
      $selected_colors = null;
      $selected_sizes = null;

      if(isset($_GET['sort_by'])){
        $sort = $_GET['sort_by'];
      }

      if(isset($_GET['price_min'])){
        $price_min = $_GET['price_min'];
      }

      if(isset($_GET['price_max'])){
        $price_max = $_GET['price_max'];
      }

      if(isset($_GET['selected_colors'])){
        $selected_colors = $_GET['selected_colors'];
      }

      if(isset($_GET['selected_sizes'])){
        $selected_sizes = $_GET['selected_sizes'];
      }

      $data['popular_tags_list']  =   $this->product->getTermData( 'product_tag', false, null, 1 );
      $data['colors_list_data']   =   $this->product->getTermData( 'product_colors', false, null, 1 );
      $data['sizes_list_data']    =   $this->product->getTermData( 'product_sizes', false, null, 1 );

      $get_product = $this->product->getProductsByUserId( $get_user->id, $params, array('sort' => $sort, 'price_min' => $price_min, 'price_max' => $price_max, 'selected_colors' => $selected_colors, 'selected_sizes' => $selected_sizes) );

      if(count($get_product) > 0){
        $data['vendor_products'] = $get_product;

        if(count($data['vendor_products']) > 0){
          $data['vendor_products']['action_url'] = Request::url();

          $currentQuery = Request::query();

          if(count($currentQuery) > 0){
            if(isset($currentQuery['view'])){
              unset($currentQuery['view']);
            }

            if(count($currentQuery) > 0){
              $currentQuery['view'] = 'list';
              $data['vendor_products']['action_url_list_view'] = Request::url(). '?' . http_build_query($currentQuery);
              $currentQuery['view'] = 'grid';
              $data['vendor_products']['action_url_grid_view'] = Request::url(). '?' . http_build_query($currentQuery);
            }
            else{
              $data['vendor_products']['action_url_list_view'] = Request::url(). '?view=list';
              $data['vendor_products']['action_url_grid_view'] = Request::url(). '?view=grid';
            }
          }
          else{
            $data['vendor_products']['action_url_list_view'] = Request::url(). '?view=list';
            $data['vendor_products']['action_url_grid_view'] = Request::url(). '?view=grid';
          }

          if(isset($_GET['view']) && $_GET['view'] == 'list'){
            $data['vendor_products']['selected_view'] = 'list'; 
          }
          elseif(isset($_GET['view']) && $_GET['view'] == 'grid'){
            $data['vendor_products']['selected_view'] = 'grid'; 
          }
          else{
            $data['vendor_products']['selected_view'] = 'grid';
          }
        }
      }
      else{
        return view('errors.no_data');
      }
      
      return view('pages.frontend.vendors.vendor-details', $data);
    }
    else{
      return view('errors.no_data');
    }
  }
  
  /**
   * 
   * Multivendor store single page review content
   *
   * @param null
   * @return void 
   */
  public function multivendorStoreSinglePageReviewContent( $params ){
    $data = array();
    $user = $params;
    
    $get_user = User::where(['name' => $user, 'user_status' => 1])->first();
    if(empty($get_user)){
      return view('errors.vendor_not_active');
    }
    
    $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
    $data['vendor_settings'] = null;
    $data['vendor_selected_cats_id'] = array();
    
    $get_user = User::where(['name' => $user])->first();
    if(!empty($get_user)){
      if(is_vendor_expired( $get_user->id )){
        return view('errors.vendor_expired');
      }
      
      $data['vendor_package_details'] = get_package_details_by_vendor_id($get_user->id);
      $data['vendor_settings'] = null;
      $get_user_details = null;
      $user_details = get_user_account_details_by_user_id( $get_user->id );

      if(count($user_details) > 0){
        $get_user_details = json_decode($user_details[0]['details']);
      } 

      $data['vendor_info'] = $get_user;
      $data['vendor_settings'] = $get_user_details;
      
      $get_global_seo = get_seo_data();
      $store_seo = $get_user_details->seo;

      $data['store_seo_meta_keywords'] = null;
      $data['store_seo_meta_description'] = null;

      if(isset($get_global_seo['meta_tag']['meta_keywords']) && !empty($store_seo->meta_keywords)){
        $data['store_seo_meta_keywords'] = trim($get_global_seo['meta_tag']['meta_keywords'].', '.$store_seo->meta_keywords, ',');
      }
      elseif(isset($get_global_seo['meta_tag']['meta_keywords']) && empty($store_seo->meta_keywords)){
        $data['store_seo_meta_keywords'] = $get_global_seo['meta_tag']['meta_keywords'];
      }
      else{
        $data['store_seo_meta_keywords'] = $store_seo->meta_keywords;
      }

      if(!empty($store_seo->meta_decription)){
        $data['store_seo_meta_description'] = $store_seo->meta_decription;
      }
      
      $data['comments_details']               =  get_comments_data_by_object_id( $get_user->id, 'vendor' );
      $data['comments_rating_details']        =  get_comments_rating_details( $get_user->id, 'vendor' );
      $data['vendor_reviews_rating_details']  =  get_comments_rating_details( $get_user->id, 'vendor' );
      $data['user_name']                      =  $user;
      
      return view('pages.frontend.vendors.vendor-details', $data);
    }
    else{
      return view('errors.no_data');
    }
  }
  
  /**
   * 
   * Multivendor store single page products categories content
   *
   * @param null
   * @return void 
   */
  public function multivendorStoreSinglePageProductsCatContent( $params, $params1 ){
    $data = array();
    $user = $params1;
    
    $get_user = User::where(['name' => $user, 'user_status' => 1])->first();
    if(empty($get_user)){
      return view('errors.vendor_not_active');
    }
    
    $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
    $data['vendor_settings'] = null;
    $data['vendor_selected_cats_id'] = array();
    
    $get_user = User::where(['name' => $user])->first();
    if(!empty($get_user)){
      if(is_vendor_expired( $get_user->id )){
        return view('errors.vendor_expired');
      }
      
      $data['vendor_package_details'] = get_package_details_by_vendor_id($get_user->id);
      $data['vendor_settings'] = null;
      $get_user_details = null;
      $user_details = get_user_account_details_by_user_id( $get_user->id );

      if(count($user_details) > 0){
        $get_user_details = json_decode($user_details[0]['details']);
      } 

      $data['vendor_info'] = $get_user;
      $data['vendor_settings'] = $get_user_details;
      
      $get_global_seo = get_seo_data();
      $store_seo = $get_user_details->seo;

      $data['store_seo_meta_keywords'] = null;
      $data['store_seo_meta_description'] = null;

      if(isset($get_global_seo['meta_tag']['meta_keywords']) && !empty($store_seo->meta_keywords)){
        $data['store_seo_meta_keywords'] = trim($get_global_seo['meta_tag']['meta_keywords'].', '.$store_seo->meta_keywords, ',');
      }
      elseif(isset($get_global_seo['meta_tag']['meta_keywords']) && empty($store_seo->meta_keywords)){
        $data['store_seo_meta_keywords'] = $get_global_seo['meta_tag']['meta_keywords'];
      }
      else{
        $data['store_seo_meta_keywords'] = $store_seo->meta_keywords;
      }

      if(!empty($store_seo->meta_decription)){
        $data['store_seo_meta_description'] = $store_seo->meta_decription;
      }
      
      $data['vendor_home_page_cats'] = array();
      if(!empty($get_user_details->general_details->vendor_home_page_cats)){
        $vendor_home_cats = json_decode($get_user_details->general_details->vendor_home_page_cats);
        
        if(count($vendor_home_cats) > 0){
          foreach($vendor_home_cats as $cat){
            $explod_val = explode('#', $cat);
            $get_id = end($explod_val);
            $parent_cat = $this->product->getTermDataById( $get_id );
            array_push($data['vendor_selected_cats_id'], $get_id);
            array_push($data['vendor_home_page_cats'], array('parent_cat' => array_shift($parent_cat), 'child_cat' => $this->product->get_categories($get_id, 'product_cat')));
          }
        }
      }

      $data['vendor_advanced_items'] = $this->product->getVendorAdvancedProducts( $get_user->id );
      $data['vendor_reviews_rating_details']  =  get_comments_rating_details( $get_user->id, 'vendor' );
      
      //
      $sort = null;
      $price_min = null;
      $price_max = null;
      $selected_colors = null;
      $selected_sizes = null;
      
      if(isset($_GET['sort_by'])){
        $sort = $_GET['sort_by'];
      }
      
      if(isset($_GET['price_min'])){
        $price_min = $_GET['price_min'];
      }
      
      if(isset($_GET['price_max'])){
        $price_max = $_GET['price_max'];
      }
      
      if(isset($_GET['selected_colors'])){
        $selected_colors = $_GET['selected_colors'];
      }

      if(isset($_GET['selected_sizes'])){
        $selected_sizes = $_GET['selected_sizes'];
      }
      
			$data['popular_tags_list']  =   $this->product->getTermData( 'product_tag', false, null, 1 );
      $data['colors_list_data']   =   $this->product->getTermData( 'product_colors', false, null, 1 );
      $data['sizes_list_data']    =   $this->product->getTermData( 'product_sizes', false, null, 1 );
										
      $get_cat_product_and_breadcrumb  =  $this->product->getProductByCatSlug($params, array());
      
      if(count($get_cat_product_and_breadcrumb) > 0){
        $data['vendor_products'] = $get_cat_product_and_breadcrumb;
      }
      else{
        return view('errors.no_data');
      }
      
       
      if(count($data['vendor_products']) > 0){
        $data['vendor_products']['action_url'] = Request::url();
        
        $currentQuery = Request::query();
        
        if(count($currentQuery) > 0){
          if(isset($currentQuery['view'])){
            unset($currentQuery['view']);
          }
          
          if(count($currentQuery) > 0){
            $currentQuery['view'] = 'list';
            $data['vendor_products']['action_url_list_view'] = Request::url(). '?' . http_build_query($currentQuery);
            $currentQuery['view'] = 'grid';
            $data['vendor_products']['action_url_grid_view'] = Request::url(). '?' . http_build_query($currentQuery);
          }
          else{
            $data['vendor_products']['action_url_list_view'] = Request::url(). '?view=list';
            $data['vendor_products']['action_url_grid_view'] = Request::url(). '?view=grid';
          }
        }
        else{
          $data['vendor_products']['action_url_list_view'] = Request::url(). '?view=list';
          $data['vendor_products']['action_url_grid_view'] = Request::url(). '?view=grid';
        }
        
        if(isset($_GET['view']) && $_GET['view'] == 'list'){
          $data['vendor_products']['selected_view'] = 'list'; 
        }
        elseif(isset($_GET['view']) && $_GET['view'] == 'grid'){
          $data['vendor_products']['selected_view'] = 'grid'; 
        }
        else{
          $data['vendor_products']['selected_view'] = 'grid';
        }
      }
      
      return view('pages.frontend.vendors.vendor-details', $data);
    }
    else{
      return view('errors.no_data');
    }
  }
  
  /**
   * 
   * Product comparison page content
   *
   * @param null
   * @return void 
   */
  public function productComparisonPageContent(){
    $data = array();
    
    $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
    $data['compare_product_data']  = array();
    $data['compare_product_label'] = null;

    $compare_data     =  $this->option->getProductCompareData();
    $custom_data      =  array('Image', 'Product', 'Price');

    if(!empty($compare_data)){
      $data['compare_product_label'] = (object) array_merge($custom_data, (array) $compare_data);
    }
    else{
      $data['compare_product_label'] = (object) $custom_data;
    }

    if(Session::has('shopist_selected_compare_product_ids') && count(Session::get('shopist_selected_compare_product_ids')) > 0){
      $get_comparison_product = Session::get('shopist_selected_compare_product_ids');

      foreach($get_comparison_product as $product){
        array_push($data['compare_product_data'],	$this->product->getProductDataById( $product ));
      }
    }
    
    return view('pages.frontend.frontend-pages.product-comparison', $data);
  }
  
  /**
   * 
   * Tag single page content
   *
   * @param null
   * @return void 
   */
  public function tagSinglePageContent( $params ){
    $data = array();
    $get_tag_by_slug = get_products_by_product_tag_slug( $params );
      
    if(count($get_tag_by_slug) > 0){
      $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
      $data['tag_single_details']  =  $get_tag_by_slug;
      $data['popular_tags_list']   =  $this->product->getTermData( 'product_tag', false, null, 1 );
      
      return view('pages.frontend.frontend-pages.tag-single-page', $data);
    }
    else{
      return view('errors.no_data');
    }
  }
  
  /**
   * 
   * Designer single page content
   *
   * @param null
   * @return void 
   */
  public function designerSinglePageContent( $params ){
    $get_product = Product::where(['slug' => $params, 'status' => 1])->first();
      
    if(!empty($get_product)){
      $data = array();
      $product_id  = $get_product->id;
      $get_product_type = get_product_type($product_id);
      
      if($get_product_type == 'customizable_product'){
        $get_current_user_data  =  get_current_frontend_user_info();

        $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
        $data['single_product_details']  =  $this->product->getProductDataById( $product_id );

        if(is_frontend_user_logged_in() && isset($get_current_user_data['user_role_slug']) && $data['single_product_details']['_is_role_based_pricing_enable'] == 'yes'){
          if(isset($data['single_product_details']['_role_based_pricing'][$get_current_user_data['user_role_slug']])){

            $regular_price = $data['single_product_details']['_role_based_pricing'][$get_current_user_data['user_role_slug']]['regular_price'];
            $sale_price = $data['single_product_details']['_role_based_pricing'][$get_current_user_data['user_role_slug']]['sale_price'];

            if(isset($regular_price) && $regular_price && isset($sale_price) && $sale_price && $regular_price > $sale_price){
              $data['single_product_details']['offer_price'] = get_product_price_html_by_filter($regular_price);
              $data['single_product_details']['solid_price'] = get_product_price_html_by_filter($sale_price);
            }
            elseif(isset($regular_price) && $regular_price){
              $data['single_product_details']['offer_price'] = null;
              $data['single_product_details']['solid_price'] = get_product_price_html_by_filter($regular_price);
            }
            else{
              $data['single_product_details']['offer_price'] = null;
              $data['single_product_details']['solid_price'] = 0;
            }
          }
        }  
        else{
          if($data['single_product_details']['post_regular_price'] && $data['single_product_details']['post_regular_price'] >0 && $data['single_product_details']['post_sale_price'] && $data['single_product_details']['post_sale_price']>0 && $data['single_product_details']['post_regular_price'] > $data['single_product_details']['post_sale_price'] ){
            $data['single_product_details']['offer_price'] = get_product_price_html_by_filter($data['single_product_details']['post_regular_price']);
          }
          else{
            $data['single_product_details']['offer_price'] = null;
          }

          $data['single_product_details']['solid_price']   = get_product_price_html_by_filter($data['single_product_details']['post_price']);
        }


        $data['single_product_details']['is_user_login']   = 'no';
        $data['single_product_details']['login_user_slug'] = '';

        if(is_frontend_user_logged_in()){
          $data['single_product_details']['is_user_login'] = 'yes';
        }

        if(count($get_current_user_data) > 0 && isset($get_current_user_data['user_role_slug'])){
          $data['single_product_details']['login_user_slug'] = $get_current_user_data['user_role_slug'];
        }

        if(Cookie::has('shopist_multi_currency')){
          $current_currency_name = get_current_currency_name();
          $to_currency    =  Cookie::get('shopist_multi_currency');
        }

        $product_url = default_placeholder_img_src();
        $data['product_zoom_image'] = $product_url;

        if($data['single_product_details']['_product_related_images_url']->product_image){
          $product_url = $data['single_product_details']['_product_related_images_url']->product_image;
          $data['product_zoom_image'] = $this->classCommonFunction->createZoomImageUrl( $product_url );
        }

        $data['single_product_details']['_product_related_images_url']->product_image = $product_url;


        $product = (object) array('id' => time(), 'url' => $product_url);
        $data['single_product_details']['_product_related_images_url']->product_gallery_images[0] = $product;

        $gallery_images = $data['single_product_details']['_product_related_images_url']->product_gallery_images;
        if(count($gallery_images) > 0){
          foreach($gallery_images as $images){
            $images->zoom_img_url = $this->classCommonFunction->createZoomImageUrl( $images->url );
          }
        }

        $data['attr_lists']               =   $this->product->getAllAttributes( $product_id );
        $data['related_items']            =   $this->product->getRelatedItems( $product_id );  
        $data['comments_details']         =   get_comments_data_by_object_id( $product_id, 'product' );
        $data['comments_rating_details']  =   get_comments_rating_details( $product_id, 'product' );
        $data['vendor_reviews_rating_details']  =   get_comments_rating_details( get_vendor_id_by_product_id($product_id), 'vendor' );
        $data['fonts_list']               =   $this->product->getFontsList( false, null, 1 );
        $data['shape_list']               =   $this->product->getShapeList( false, null, 1 );


        $get_seo_data = get_seo_data();

        if(isset($get_seo_data['meta_tag']['meta_keywords']) && isset($data['single_product_details']['_product_seo_keywords'])){
          $data['single_product_details']['meta_keywords'] = trim( trim($get_seo_data['meta_tag']['meta_keywords'], ','). ',' .trim($data['single_product_details']['_product_seo_keywords'], ','), ',');
        }
        elseif(!isset($get_seo_data['meta_tag']['meta_keywords']) && isset($data['single_product_details']['_product_seo_keywords'])){
          $data['single_product_details']['meta_keywords'] = trim($data['single_product_details']['_product_seo_keywords'], ',');
        }
        elseif(isset($get_seo_data['meta_tag']['meta_keywords']) && !isset($data['single_product_details']['_product_seo_keywords'])){
          $data['single_product_details']['meta_keywords'] = trim($get_seo_data['meta_tag']['meta_keywords'], ',');
        }
        else{
          $data['single_product_details']['meta_keywords'] = null;
        }

        $data['upsell_products'] = get_upsell_products( $product_id );
        $data['designer_settings'] = $this->option->getCustomDesignerSettingsData();
        $data['art_cat_lists_data']  =   $this->product->getTermData( 'designer_cat', false, null, 1 );

        if($data['single_product_details']['_product_custom_designer_settings']['enable_global_settings'] == 'yes'){
          if(count($data['designer_settings'])>0){
            $data['designer_hf_data'] = $data['designer_settings']['general_settings'];
          }
        }
        elseif($data['single_product_details']['_product_custom_designer_settings']['enable_global_settings'] == 'no'){
          if(count($data['single_product_details']['_product_custom_designer_settings']) >0){
            $data['designer_hf_data'] = $data['single_product_details']['_product_custom_designer_settings'];
          }
        }

        $get_data = SaveCustomDesign ::where('product_id', $product_id)->first();

        if(!empty($get_data)){
          $data['design_json_data'] = $get_data['design_data'];
        }
        else{
          $data['design_json_data'] = null;
        }
        
        $get_variation_data = get_product_variations_with_data( $product_id );
      
        if(count($get_variation_data) > 0){
          $variation_data = array();

          foreach($get_variation_data as $row){
            if(isset($row['_variation_post_price'])){
              $row['_variation_post_price'] = price_html( get_product_price_html_by_filter(get_role_based_price_by_product_id($row['id'], $row['_variation_post_price'])), get_frontend_selected_currency());
            }
            
            $get_current_user_data  =  get_current_frontend_user_info();
    
            if(is_frontend_user_logged_in() && isset($get_current_user_data['user_role_slug']) ){
              if($row['_is_role_based_pricing_enable'] == true){
                if(isset($row['_role_based_pricing_array'][$get_current_user_data['user_role_slug']])){
                  $regular_price =  $row['_role_based_pricing_array'][$get_current_user_data['user_role_slug']]['regular_price'];
                  $sale_price    =  $row['_role_based_pricing_array'][$get_current_user_data['user_role_slug']]['sale_price'];

                  $row['regular_price_comp_val'] = $regular_price;
                  $row['sales_price_comp_val']   = $sale_price;

                  $row['regular_price'] = price_html( get_product_price_html_by_filter(get_role_based_price_by_product_id($row['id'], $regular_price)), get_frontend_selected_currency());
                  $row['sales_price']   = price_html( get_product_price_html_by_filter(get_role_based_price_by_product_id($row['id'], $sale_price)), get_frontend_selected_currency());
                }
              }
            } 

            array_push($variation_data, $row);
          }

          $data['variations_data'] = $variation_data;
        }
        else{
          $data['variations_data'] = $get_variation_data;
        }

        return view('pages.frontend.frontend-pages.frontend-designer', $data);
      }
      else{
        return view('errors.no_data');
      }
    }
    else{
      return view('errors.no_data');
    }
  }
  
  /**
   * 
   * Checkout received order
   *
   * @param order_id, order_processing_id
   * @return void 
   */
  public function thankyouPageContent( $params, $params2 ){
    $data = array();
    $get_order_data = $this->classCommonFunction->get_order_details_by_order_id(array('order_id' => $params, 'order_process_id' => $params2));
    $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
    
    if(count($get_order_data) > 0){
      $get_order_data['settings'] = $this->option->getSettingsData();  
      $data['order_details_for_thank_you_page'] = $get_order_data;
    }
    else{
      $data['order_details_for_thank_you_page'] = array();
    }
    
    return view('pages.frontend.frontend-pages.thank-you', $data);
  }

  /**
   * 
   *Manage for cart page
   *
   * @param null
   * @return void 
   */
  public function doActionFromCartPage(){
    $data = Input::all();
    if( Request::isMethod('post') && isset($data['empty_cart']) && Session::token() == Input::get('_token')){
      $this->cart->clear();
      return redirect()->back();
    }
    elseif( Request::isMethod('post') && isset($data['update_cart']) && Session::token() == Input::get('_token')){
      if(count($data['cart_quantity']) > 0){
        foreach($data['cart_quantity'] as $key => $qty){
          $this->cart->updateQty($key, $qty);
        }
      }
      return redirect()->back();
    }
    elseif( Request::isMethod('post') && isset($data['checkout']) && Session::token() == Input::get('_token')){
      if($this->cart->getItems()){
        foreach($this->cart->getItems() as $items){
			$price = $this->classCommonFunction->getProductPrice($items->id,$items->options['required_option'],$items->options['option_option'],$items->quantity);
			if($price=='out_of_stock')
			{
				Session::flash('message', Lang::get('frontend.sorry_label') .' '.$product_data['post_title'] .' '. Lang::get('frontend.stock_validation'));
                $this->cart->clear();
                return redirect()->back();
			}
        }
        
        return redirect()->route('checkout-page');
      }
    }
  }

  /**
   * 
   *Item remove from cart
   *
   * @param item id
   * @return void
   */
  public function doActionForRemoveItem( $item_id ){
    if($item_id){
      if( $this->cart->remove( $item_id ) ){
        return redirect()->back();
      }
    }
  }
  
  /**
   * 
   *Remove compare product from list
   *
   * @param product id
   * @return void
   */
  public function doActionForRemoveCompareProduct( $product_id ){
    if($product_id){
      if(Session::has('shopist_selected_compare_product_ids') && count(Session::get('shopist_selected_compare_product_ids')) > 0){
        $array = array();
        foreach(Session::get('shopist_selected_compare_product_ids') as $val){
          if($val != $product_id){
            array_push($array, $val);
          }
        }
        
        Session::forget('shopist_selected_compare_product_ids');
        Session::put('shopist_selected_compare_product_ids', $array);
        
        return redirect()->back();
      }
    }
  }
  
  /**
   * 
   * Force file download for downloadable product
   *
   * @param product id, file key
   * @return void
   */
  public function forceDownload( $post_id, $order_id, $file_key, $target ){
    $get_orders_items  =   OrdersItem::where(['order_id' => $order_id])->first();
    
    if(!empty($get_orders_items)){
      $orders_items = json_decode( $get_orders_items->order_data, TRUE );
    }
    
    if( $this->classCommonFunction->checkDownloadRequired( $orders_items[$post_id]['download_data'], $order_id, $orders_items[$post_id]['download_data']['downloadable_files'][$file_key]['file_name'] ) && isset($orders_items[$post_id]['download_data']['downloadable_files'][$file_key]) && isset($orders_items[$post_id]['download_data']['downloadable_files'][$file_key][$target]) ){
      $parse_url = explode('uploads', $orders_items[$post_id]['download_data']['downloadable_files'][$file_key][$target]);
      
      if(count($parse_url) > 0 && isset($parse_url[1])){
        $file_path = public_path().'/uploads'.$parse_url[1];
        
        if(File::exists($file_path)){
          $get_extension = File::extension($file_path);
          $get_content_type = File::mimeType($file_path);

          if(!empty($get_extension) && !empty($get_content_type)){
            $filename = time().'-'.uniqid(true).'.'.$get_extension;
            
            $user_id = 0;
            $get_post = PostExtra::where(['post_id' => $order_id, 'key_name' => '_order_process_key'])->first();

            if(is_frontend_user_logged_in()){
              $get_user_info = get_current_frontend_user_info();
              $user_id = $get_user_info['user_id'];
            }
            
            //save download data
            $downloadextra = new DownloadExtra;
            $downloadextra->post_id      =   $post_id;
            $downloadextra->order_id     =   $order_id;
            $downloadextra->order_key		  =   $get_post->key_value;
            $downloadextra->user_id			   =   $user_id;
            $downloadextra->file_name		  =   $orders_items[$post_id]['download_data']['downloadable_files'][$file_key]['file_name'];
            $downloadextra->file_url		   =   $parse_url[1];
            
            if($downloadextra->save()){
              header('Content-Description: File Transfer');
              header('Cache-Control: public');
              header('Content-Type: '.$get_content_type);
              header("Content-Transfer-Encoding: binary");
              header('Content-Disposition: attachment; filename='. $filename);
              header('Content-Length: '.filesize($file_path));
              ob_clean(); 
              flush();
              readfile($file_path);
              exit;
            }
          }
        } 
      }
    }
  }
  
   /**
   * <ayushma.jain@gaurish.com>
   * Youth Protection Policy page content
   *
   * @param null
   * @return void 
   */
   public function termsAndPolicyContent(){
	   $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
	    return view('pages.frontend.frontend-pages.terms-condition', $data);
   }
   /**
   * <ayushma.jain@gaurish.com>
   * Time Deal page content
   *
   * @param null
   * @return void 
   */
   public function timeDealPageContent(){
	   $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
	    return view('pages.frontend.frontend-pages.time-deal-page', $data);
   }
    /**
   * <ayushma.jain@gaurish.com>
   * Load search page in mobile view.
   *
   * @param null
   * @return void 
   */
   public function searchPageContent(){
	   $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
	   return view('pages.frontend.frontend-pages.search-page',$data);
   } 
    /**
   * <ayushma.jain@gaurish.com>
   * Load category page in mobile view.
   *
   * @param null
   * @return void 
   */
   public function categoryPageContent(){
	   $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
	   
	   $get_cat_tree = $this->product->get_categories(0, 'product_cat');
	   $data['productCategoriesTree']        =   $get_cat_tree;
	   return view('pages.frontend.frontend-pages.mob-category-page',$data);
   } 
   
   /**
   * <ayushma.jain@gaurish.com>
   * Recent Product page in mobile view.
   *
   * @param null
   * @return void 
   */
   public function recentProductPageContent(){
	   $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
	   if(is_frontend_user_logged_in()){
		   $recently_visited=$checkPreviousRecord = UserRecentActivity::where(['user_id' => Session::get('shopist_frontend_user_id'),'activity_type' => 'visit'])->get()->toArray();
		   $data['recently_visited'] = array_unique(explode(",",$recently_visited[0]['activity']));
	   }
	   return view('pages.frontend.frontend-pages.recent-product',$data);
   }
   
   //Function to store category sorting data in cache.
   public function StoreCategoryData(){
	   //echo '<pre>'; print_r($_POST);exit;
	    $User =       new User;
		$interest_category  = isset($_POST['category'])? implode(',',$_POST['category']): ' ';
		if(is_frontend_user_logged_in()){
			User::where('id', Session::get('shopist_frontend_user_id'))
				->update(['interest_category' => $interest_category]);
		}
		if(isset($_POST['category']))
		{
			Cache::forever( 'cachekey', $_POST['category'], 1 );
		}
		if(isset($_POST['sorted_category_list']))
		{
			Cache::forever( 'sorted_list', $_POST['sorted_category_list'], 1 );
		}
		return redirect('/');
	  
   } 
   //Function to store category sorting data in cache.
   public function ResetstoreCategoryData(){
		if(Cache::has('cachekey'))
		{
			Cache::forget('cachekey');
		}
		if(Cache::has('sorted_list'))
		{
			Cache::forget('sorted_list');
		}
		return redirect('/');
	  
   }
   public function getOrderPaymentResponse()
   {
		print_r($_REQUEST);
   }
  
}