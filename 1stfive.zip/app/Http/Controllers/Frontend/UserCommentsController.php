<?php
namespace shopist\Http\Controllers\Frontend;

use shopist\Http\Controllers\Controller;
use Request;
use Illuminate\Support\Facades\Lang;
use Validator;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Input;
use shopist\Models\Comment;
use Illuminate\Support\Facades\DB;

class UserCommentsController extends Controller
{
  public function saveUserComments(){
    if( Request::isMethod('post') && Session::token() == Input::get('_token') ){
      
      if(Session::has('shopist_frontend_user_id')){
        $input = Input::all();
		
		$product_id = !empty(Input::get('object_id'))? Input::get('object_id'): 0;
		$sub_order_id = !empty(Input::get('sub_order_id')) ? Input::get('sub_order_id') : 0;
		$content = !empty(Input::get('product_review_content')) ? Input::get('product_review_content') : '';
		$rating = !empty(Input::get('selected_rating_value')) ? Input::get('selected_rating_value') : 0;
		$target = !empty(Input::get('comments_target')) ? Input::get('comments_target') : 0;
		//$terms = (!empty(Input::get('terms')) && Input::get('terms') == true) ? 'Y' : 'N';
		$alreadyExistingFlag = '';
		
          $comments   =  new Comment;
          $alreadyExistingFlag  = $comments->where(['order_id' => $sub_order_id,'object_id'=> $product_id])->get();
		  
		  if(count($alreadyExistingFlag)>0){
			  $updateStatus = $comments->where(['order_id' => $sub_order_id,'object_id'=> $product_id])->update(['content' => '$content','rating'=>$rating]);
		  }else{
			  $comments->user_id    	=    Session::get('shopist_frontend_user_id');
			  $comments->content    	=    $content;
			  $comments->rating     	=    $rating;
			  $comments->object_id   	=    Input::get('object_id');
			  $comments->seller_id   	=    get_author_id_by_product_id(Input::get('object_id'));
			  $comments->order_id   	=    $sub_order_id;
			  $comments->target     	=    $target;
			  $comments->status      	=    0;
		  }
          
          if($comments->save()){
			if(isset($_POST['terms']))
			{ 
				$data = array('status'=>'Completed','complete_date'=>NOW());
				$get_order_data = DB::table('order_detail')
					->where('id', $sub_order_id)
					->update($data);
			}
            Session::flash('success-message', Lang::get('frontend.comments_saved_msg') );
            return redirect()-> back()->withInput(); 
			//return redirect()->route('product-review-page');
          }
        
      }
      else{
        Session::flash('error-message', Lang::get('frontend.without_login_comments_msg') );
        return redirect()-> back()
                         ->withInput();
      }
    }
  }
}