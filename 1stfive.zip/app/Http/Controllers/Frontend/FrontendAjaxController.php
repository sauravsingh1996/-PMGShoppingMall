<?php
namespace shopist\Http\Controllers\Frontend;

use shopist\Http\Controllers\Controller;
use Request;
use Hash;
use Illuminate\Support\Facades\Input;
use shopist\Models\Post;
use shopist\Models\Product;
use shopist\Library\GetFunction;
use Session;
use Anam\Phpcart\Facades\Cart;
use Illuminate\Support\Facades\Cache;
use Carbon\Carbon;
use shopist\Models\RequestProduct;
use shopist\Models\Subscription;
use shopist\Models\UsersDetail;
use shopist\Models\UserShippingAddress;
use shopist\Models\SupportTicket;
use shopist\Models\Consultation;
use shopist\Models\User;
use shopist\Models\WishList;
use shopist\Library\CommonFunction;
use shopist\Http\Controllers\OptionController;
use shopist\Http\Controllers\ProductsController;
use Illuminate\Support\Facades\DB;
use shopist\Models\OrderDetail;


class FrontendAjaxController extends Controller
{
  public $currency_symbol;
  public $settingsData              = array();
  public $shipping                  = array();
  public $classCommonFunction;
  public $option;
  public $product;


  public function __construct() 
  {
    $this->classGetFunction     = new GetFunction();
    $this->classCommonFunction  =  new CommonFunction();
    $this->option   =  new OptionController();
    $this->product   =  new ProductsController();
    
    
    $this->shipping = $this->option->getShippingMethodData();
    $this->settingsData   = $this->option->getSettingsData();
    $this->currency_symbol = $this->classCommonFunction->get_currency_symbol( $this->settingsData['general_settings']['currency_options']['currency_name'] );
  }
  
  /**
   * 
   *Products search by products title
   *
   * @param null
   * @return array
   */
  public function getProductsByFilterWithName()
  {
    if(Request::isMethod('post') && Request::ajax() && Session::token() == Request::header('X-XSRF-TOKEN'))
    {
      $input = Input::all();
      
       
      $get_posts_by_filter = Product::where(['status' => 1])-> where('title', 'LIKE', '%' .$input['data']. '%')->paginate(15);
     
      $returnHTML = view('pages.ajax-pages.products')->with(['filter_data' => $get_posts_by_filter, '_currency_symbol' => $this->currency_symbol])->render();
      
      return response()->json(array('success' => true, 'html'=> $returnHTML));
    }
  } 
  
  /**
   * 
   *Products search by products title
   *
   * @param null
   * @return array
   */
  public function addAddress()
  {
    
      $input = Input::all();
       $get_user_login_data = get_current_frontend_user_info();
       $address = $_GET['address'];
       $get_posts_by_filter = UserShippingAddress::where( ['user_id' => $get_user_login_data['user_id']] )->orderBy('mark_default', 'DESC')->get()->toArray();
     
      $returnHTML = view('pages.ajax-pages.shipping-address-view')->with(['filter_data' => $get_posts_by_filter, 'new_address' =>  $address ,'_currency_symbol' => $this->currency_symbol])->render();
      
      return response()->json(array('success' => true, 'html'=> $returnHTML));
    
  }
  
  /**
   * 
   *Products add to cart initialize
   *
   * @param null
   * @return void
   */
  public function productAddToCart()
  {
    if(Request::isMethod('post') && Request::ajax() && Session::token() == Request::header('X-CSRF-TOKEN')){
		$input = Request::all();
		$error = false;
		$error = false;
		$final_product_price = 0;
		$product = $this->product->getProductDataById( $input['product_id']);
		if($product['post_status']!=1)
		{
			//echo '1';
			return "out_of_stock";
		}
		if($product['available_for_minors']=='N')
		{
			$user = get_current_frontend_user_info();
			if(!empty($user['dob']) && $user['dob']!='0000-00-00')
			{
				$dob = new \DateTime($user['dob']);
	 
				//We need to compare the user's date of birth with today's date.
				$now = new \DateTime();
				 
				//Calculate the time difference between the two dates.
				$difference = $now->diff($dob);
				 
				//Get the difference in years, as we are looking for the user's age.
				$age = $difference->y;
				if($age < 19)
				{
					//echo '2';
					return "out_of_stock";
				}
			}
		}
		//print_r($product);
		if($product['sale_period_mode']=='yes' && $product['sale_period_start_date']!='0000-00-00' && !empty($product['sale_period_start_date']) && strtotime(date('Y-m-d')) < strtotime($product['sale_period_start_date']) )
		{
			
			return "out_of_stock";
		}
		if($product['sale_period_mode']=='yes' && $product['sale_period_end_date']!='0000-00-00' && !empty($product['sale_period_end_date']) && strtotime($product['sale_period_end_date']) < strtotime(date('Y-m-d')))
		{
			
			//echo '4';
			return "out_of_stock";
		}
		if($product['post_stock_availability']!='in_stock' || (!isset($input['required_option']) && $product['manage_stock']=='yes' && $product['stock_qty_default'] < $input['qty']))
		{
			//echo '5';
			return "out_of_stock";
		}
		if(!isset($input['required_option']))
		{
			$final_product_price=$product['post_sale_price'];
		}
		$product_data = $this->classCommonFunction->getProductExtra($input['product_id'],'_product_section_data_options_json');
		
		//Check Qty if any required option exit or not
		if(isset($input['required_option']))
		{
			$required_data = $this->searchProductOptionalData($input['required_option'],$product_data['requiredOptions']);
			if(empty($required_data))
			{
				echo "no_option_found";exit;
			}	
			if($product['manage_stock']=='no' || isset($required_data['sale_mode']) && $required_data['sale_mode']=='on_sale' && $input['qty'] <= $required_data['sale_quantity'] )
			{
				$final_product_price=$final_product_price+$required_data['sale_price'];
			}
			else
			{
				echo "required_option_out_of_stock";
				exit;
			}
		}
		//echo $final_product_price.'<br/>';
		//Check Qty if any optional option exit or not
		if(isset($input['option_option']))
		{
			foreach($input['option_option'] as $option)
			{
				$key = array_search($option, array_column($product_data['optionalOptions'], 'value'));
				if($key > -1)
				{
					$required_data = $product_data['optionalOptions'][$key];
				}
				if( isset($required_data['sale_mode']) && $required_data['sale_mode']=='on_sale' && $input['qty'] <= $required_data['sale_quantity'] )
				{
					$final_product_price=$final_product_price+$required_data['sale_price'];
				}
				else
				{
					echo "optional_option_out_of_stock";
					exit;
				}
			}
			
		}
		if($final_product_price==0)
		{
			echo "zero_price";exit;
		}
		$selected_option['required_option']=(isset($input['required_option']))?$input['required_option']:array();
		$selected_option['option_option']=(isset($input['option_option']))?$input['option_option']:array();
		$this->classCommonFunction->add_to_cart($input['product_id'], $input['qty'], $final_product_price, $selected_option);
    }
  }
  
  /**
   * 
   *Cart update using shipping method 
   *
   * @param null
   * @return html
   */
  public function cartTotalUpdateUsingShippingMethod(){
    if(Request::isMethod('post') && Request::ajax() && Session::token() == Request::header('X-CSRF-TOKEN')){
      $input = Request::all();
      $shipping_array = array();
      $vendor_details = array();
      $shipping_cost  = 0;
      $shipping_details = array();
      
      if(Cart::items()->count() > 0){
        foreach(Cart::items() as $item){
          $get_vendor_details = get_vendor_details_by_product_id( $item->product_id );
          
          if(count($get_vendor_details) > 0 && $get_vendor_details['user_role_slug'] == 'vendor'){
           $vendor_details = json_decode($get_vendor_details['details']);
           break;
          }
        }
      }
      
      if(is_array($vendor_details) && count($vendor_details) > 0){
        $shipping_details = $this->classCommonFunction->objToArray($vendor_details->shipping_method, true);
      }
      else{
        $shipping_details = $this->shipping;
      }
      
      if($input['data'] == 'flat_rate'){
        $shipping_cost = $shipping_details['flat_rate']['method_cost'];
      }
      elseif($input['data'] == 'free_shipping'){
        $shipping_cost = 0;
      }
      elseif($input['data'] == 'local_delivery'){
        if($shipping_details['local_delivery']['fee_type'] == 'fixed_amount'){
          $shipping_cost = $shipping_details['local_delivery']['delivery_fee'];
        }
        elseif($shipping_details['local_delivery']['fee_type'] == 'cart_total'){
          $shipping_cost = Cart::getLocalDeliveryShippingPercentageTotal();
        }
        elseif($shipping_details['local_delivery']['fee_type'] == 'per_product'){
          $shipping_cost = Cart::getLocalDeliveryShippingPerProductTotal();
        }
      }
      
      $shipping_array = array('shipping_method' => $input['data'], 'shipping_cost' => $shipping_cost);
      
      if(count($shipping_array) > 0){   
        if(Cart::setShippingMethod( $shipping_array )){
          echo  price_html( get_product_price_html_by_filter(Cart::getCartTotal()) ); 
        }
      }
    }
  }
  
  /**
   * 
   *Save custom design image
   *
   * @param null
   * @return json
   */
  public function saveCustomDesignImage(){
    if(Request::isMethod('post')){
      if(Session::token() == Request::header('X-CSRF-TOKEN')){
        $input = Request::all();
        //$destinationPath = 'uploads';
        $destinationPath = public_path('uploads');
        $fileName        = '';
        $upload_success  = '';
        $accessToken = uniqid (rand(), true);
        
        
        if(count($input) >0){
          foreach($input as $key => $val){        
            $fileName = uniqid(time(), true). '.' .'png';
            $upload_success = Input::file($key)->move($destinationPath, $fileName);
            
            if ($upload_success) {
              if(Session::has('_recent_saved_custom_design_images')){
                $get_img_ary = Session::get('_recent_saved_custom_design_images');
                $parse_ary = unserialize($get_img_ary);
                
                if(isset($parse_ary[$accessToken])){
                  array_push($parse_ary[$accessToken], $fileName);
                }
                else{
                  $parse_ary[$accessToken] = array($fileName);
                }
                
                Session::forget('_recent_saved_custom_design_images');
                Session::put('_recent_saved_custom_design_images', serialize($parse_ary));
              }
              elseif(!Session::has('_recent_saved_custom_design_images')){
                $img_ary = array($accessToken => array($fileName));
                Session::put('_recent_saved_custom_design_images', serialize($img_ary) );
              }
            }
          } 
          
          if(Session::has('_recent_saved_custom_design_images')){
            return response()->json(array('status' => 'success', '_access_token' => $accessToken));
          }
        }
      }
    }
  }
  
  /**
   * 
   *Customize products add to cart initialize
   *
   * @param null
   * @return void
   */
  public function customizeProductAddToCart(){
    if(Request::isMethod('post') && Request::ajax() && Session::token() == Request::header('X-CSRF-TOKEN')){
      $input = Request::all();
      
      if(isset($input['customizeData'])){
        $expiresAt = Carbon::now()->addMinutes(50);
        
        if(Cache::add($input['accessToken'], $input['customizeData'], $expiresAt)){
          if(isset($input['variation_id']) && $input['variation_id']){
            $this->classCommonFunction->add_to_cart($input['product_id'], $input['qty'], $input['variation_id'], null, $input['accessToken'], $input['customizeData']);
          }
          else{
            $this->classCommonFunction->add_to_cart($input['product_id'], $input['qty'], 0, null, $input['accessToken'], $input['customizeData']);
          }
        }
      }
    }
  }
  
  /**
   * 
   * Request product data save
   *
   * @param null
   * @return json
   * since version 2.0
   */
  public function storeRequestedProductData(){
    if(Request::isMethod('post') && Request::ajax() && Session::token() == Request::header('X-CSRF-TOKEN')){
      $input = Request::all();
      $request_product  =  new RequestProduct;
      
      $request_product->product_id    =   $input['product_id'];
      $request_product->name          =   urldecode($input['product_name']);
      $request_product->email         =   urldecode($input['email']);
      $request_product->phone_number	=   urldecode($input['phone_number']);
      $request_product->description   =   urldecode($input['description']);
      
      if($request_product->save()){
        return response()->json(array('status' => 'saved'));
      }
    }
  }
  
   /**
   * 
   * Subscription data save
   *
   * @param null
   * @return json
   * since version 2.0
   */
  public function storeSubscriptionData()
  {
    if(Request::isMethod('post') && Request::ajax() && Session::token() == Request::header('X-CSRF-TOKEN'))
    {
      $input = Request::all();
      
      if($input['type'] == 'custom'){
        $subscriptions  =  new Subscription;
        
        $subscriptions->name    =   urldecode($input['name']);
        $subscriptions->email   =   urldecode($input['email']);
        
        if($subscriptions->save()){
          return response()->json(array('status' => 'saved'));
        }
      }   
      elseif($input['type'] == 'mailchimp'){
        $subscribe_data = get_subscription_data();
        
        if(isset($subscribe_data['mailchimp']['api_key']) && isset($subscribe_data['mailchimp']['list_id'])){
          $api_key = $subscribe_data['mailchimp']['api_key'];
          $listId  = $subscribe_data['mailchimp']['list_id'];
          $email   = urldecode($input['email']);
          $name    = urldecode($input['name']); 
          
          $data = [
              'email'     =>  $email,
              'status'    =>  'subscribed',
              'firstname' =>  $name,
              'lastname'  =>  ''
          ];
          
          $response = $this->classGetFunction->store_mailchimp_subscriber_data($api_key, $listId, $data);
          
          if($response['status'] == 400){
            return response()->json(array('status' => 'error'));
          }
          elseif($response['status'] == 'subscribed'){
            return response()->json(array('status' => 'saved'));
          }
        }
      }
    }
  }
  
  /**
  * 
  * Set cookie for subscription popup 
  *
  * @param null
  * @return response
  */
  public function setCookieForSubscriptionPopup(){
    if(Request::isMethod('post') && Request::ajax() && Session::token() == Request::header('X-CSRF-TOKEN')){
      return response()->json(array('status' => 'saved'))->withCookie(cookie()->forever('subscribe_popup_not_needed', 'no_need'));
    }
  }

   /**
   * 
   * Frontend user logout
   *
   * @param null
   * @return void
   */
  public function logoutFromFrontendUserLogin()
  {
    if(Request::isMethod('post') && Request::ajax() && Session::token() == Request::header('X-XSRF-TOKEN'))
    {
      if(Session::has('shopist_frontend_user_id'))
      {
        Session::forget('shopist_frontend_user_id');
		Session::forget('enum_user_type_status');
        echo urlencode(route('user-login-page'));
      }
    }
  }
  
  /**
   * 
   * Frontend user wishlist data save
   *
   * @param null
   * @return json
   */
  public function userWishlistDataSaved()
  {
    if(Request::isMethod('post') && Request::ajax() && Session::token() == Request::header('X-CSRF-TOKEN')){
      $input               =  Request::all();
      $get_current_user_id =  get_current_frontend_user_info();
      if(isset($get_current_user_id['user_id']) && $get_current_user_id['user_id']){
			$WishList = new WishList;
			$product_id = $input['data'];
			$updateInsert = $WishList->updateOrCreate(
              [
              'user_id' => $get_current_user_id['user_id'],
              'product_id' => $product_id
              ],
              [
              'user_id' => $get_current_user_id['user_id'],
              'product_id' => $product_id,
              'updated_at' => date('Y-m-d h:i:s')
              ]
            );
			return response()->json(array('status' => 'success', 'notice_type' => 'user_wishlist_saved'));
      }
      else{
        return response()->json(array('status' => 'error', 'notice_type' => 'user_login_required'));
      }
    }
  }
  
  /**
   * 
   * Manage multi language
   *
   * @param null
   * @return json
   */
  public function multiLangProcessing(){
    if(Request::isMethod('post') && Request::ajax() && Session::token() == Request::header('X-CSRF-TOKEN')){
      $input = Request::all();
     
      return response()->json(array('status' => 'success'))->withCookie( cookie()->forever('shopist_multi_lang', $input['data']) );
    }
  }
  
  /**
   * 
   * Manage multi currency
   *
   * @param null
   * @return json
   */
  public function multiCurrencyProcessing(){
    if(Request::isMethod('post') && Request::ajax() && Session::token() == Request::header('X-CSRF-TOKEN')){
      $input = Request::all();
      return response()->json(array('status' => 'success'))->withCookie( cookie()->forever('shopist_multi_currency', $input['data']) );
    }
  }
  
  /**
   * 
   * Get function for products quick view
   *
   * @param null
   * @return html
   */
  public function getQuickViewProductData(){
    $input = Request::all();
    
    if(Request::isMethod('post') && Request::ajax() && Session::token() == Request::header('X-CSRF-TOKEN')){
      $data = array();
      
      $data = $this->classCommonFunction->get_dynamic_frontend_content_data();
      $data['single_product_details']  =  $this->product->getProductDataById( $input['product_id'] );
      $data['attr_lists']              =  $this->product->getAllAttributes( $input['product_id'] );
      $data['comments_rating_details'] =  get_comments_rating_details( $input['product_id'], 'product' );
          
      $returnHTML = view('pages.ajax-pages.quick-view-content')->with( $data )->render();

      return response()->json(array('success' => true, 'html'=> $returnHTML));
    }
  }
  
  /**
   * 
   * Check and apply user coupon
   *
   * @param coupon code
   * @return response
   */
  public function applyUserCoupon(){
    $input = Request::all();
    
    if(Request::isMethod('post') && Request::ajax() && Session::token() == Request::header('X-CSRF-TOKEN')){
      $response = $this->classGetFunction->manage_coupon($input['_couponCode'], 'new_add');
      $coupon_response = $this->classGetFunction->get_coupon_response( $input['_couponCode'] );
      
      if(!empty($response) && $response == 'no_coupon_data'){
        return response()->json(array('error' => true, 'error_type'=> 'no_coupon_data'));
      }
      elseif(!empty($response) && $response == 'coupon_already_apply'){
        return response()->json(array('error' => true, 'error_type'=> 'coupon_already_apply'));
      }
      elseif(!empty($response) && $response == 'less_from_min_amount'){
        return response()->json(array('error' => true, 'error_type'=> 'less_from_min_amount', 'min_amount' => price_html( get_product_price_html_by_filter($coupon_response['coupon_min_restriction_amount'], get_frontend_selected_currency() ))));
      }
      elseif(!empty($response) && $response == 'exceed_from_max_amount'){
        return response()->json(array('error' => true, 'error_type'=> 'exceed_from_max_amount', 'max_amount' => price_html( get_product_price_html_by_filter($coupon_response['coupon_max_restriction_amount'], get_frontend_selected_currency() ))));
      }
      elseif(!empty($response) && $response == 'no_login'){
        return response()->json(array('error' => true, 'error_type'=> 'no_login'));
      }
      elseif(!empty($response) && $response == 'user_role_not_match'){
        $get_login_user = get_current_frontend_user_info();
        return response()->json(array('error' => true, 'error_type'=> 'user_role_not_match', 'role_name' => $get_login_user['user_role']));
      }
      elseif(!empty($response) && $response == 'coupon_expired'){
        return response()->json(array('error' => true, 'error_type'=> 'coupon_expired'));
      }
      elseif(!empty($response) && $response == 'discount_from_product'){
        return response()->json(array('success' => true, 'success_type'=> 'discount_from_product', 'discount_price' => price_html( get_product_price_html_by_filter(Cart::couponPrice(), get_frontend_selected_currency() )), 'grand_total' => price_html( get_product_price_html_by_filter(Cart::getCartTotal(), get_frontend_selected_currency() ))));
      }
      elseif(!empty($response) && $response == 'percentage_discount_from_product'){
        return response()->json(array('success' => true, 'success_type'=> 'percentage_discount_from_product', 'discount_price' => price_html( get_product_price_html_by_filter(Cart::couponPrice(), get_frontend_selected_currency() )), 'grand_total' => price_html( get_product_price_html_by_filter(Cart::getCartTotal(), get_frontend_selected_currency() ))));
      }
      elseif(!empty($response) && $response == 'discount_from_total_cart'){
        return response()->json(array('success' => true, 'success_type'=> 'discount_from_total_cart', 'discount_price' => price_html( get_product_price_html_by_filter(Cart::couponPrice(), get_frontend_selected_currency() )), 'grand_total' => price_html( get_product_price_html_by_filter(Cart::getCartTotal(), get_frontend_selected_currency() ))));
      }
      elseif(!empty($response) && $response == 'percentage_discount_from_total_cart'){
        return response()->json(array('success' => true, 'success_type'=> 'percentage_discount_from_total_cart', 'discount_price' => price_html( get_product_price_html_by_filter(Cart::couponPrice(), get_frontend_selected_currency() )), 'grand_total' => price_html( get_product_price_html_by_filter(Cart::getCartTotal(), get_frontend_selected_currency() ))));
      }
      elseif(!empty($response) && $response == 'exceed_from_cart_total'){
        return response()->json(array('error' => true, 'error_type'=> 'exceed_from_cart_total'));
      }
    }
  }
  
  /**
   * 
   * user coupon remove
   *
   * @param null
   * @return response
   */
  public function removeUserCoupon(){
    if(Cart::remove_coupon()){
      return response()->json(array('success' => true, 'grand_total'=> price_html( get_product_price_html_by_filter(Cart::getCartTotal(), get_frontend_selected_currency() ))));
    }
  }
  
  /**
   * 
   * delete item from wishlist
   *
   * @param null
   * @return response
   */
  public function deleteItemFromWishlist(){
	  
		if(Request::isMethod('post') && Request::ajax() && Session::token() == Request::header('X-CSRF-TOKEN')){
			$input               =  Request::all();
			$get_current_user_id =  get_current_frontend_user_info();
	  

			if(!empty($get_current_user_id) && count($get_current_user_id) > 0){
				$get_data_by_user_id = get_user_account_details_by_user_id( $get_current_user_id['user_id'] );

				$WishList = new WishList;
		
					foreach($input['data'] as $data)
					{
						$affected_row = $WishList->where(['user_id'=> $get_current_user_id['user_id']])->where('product_id', $data)->delete(); 
					}
		 
		
				return response()->json(array('status' => 'success', 'notice_type' => 'deleted_item'));
		
			}  
		}
	}
  
  /**
   * 
   * Get Mini cart data
   *
   * @param null
   * @return response
   */
  public function getMiniCartData(){
    if(Request::isMethod('post') && Request::ajax() && Session::token() == Request::header('X-CSRF-TOKEN')){
      $input =  Request::all();
      $returnHTML = '';
      
      if($input['mini_cart_id'] == 1){
        $returnHTML = view('pages.ajax-pages.mini-cart-html')->render();
      }
      elseif($input['mini_cart_id'] == 2){
        $returnHTML = view('pages.ajax-pages.mini-cart-html2')->render();
      }
      
      return response()->json(array('status' => 'success', 'type' => 'mini_cart_data', 'html'=> $returnHTML));
    }
  }
  
  /**
   * 
   * Product compare data process
   *
   * @param null
   * @return response
   */
  public function productCompareDataSaved(){
    if(Request::isMethod('post') && Request::ajax() && Session::token() == Request::header('X-CSRF-TOKEN')){
      $input = Request::all();
      
      if(!Session::has('shopist_selected_compare_product_ids')){
        Session::put('shopist_selected_compare_product_ids', array($input['id']));
        return response()->json(array('status' => 'success', 'notice_type' => 'compare_data_saved', 'item_count' => 1));
      }
      elseif(Session::has('shopist_selected_compare_product_ids')){
        $get_data = Session::get('shopist_selected_compare_product_ids');
        
        if(in_array($input['id'], $get_data)){
          return response()->json(array('status' => 'error', 'notice_type' => 'already_saved', 'item_count' => count($get_data)));
        }
        else{
          if(count($get_data) < 4){
            array_push($get_data, $input['id']);
            Session::forget('shopist_selected_compare_product_ids');
            Session::put('shopist_selected_compare_product_ids', $get_data);

            return response()->json(array('status' => 'success', 'notice_type' => 'compare_data_saved', 'item_count' => count($get_data)));
          }
          else{
            return response()->json(array('status' => 'error', 'notice_type' => 'compare_data_exceed_limit', 'item_count' => count($get_data)));
          }
        }
       
      }
    }
  }
  
  /**
   * 
   * Contact with vendor via email
   *
   * @param name, message
   * @return response
   */
  public function contactWithVendorEmail(){
    if(Request::isMethod('post') && Request::ajax() && Session::token() == Request::header('X-CSRF-TOKEN')){
      $input = Request::all(); 
      $mailData = array();
      
      $mailData['source']           =   'contact_to_vendor_mail';
      $mailData['data']             =   array('_mail_to' => base64_decode($input['vendor_mail']), '_mail_from' => base64_decode($input['customer_email']), '_subject' => base64_decode($input['name']), '_message' => base64_decode($input['message']));

      $this->classGetFunction->sendCustomMail( $mailData );
      
      return response()->json(array('status' => 'success'));
    }
  }
  
  /**
   * 
   * Save user address 
   *
   * @param name, message
   * @return response
   */
  public function saveUserAccountData(){
    if(Request::isMethod('post') && Request::ajax() && Session::token() == Request::header('X-CSRF-TOKEN')){
		$input = Request::all(); 
		$get_current_user_id =  get_current_frontend_user_info();
		$user_shipping_address 						=  new UserShippingAddress;
		//if mark address to default then update other
		if($input['mark_default']=='yes')
		{
			UserShippingAddress::where(['user_id' => $get_current_user_id['user_id']])->update(['mark_default' => 'no']);
		}
		$user_shipping_address->updateOrCreate(
            [
              'id' => $input['_address_id']
            ],
            [
              'user_id' => $get_current_user_id['user_id'],
              'nomination' => $input['nomination'],
              'recipient' =>  $input['recipient'],
              'zipcode' => $input['zip'],
              'address_line_1' => $input['address_1'],
              'address_line_2' => $input['address_2'],
              'primary_contact' => $input['primary_contact'],
              'secondary_contact' => $input['secondary_contact'],
              'mark_default' => $input['mark_default'],
              'updated_at' => date('Y-m-d h:i:s')
            ]
        );
      return response()->json(array('status' => 'saved'));
    }
  }
  /**
   * 
   * Delete user address 
   *
   * @param id
   * @return response
   */
  public function deleteUserAccountData(){
    if(Request::isMethod('post') && Request::ajax() && Session::token() == Request::header('X-CSRF-TOKEN')){
		$input = Request::all();
		$user_shipping_address 	=  new UserShippingAddress;		
		$get_current_user_id =  get_current_frontend_user_info();
        $address_id =  $input['id'];
        UserShippingAddress::where( ['user_id' => $get_current_user_id['user_id'],'id' => $address_id] )->delete();
		return response()->json(array('status' => 'removed'));
    }
  }
  /**
   * 
   * Delete user support ticket 
   *
   * @param id
   * @return response
   */
  public function deleteUserSupportTicket(){
    if(Request::isMethod('post') && Request::ajax() && Session::token() == Request::header('X-CSRF-TOKEN')){
		$input = Request::all();
		$support_ticket 	=  new SupportTicket;		
		$get_current_user_id =  get_current_frontend_user_info();
        $id =  $input['id'];
        SupportTicket::where( ['user_id' => $get_current_user_id['user_id'],'id' => $id] )->delete();
		return response()->json(array('status' => 'removed'));
    }
  }
  
  /**
   * 
   * Delete One To One Inquiry Data
   *
   * @param id
   * @return response
   */
  public function deleteUserOneToOneInquiryData(){
    if(Request::isMethod('post') && Request::ajax() && Session::token() == Request::header('X-CSRF-TOKEN')){
		$input = Request::all();
		
		// Loading instance of Consultation Model.
        $Consultation = new Consultation;
		
		$get_current_user_id =  get_current_frontend_user_info();
        $id =  $input['id'];
		 
		DB::table('user_1_1_consultation_inquiry_data')->where('bintInquiryId', '=', $id)->where('bintLoggedInUserId', '=',  $get_current_user_id['user_id'])->delete();
        
		return response()->json(array('status' => 'removed'));
    }
  }
  /**
   * 
   * Verify user email and password
   *
   * @param email
   * @param current_password
   * @return response
   */
  public function verifyUserEmailnPwd()
  {
	if(Request::isMethod('post') && Request::ajax() && Session::token() == Request::header('X-CSRF-TOKEN')){
		$pwd_status = $email_status = 'success';
		$input = Request::all();

		if(!empty($input['current_pwd']))
		{
			$pwd_status='error';
			$password       =      bcrypt($input['current_pwd']);
			$userdata       =      ['id' => Session::get('shopist_frontend_user_id')];
			$dataResponse   =      User::where($userdata)->first();
			if(!empty($dataResponse) && isset($dataResponse->password) && isset($dataResponse->id)){
				
				if(Hash::check($input['current_pwd'], $password) && Hash::check($input['current_pwd'], $dataResponse->password))
				{
					$pwd_status='success';
				}
			}
		}
		if(!empty($input['email']))
		{
			$email_status='error';
			$is_email_exists     = User::where(['email' => $input['email']])->first();
			if($is_email_exists && $is_email_exists->id != Session::get('shopist_frontend_user_id'))
			{
				$email_status='error';
			}
			else
			{
				$email_status='success';
			}

		}
		return response()->json(array('email_status' => $email_status,'pwd_status' => $pwd_status));
    }
  }
  /**
   * Function :saveReturnRequest()
   * Function to send Exchange Request for Product.
   * Ayushma jain <ayushma.jain@gaurish.com> 11-04-2019
   */
  public function saveExchangeRequest(){
		$id = isset($_POST['data']['id']) ? $_POST['data']['id'] :'';
		$exchange_reason = isset($_POST['data']['exchange_reason']) ? $_POST['data']['exchange_reason'] :'';
		$payment_method = isset($_POST['data']['payment_method']) ? $_POST['data']['payment_method'] :'';
		$product_review_content = isset($_POST['data']['product_review_content']) ? $_POST['data']['product_review_content'] :'';
		$recall_option = isset($_POST['data']['recall_option']) ? $_POST['data']['recall_option'] :'';
		$shipping_cost = isset($_POST['data']['shipping_cost']) ? $_POST['data']['shipping_cost'] :'';
		$data =json_encode(array('reason_type'=>$exchange_reason,'reason_text'=>$product_review_content,'shipping_method'=>$recall_option,'shipping_amount'=>$shipping_cost,'payment_gateway'=>$payment_method,'payment_detail'=>''));
		$orderDetail 	= 	new OrderDetail;
		$updateStatus = $orderDetail->where(['id' => $id])->update(['status' => 'ExchangeRequest' ,'exchange_detail' => $data]);
		if(count($updateStatus)>0){
			return response()->json(array('status' => 'success'));
		}else{
			return response()->json(array('status' => 'failed'));
		}
		
	}
	/**
   * Function :saveReturnRequest()
   * Function to send Return Request for Product.
   * Ayushma jain <ayushma.jain@gaurish.com> 11-04-2019
   */
  
	public function saveReturnRequest(){
		$id = isset($_POST['data']['id']) ? $_POST['data']['id'] :'';
		$exchange_reason = isset($_POST['data']['exchange_reason']) ? $_POST['data']['exchange_reason'] :'';
		$product_review_content = isset($_POST['data']['product_review_content']) ? $_POST['data']['product_review_content'] :'';
		$recall_option = isset($_POST['data']['recall_option']) ? $_POST['data']['recall_option'] :'';
		$shipping_cost = isset($_POST['data']['shipping_cost']) ? $_POST['data']['shipping_cost'] :'';
		$data =json_encode(array('reason_type'=>$exchange_reason,'reason_text'=>$product_review_content,'shipping_method'=>$recall_option,'shipping_amount'=>$shipping_cost));
		$orderDetail 	= 	new OrderDetail;
		$updateStatus = $orderDetail->where(['id' => $id])->update(['status' => 'ReturnRequest' ,'return_detail' => $data]);
		if(count($updateStatus)>0){
			return response()->json(array('status' => 'success'));
		}else{
			return response()->json(array('status' => 'failed'));
		}
		
	}
	
	/**
   * Function :saveCancelRequest()
   * Function to send Cancel Request for Product.
   * Ayushma jain <ayushma.jain@gaurish.com> 11-04-2019
   */
  
	public function saveCancelRequest(){
		$id = isset($_POST['data']) ? $_POST['data'] :'';
		$orderDetail 	= 	new OrderDetail;
		$updateStatus = $orderDetail->where(['id' => $id])->update(['status' => 'CancelRequest' ,'cancellation_date' => NOW()]);
		if(count($updateStatus)>0){
			return response()->json(array('status' => 'success'));
		}else{
			return response()->json(array('status' => 'failed'));
		}
		
	}
	
	/**
   * Function :withdrawReturnRequest()
   * Function to cancel Return Request for Product.
   * Ayushma jain <ayushma.jain@gaurish.com> 16-04-2019
   */
  
	public function withdrawReturnRequest(){
		
		$sub_order_id = isset($_POST['data']) ? $_POST['data'] :'';
		
		$orderDetail 	= 	new OrderDetail;
		$CheckStatus = $orderDetail->where(['id' => $sub_order_id,'status'=> 'ReturnRequest'])->get();
		$updateStatus = 0;
		if(count($CheckStatus)>0)
		{
			$updateStatus = $orderDetail->where(['id' => $sub_order_id])->update(['status' => 'Completed']);
			return response()->json(array('status' => 'success'));
		}else{
			return response()->json(array('status' => 'failed'));
		}
		
	}
	
	/**
   * Function :withdrawExchangeRequest()
   * Function to cancel Return Request for Product.
   * Ayushma jain <ayushma.jain@gaurish.com> 16-04-2019
   */
  
	public function withdrawExchangeRequest(){
		
		$sub_order_id = isset($_POST['data']) ? $_POST['data'] :'';
		
		$orderDetail 	= 	new OrderDetail;
		$CheckStatus = $orderDetail->where(['id' => $sub_order_id,'status'=> 'ExchangeRequest'])->get();
		$updateStatus = 0;
		if(count($CheckStatus)>0)
		{
			$updateStatus = $orderDetail->where(['id' => $sub_order_id])->update(['status' => 'Completed']);
			return response()->json(array('status' => 'success'));
		}else{
			return response()->json(array('status' => 'failed'));
		}
		
	}
	
	/**
   * Function :withdrawCancelRequest()
   * Function to cancel Return Request for Product.
   * Ayushma jain <ayushma.jain@gaurish.com> 16-04-2019
   */
  
	public function withdrawCancelRequest(){
		
		$sub_order_id = isset($_POST['data']) ? $_POST['data'] :'';
		
		$orderDetail 	= 	new OrderDetail;
		$CheckStatus = $orderDetail->where(['id' => $sub_order_id,'status'=> 'CancelRequest'])->get();
		$updateStatus = 0;
		if(count($CheckStatus)>0)
		{
			$updateStatus = $orderDetail->where(['id' => $sub_order_id])->update(['status' => 'Deposit']);
			return response()->json(array('status' => 'success'));
		}else{
			return response()->json(array('status' => 'failed'));
		}
		
	}
	
	/**
   * Function :deleteProductReview()
   * Function to Delete Product Review From Comments table.
   * Ayushma jain <ayushma.jain@gaurish.com> 12-04-2019
   */
  
	public function deleteProductReview(){
		$id = isset($_POST['data']) ? $_POST['data'] :'';
		$deleteStatus = DB::table('comments')->where(['id'=>$id])->delete();
		if(count($deleteStatus)>0){
			return response()->json(array('status' => 'success'));
		}else{
			return response()->json(array('status' => 'failed'));
		}
		
	}
	
	/**
   * Function :checkRefundAccount()
   * Function to Check user have refund account or not Product Review From Comments table.
   * Ayushma jain <ayushma.jain@gaurish.com> 12-04-2019
   */
  
	public function checkRefundAccount(){
		$user_id = isset($_POST['data']) ? $_POST['data'] :'';
		$refundAccountData = DB::table('refund_account')->where(['user_id'=>$user_id])->get();
		if(count($refundAccountData)>0){
			return response()->json(array('status' => 'success'));
		}else{
			return response()->json(array('status' => 'failed'));
		}
		
	}
	public function searchProductOptionalData($combination,$option_array)
	{
		$matchLength=count($combination);
		$checkLength=0;
		if(count($option_array)>0)
		{
			foreach($option_array as $key => $rr)
			{
				$temp_arr = explode('+',$rr['value']);
				$checkLength=0;
				foreach($combination as $str)
				{
					//echo $str.'-'.$temp_arr[0].'+';
					if(in_array($str,$temp_arr))
					{
						$checkLength++;
					}
				}
				if($matchLength==$checkLength)
				{
					return $option_array[$key];
				}
			}
		}
	}

}