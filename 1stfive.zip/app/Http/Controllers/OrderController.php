<?php
namespace shopist\Http\Controllers;

use shopist\Http\Controllers\Controller;
use shopist\Models\Post;
use shopist\Models\PostExtra;
use Illuminate\Support\Facades\DB;
use shopist\Library\CommonFunction;
use shopist\Library\GetFunction;
use Carbon\Carbon;
use Session;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;
use shopist\Models\OrdersItem;
use Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\App;
use Excel;


class OrderController extends Controller
{
  public $classCommonFunction;
  public $classGetFunction;
  public $carbonObject;
  
  public function __construct(){
    $this->classCommonFunction  =  new CommonFunction();
    $this->classGetFunction     =  new GetFunction();
    $this->carbonObject         =  new Carbon();
  }
  
  /**
   * 
   * Order list content
   *
   * @param null
   * @return response view
   */
  public function orderListsContent(){
    $data = array();
    $data = $this->classCommonFunction->commonDataForAllPages();
    $get_shop_order_data = $this->getOrderList('all_order'); 
    
    $currentPage = LengthAwarePaginator::resolveCurrentPage();
    $col = new Collection( $get_shop_order_data );
    $perPage = 10;
    $currentPageSearchResults = $col->slice(($currentPage - 1) * $perPage, $perPage)->all();
    $order_object = new LengthAwarePaginator($currentPageSearchResults, count($col), $perPage);

    $order_object->setPath( route('admin.shop_orders_list') );

    $data['orders_list_data']  =  $order_object;
     
    return view('pages.admin.orders.order-list', $data);
  }
  
  /**
   * 
   * Order current date content
   *
   * @param null
   * @return response view
   */
  public function orderCurrentDateContent(){
    $data = array();
    $data = $this->classCommonFunction->commonDataForAllPages();
    $get_shop_order_data = $this->getOrderList('current_date_order');
    
    $currentPage = LengthAwarePaginator::resolveCurrentPage();
    $col = new Collection( $get_shop_order_data );
    $perPage = 10;
    $currentPageSearchResults = $col->slice(($currentPage - 1) * $perPage, $perPage)->all();
    $order_object = new LengthAwarePaginator($currentPageSearchResults, count($col), $perPage);

    $order_object->setPath( route('admin.shop_orders_list') );

    $data['orders_list_data']  =  $order_object;
     
    return view('pages.admin.orders.order-list', $data);
  }

  /**
   * 
   * Order details content
   *
   * @param order_id
   * @return response
   */
  public function orderDetailsPageContent( $params ){
    $data = array();
    $order_id = 0;
    $get_post = Post::where(['id' => $params, 'post_type' => 'shop_order'])->first();

    if(!empty($get_post) && $get_post->parent_id > 0){
      $order_id = $get_post->parent_id;
    }
    else{
      $order_id = $params;
    }

    $data = $this->classCommonFunction->commonDataForAllPages();
    $get_post_by_order_id     = Post::where(['id' => $params])->first();
    $get_postmeta_by_order_id = PostExtra::where(['post_id' => $order_id])->get();
    $get_orders_items         = OrdersItem::where(['order_id' => $params])->first();

    if($get_post_by_order_id->count() > 0 && $get_postmeta_by_order_id ->count() > 0 && $get_orders_items->count() >0){
      $order_date_format = new Carbon( $get_post_by_order_id->created_at);

      $order_data_by_id = get_customer_order_billing_shipping_info( $order_id );
      $order_data_by_id['_order_id']    = $get_post_by_order_id->id;
      $order_data_by_id['_order_date']  = $order_date_format->toDayDateTimeString();

      foreach($get_postmeta_by_order_id as $postmeta_row_data){
        if($postmeta_row_data->key_name === '_order_shipping_method'){
          $order_data_by_id[$postmeta_row_data->key_name] = $this->classCommonFunction->get_shipping_label($postmeta_row_data->key_value);
        }
        elseif($postmeta_row_data->key_name == '_customer_user'){
          $user_data = unserialize($postmeta_row_data->key_value);
          if($user_data['user_mode'] == 'guest'){
            $order_data_by_id['_member']  = array('name' => 'Guest', 'url' => '');
          }
          elseif($user_data['user_mode'] == 'login'){
            $user_details_by_id = get_user_details($user_data['user_id']);
            $order_data_by_id['_member']  = array('name' => $user_details_by_id['user_display_name'], 'url' => $user_details_by_id['user_photo_url']);
          }
        }
        elseif($postmeta_row_data->key_name == '_order_currency' || $postmeta_row_data->key_name == '_customer_ip_address' || $postmeta_row_data->key_name == '_customer_user_agent' || $postmeta_row_data->key_name == '_order_shipping_cost' || $postmeta_row_data->key_name == '_order_shipping_method' || $postmeta_row_data->key_name == '_payment_method' || $postmeta_row_data->key_name == '_payment_method_title' || $postmeta_row_data->key_name == '_order_tax' || $postmeta_row_data->key_name == '_order_total' || $postmeta_row_data->key_name == '_order_notes' || $postmeta_row_data->key_name == '_order_status' || $postmeta_row_data->key_name == '_order_discount' || $postmeta_row_data->key_name == '_order_coupon_code' || $postmeta_row_data->key_name == '_is_order_coupon_applyed' || $postmeta_row_data->key_name == '_final_order_shipping_cost' || $postmeta_row_data->key_name == '_final_order_tax' || $postmeta_row_data->key_name == '_final_order_total' || $postmeta_row_data->key_name == '_final_order_discount'){
          $order_data_by_id[$postmeta_row_data->key_name] = $postmeta_row_data->key_value;
        }
      } 

      $order_data_by_id['_ordered_items']  = json_decode( $get_orders_items->order_data, TRUE );
      $order_data_by_id['_order_history']  = $this->getOrderDownloadHistory( $params ); 
    }

    $data['order_data_by_id']  =   $order_data_by_id;
    
    return view('pages.admin.orders.order-details', $data);
  }

  
  /**
   * 
   * Get order list
   *
   * @param all order or current date order
   * @return array
   */
  public function getOrderList( $order_track ){
    $order_data = array();
    
    if(is_vendor_login() && Session::has('shopist_admin_user_id')){
      if($order_track == 'all_order'){
        $get_order  = DB::table('posts')
                      ->where(['posts.post_type' => 'shop_order'])
                      ->where(['vendor_orders.vendor_id' => Session::get('shopist_admin_user_id')])
                      ->join('vendor_orders', 'vendor_orders.order_id', '=', 'posts.id')
                      ->orderBy('posts.id', 'desc')
                      ->select('posts.*')
                      ->get()
                      ->toArray();
      }
      elseif($order_track == 'current_date_order'){
        $get_order  = DB::table('posts')
                      ->where(['posts.post_type' => 'shop_order'])
                      ->where(['vendor_orders.vendor_id' => Session::get('shopist_admin_user_id')])
                      ->whereDate('posts.created_at', '=', $this->carbonObject->today()->toDateString())
                      ->join('vendor_orders', 'vendor_orders.order_id', '=', 'posts.id')
                      ->orderBy('posts.id', 'desc')
                      ->select('posts.*')
                      ->get()
                      ->toArray();
      }
      if(count($get_order) >0){
        $order_data = $this->manageAllOrders( $this->classCommonFunction->objToArray( $get_order ));
      }
    }
    else{
      if($order_track == 'all_order'){
        $get_order = Post::where(['parent_id' => 0, 'post_type' => 'shop_order'])->orderBy('id', 'DESC')->get()->toArray();
      }
      elseif($order_track == 'current_date_order'){
        $get_order = Post::whereDate('created_at', '=', $this->carbonObject->today()->toDateString())->where(['parent_id' => 0, 'post_type' => 'shop_order'])->get()->toArray();
      }
      
      if(count($get_order) >0){
        $order_data = $this->manageAllOrders( $get_order );
      }
    }
    
    return $order_data;
  }
  
  /**
   * 
   * Manage all orders 
   *
   * @param order array
   * @return array
   */
  public function manageAllOrders( $get_order ){
    $order_data = array();
   
    if(count($get_order) > 0){
      foreach($get_order as $order){
        $order_postmeta = array();
        $get_postmeta_by_order_id = PostExtra::where(['post_id' => $order['id']])->get();
        
        if($get_postmeta_by_order_id->count() > 0){
          $date_format = new Carbon( $order['created_at']);

          $order_postmeta['_post_id']    = $order['id'];
          $order_postmeta['_order_date'] = $date_format->toDayDateTimeString();


          foreach($get_postmeta_by_order_id as $postmeta_row){
            if( $postmeta_row->key_name == '_order_status' || $postmeta_row->key_name == '_order_total' || $postmeta_row->key_name == '_final_order_total' || $postmeta_row->key_name == '_order_currency' ){
            $order_postmeta[$postmeta_row->key_name] = $postmeta_row->key_value;
            }
          }
        }
        
        $get_sub_order = get_vendor_sub_order_by_order_id($order['id']);
        $order_postmeta['_sub_order'] = array();
        
        if(count( $get_sub_order ) > 0){ 
          foreach($get_sub_order as $sub_order){
            $sub_order_postmeta = array();
            $get_postmeta_by_sub_order_id = PostExtra::where(['post_id' => $sub_order['parent_id']])->get();
            
            if($get_postmeta_by_sub_order_id->count() > 0){
              $sub_order_date_format = new Carbon( $sub_order['created_at']);

              $sub_order_postmeta['_post_id']    = $sub_order['id'];
              $sub_order_postmeta['_order_date'] = $sub_order_date_format->toDayDateTimeString();


              foreach($get_postmeta_by_sub_order_id as $sub_order_postmeta_row){
                if( $sub_order_postmeta_row->key_name == '_order_status' || $sub_order_postmeta_row->key_name == '_order_total' || $sub_order_postmeta_row->key_name == '_final_order_total' || $sub_order_postmeta_row->key_name == '_order_currency' ){
                $sub_order_postmeta[$sub_order_postmeta_row->key_name] = $sub_order_postmeta_row->key_value;
                }
              }
            }
            array_push($order_postmeta['_sub_order'], $sub_order_postmeta);
          }
        }
        
        array_push($order_data, $order_postmeta);
      }
    }
    return $order_data;
  }
  
   /**
   * 
   * Get order download history
   *
   * @param order_id
   * @return array
   */
  public function getOrderDownloadHistory( $order_id){
    $order_data = array();
    $get_order_data = DB::table('download_extras')
                      ->select('file_name', 'file_url', DB::raw('count(*) as total'))
                      ->where('order_id', $order_id)
                      ->groupBy('file_name', 'file_url')
                      ->get()->toArray();
    
    
    if(count($get_order_data) > 0){
      $order_data = $get_order_data;
    }
    
    return $order_data;
  }
  
  /**
   * 
   * Update order status
   *
   * @param order id
   * @return void
   */
  public function updateOrderStatus($order_id){
    if( Request::isMethod('post') && Session::token() == Input::get('_token')){
      $environment = App::environment();
      $email_options = get_emails_option_data();
      
      $data = array(
                    'key_value' => Input::get('change_order_status')
      );
      
      if( PostExtra::where(['post_id' => $order_id, 'key_name' => '_order_status'])->update( $data )){
        $get_email = get_customer_order_billing_shipping_info( $order_id );
        
        if($environment === 'production' && $email_options['cancelled_order']['enable_disable'] == true && Input::get('change_order_status') == 'cancelled'){
          
          $this->classGetFunction->sendCustomMail( array('source' => 'cancelled_order', 'email' => $get_email['_billing_email'], 'order_id' => $order_id) );
        }
        elseif($environment === 'production' && $email_options['processed_order']['enable_disable'] == true && Input::get('change_order_status') == 'processing'){
          $this->classGetFunction->sendCustomMail( array('source' => 'processed_order', 'email' => $get_email['_billing_email'], 'order_id' => $order_id) );
        }
        elseif($environment === 'production' && $email_options['completed_order']['enable_disable'] == true && Input::get('change_order_status') == 'completed'){
          $this->classGetFunction->sendCustomMail( array('source' => 'completed_order', 'email' => $get_email['_billing_email'], 'order_id' => $order_id) );
        }
        return redirect()->back();
      }
    }
  }
  
  /**
   * 
   * Redirect to order invoice
   *
   * @param null
   * @return void
   */
  public function redirectOrderInvoice( $params ){
    $order_id = 0;
    $get_post = Post::where(['id' => $params, 'post_type' => 'shop_order'])->first();
    

    if(!empty($get_post) && $get_post->parent_id > 0){
      $order_id = $get_post->parent_id;
    }
    else{
      $order_id = $params;
    }
    
    $get_post_by_order_id     = Post::where(['id' => $params])->first();
    $get_postmeta_by_order_id = PostExtra::where(['post_id' => $order_id])->get();
    $get_orders_items         = OrdersItem::where(['order_id' => $params])->first();

    if($get_post_by_order_id->count() > 0 && $get_postmeta_by_order_id ->count() > 0 && $get_orders_items->count() >0){
      $order_date_format = new Carbon( $get_post_by_order_id->created_at);

      $order_data_by_id = get_customer_order_billing_shipping_info( $order_id );
      $order_data_by_id['_order_id']    = $get_post_by_order_id->id;
      $order_data_by_id['_order_date']  = $order_date_format->toDayDateTimeString();

      foreach($get_postmeta_by_order_id as $postmeta_row_data){
        if($postmeta_row_data->key_name === '_order_shipping_method'){
          $order_data_by_id[$postmeta_row_data->key_name] = $this->classCommonFunction->get_shipping_label($postmeta_row_data->key_value);
        }
        elseif($postmeta_row_data->key_name == '_customer_user'){
          $user_data = unserialize($postmeta_row_data->key_value);
          if($user_data['user_mode'] == 'guest'){
            $order_data_by_id['_member']  = array('name' => 'Guest', 'url' => '');
          }
          elseif($user_data['user_mode'] == 'login'){
            $user_details_by_id = get_user_details($user_data['user_id']);
            $order_data_by_id['_member']  = array('name' => $user_details_by_id['user_display_name'], 'url' => $user_details_by_id['user_photo_url']);
          }
        }
        elseif($postmeta_row_data->key_name == '_order_currency' || $postmeta_row_data->key_name == '_customer_ip_address' || $postmeta_row_data->key_name == '_customer_user_agent' || $postmeta_row_data->key_name == '_order_shipping_cost' || $postmeta_row_data->key_name == '_order_shipping_method' || $postmeta_row_data->key_name == '_payment_method' || $postmeta_row_data->key_name == '_payment_method_title' || $postmeta_row_data->key_name == '_order_tax' || $postmeta_row_data->key_name == '_order_total' || $postmeta_row_data->key_name == '_order_notes' || $postmeta_row_data->key_name == '_order_status' || $postmeta_row_data->key_name == '_order_discount' || $postmeta_row_data->key_name == '_order_coupon_code' || $postmeta_row_data->key_name == '_is_order_coupon_applyed' || $postmeta_row_data->key_name == '_final_order_shipping_cost' || $postmeta_row_data->key_name == '_final_order_tax' || $postmeta_row_data->key_name == '_final_order_total' || $postmeta_row_data->key_name == '_final_order_discount'){
          $order_data_by_id[$postmeta_row_data->key_name] = $postmeta_row_data->key_value;
        }
      } 

      $order_data_by_id['_ordered_items']  = json_decode( $get_orders_items->order_data, TRUE );
    }
    
    return view('pages.admin.invoice.invoice', array('order_data_by_id' => $order_data_by_id));
  }
	/**
		* 
		* Redirect to order management screen
		*
		* @param null
		* @return void
	*/
	public function redirectOrderMgmt($type,$mode='view')
	{
		$search='';
		if(isset($_GET['search']))
		{
			$search=$_GET['search'];
		}
		$data = array();
		$common_obj  = new CommonFunction();
		$data = $common_obj->commonDataForAllPages();
		$data['type'] = $type;
		$data['search'] = $search;
		$data['order_data'] = array();
		$courier_code_list='';
		$courier_code_arr=array();
		$courier_code =  DB::table('courier_code')->select('*')->get()->toArray();;
		if(count($courier_code) > 0)
		{
			foreach($courier_code as $code)
			{
				$courier_code_list.="<option value='".$code->courier_code."'>".$code->courier_name."</option> ";
				$courier_code_arr[$code->courier_code]=$code->courier_name;
			}
		}
		$data['courier_code_list']	= 	$courier_code_list;
		$data['courier_code_arr'] 	=	$courier_code_arr;
		if(empty($search))
		{
			$get_order_data = DB::table('order_detail')
					->where('seller_id', Session::get('shopist_admin_user_id'))
					->where('status', $type)
					->join('orders', 'orders.id', '=', 'order_detail.order_id')
					->join('users', 'users.id', '=', 'orders.user_id')
                    ->orderBy('order_detail.id', 'desc')
                    ->select('order_detail.*', 'orders.*', 'order_detail.id as subOrderId', 'users.display_name')
                    ->get()->toArray();
		}
		else
		{
			$seller=Session::get('shopist_admin_user_id');
			$get_order_data = DB::table('order_detail')
					->where(function($query) use ($seller,$type){
						$query->where('seller_id',$seller);
						$query->where('status', $type);
					})
					->where(function($query) use ($search){
						$query->Where('orders.shipping_receiver_name','like', "%".$search."%");
						$query->orWhere('orders.shipping_address_1','like', "%".$search."%");
						$query->orWhere('orders.shipping_address_2','like', "%".$search."%");
						$query->orWhere('orders.shipping_contact_1','like', "%".$search."%");
					})
					->join('orders', 'orders.id', '=', 'order_detail.order_id')
					->join('users', 'users.id', '=', 'orders.user_id')
                    ->orderBy('order_detail.id', 'desc')
                    ->select('order_detail.*', 'orders.*', 'order_detail.id as subOrderId', 'users.display_name')
                    ->get()->toArray();

		}
		if(count($get_order_data) > 0){
			$data['order_data'] = $get_order_data;
		}
		if($mode=='view')
		{
			$data['WaitDepositCount']=$this->getOrderCount(Session::get('shopist_admin_user_id'),'WaitDeposit');
			$data['DepositCount']=$this->getOrderCount(Session::get('shopist_admin_user_id'),'Deposit');
			$data['PreparedCount']=$this->getOrderCount(Session::get('shopist_admin_user_id'),'Prepared');
			$data['ShippedCount']=$this->getOrderCount(Session::get('shopist_admin_user_id'),'Shipped');
			$data['DeliveredCount']=$this->getOrderCount(Session::get('shopist_admin_user_id'),'Delivered');
			return view('pages.admin.seller_orders.order-list', $data);
		}
		else
		{
			return $data;
		}
	}
	public function getOrderCount($seller_id,$type)
	{
		$total ='';
		$get_order_data = DB::table('order_detail')
					->where('seller_id',$seller_id)
					->where('status', $type)
                    ->select(DB::raw('count(*) as total'))
                    ->get()->toArray();
		if(count($get_order_data) > 0){
			$total = $get_order_data[0]->total;
		}
		return $total;
	}
	/**
		* 
		* Redirect to cancel order management screen
		*
		* @param null
		* @return void
	*/
	public function redirectCancelMgmt($type)
	{
		$search='';
		if(isset($_GET['search']))
		{
			$search=$_GET['search'];
		}
		$data = array();
		$common_obj  = new CommonFunction();
		$data = $common_obj->commonDataForAllPages();
		$data['type'] = $type;
		$data['search'] = $search;
		$data['order_data'] = array();
		if(empty($search))
		{
			$get_order_data = DB::table('order_detail')
					->where('seller_id', Session::get('shopist_admin_user_id'))
					->where('status', $type)
					->join('orders', 'orders.id', '=', 'order_detail.order_id')
					->join('users', 'users.id', '=', 'orders.user_id')
                    ->orderBy('order_detail.id', 'desc')
                    ->select('order_detail.*', 'orders.*', 'order_detail.id as subOrderId', 'users.display_name')
                    ->get()->toArray();
		}
		else
		{
			$seller=Session::get('shopist_admin_user_id');
			$get_order_data = DB::table('order_detail')
					->where(function($query) use ($seller,$type){
						$query->where('seller_id',$seller);
						$query->where('status', $type);
					})
					->where(function($query) use ($search){
						$query->Where('orders.shipping_receiver_name','like', "%".$search."%");
						$query->orWhere('orders.shipping_address_1','like', "%".$search."%");
						$query->orWhere('orders.shipping_address_2','like', "%".$search."%");
						$query->orWhere('orders.shipping_contact_1','like', "%".$search."%");
					})
					->join('orders', 'orders.id', '=', 'order_detail.order_id')
					->join('users', 'users.id', '=', 'orders.user_id')
                    ->orderBy('order_detail.id', 'desc')
                    ->select('order_detail.*', 'orders.*', 'order_detail.id as subOrderId', 'users.display_name')
                    ->get()->toArray();

		}
		if(count($get_order_data) > 0){
			$data['order_data'] = $get_order_data;
		}
		$data['CancelRequestCount']=$this->getOrderCount(Session::get('shopist_admin_user_id'),'CancelRequest');
		$data['CancelProcessingCount']=$this->getOrderCount(Session::get('shopist_admin_user_id'),'CancelProcessing');
		$data['CancelFailedCount']=$this->getOrderCount(Session::get('shopist_admin_user_id'),'CancelFailed');
		$data['CancelCompleteCount']=$this->getOrderCount(Session::get('shopist_admin_user_id'),'CancelComplete');
		return view('pages.admin.seller_orders.cancel-order-list', $data);
	}
	/**
		* 
		* Redirect to return order management screen
		*
		* @param null
		* @return void
	*/
	public function redirectReturnMgmt($type)
	{
		$search='';
		if(isset($_GET['search']))
		{
			$search=$_GET['search'];
		}
		$data = array();
		$common_obj  = new CommonFunction();
		$data = $common_obj->commonDataForAllPages();
		$data['type'] = $type;
		$data['search'] = $search;
		$data['order_data'] = array();
		if(empty($search))
		{
			$get_order_data = DB::table('order_detail')
					->where('seller_id', Session::get('shopist_admin_user_id'))
					->where('status', $type)
					->join('orders', 'orders.id', '=', 'order_detail.order_id')
					->join('users', 'users.id', '=', 'orders.user_id')
                    ->orderBy('order_detail.id', 'desc')
                    ->select('order_detail.*', 'orders.*', 'order_detail.id as subOrderId', 'users.display_name')
                    ->get()->toArray();
		}
		else
		{
			$seller=Session::get('shopist_admin_user_id');
			$get_order_data = DB::table('order_detail')
					->where(function($query) use ($seller,$type){
						$query->where('seller_id',$seller);
						$query->where('status', $type);
					})
					->where(function($query) use ($search){
						$query->Where('orders.shipping_receiver_name','like', "%".$search."%");
						$query->orWhere('orders.shipping_address_1','like', "%".$search."%");
						$query->orWhere('orders.shipping_address_2','like', "%".$search."%");
						$query->orWhere('orders.shipping_contact_1','like', "%".$search."%");
					})
					->join('orders', 'orders.id', '=', 'order_detail.order_id')
					->join('users', 'users.id', '=', 'orders.user_id')
                    ->orderBy('order_detail.id', 'desc')
                    ->select('order_detail.*', 'orders.*', 'order_detail.id as subOrderId', 'users.display_name')
                    ->get()->toArray();

		}
		if(count($get_order_data) > 0){
			$data['order_data'] = $get_order_data;
		}
		$data['ReturnRequestCount']=$this->getOrderCount(Session::get('shopist_admin_user_id'),'ReturnRequest');
		$data['ReturnCollectionCount']=$this->getOrderCount(Session::get('shopist_admin_user_id'),'ReturnCollection');
		$data['ReturnRefundProgressCount']=$this->getOrderCount(Session::get('shopist_admin_user_id'),'ReturnRefundProgress');
		$data['ReturnRefundFailedCount']=$this->getOrderCount(Session::get('shopist_admin_user_id'),'ReturnRefundFailed');
		$data['ReturnCompleteCount']=$this->getOrderCount(Session::get('shopist_admin_user_id'),'ReturnComplete');
		return view('pages.admin.seller_orders.return-order-list', $data);
	}
		/**
		* 
		* Redirect to exchange order management screen
		*
		* @param null
		* @return void
	*/
	public function redirectExchangeMgmt($type)
	{
		$search='';
		if(isset($_GET['search']))
		{
			$search=$_GET['search'];
		}
		$data = array();
		$common_obj  = new CommonFunction();
		$data = $common_obj->commonDataForAllPages();
		$data['type'] = $type;
		$data['search'] = $search;
		$data['order_data'] = array();
		$courier_code_list='';
		$courier_code_arr=array();
		$courier_code =  DB::table('courier_code')->select('*')->get()->toArray();;
		if(count($courier_code) > 0)
		{
			foreach($courier_code as $code)
			{
				$courier_code_list.="<option value='".$code->courier_code."'>".$code->courier_name."</option> ";
				$courier_code_arr[$code->courier_code]=$code->courier_name;
			}
		}
		$data['courier_code_list']	= 	$courier_code_list;
		$data['courier_code_arr'] 	=	$courier_code_arr;
		if(empty($search))
		{
			$get_order_data = DB::table('order_detail')
					->where('seller_id', Session::get('shopist_admin_user_id'))
					->where('status', $type)
					->join('orders', 'orders.id', '=', 'order_detail.order_id')
					->join('users', 'users.id', '=', 'orders.user_id')
                    ->orderBy('order_detail.id', 'desc')
                    ->select('order_detail.*', 'orders.*', 'order_detail.id as subOrderId', 'users.display_name')
                    ->get()->toArray();
		}
		else
		{
			$seller=Session::get('shopist_admin_user_id');
			$get_order_data = DB::table('order_detail')
					->where(function($query) use ($seller,$type){
						$query->where('seller_id',$seller);
						$query->where('status', $type);
					})
					->where(function($query) use ($search){
						$query->Where('orders.shipping_receiver_name','like', "%".$search."%");
						$query->orWhere('orders.shipping_address_1','like', "%".$search."%");
						$query->orWhere('orders.shipping_address_2','like', "%".$search."%");
						$query->orWhere('orders.shipping_contact_1','like', "%".$search."%");
					})
					->join('orders', 'orders.id', '=', 'order_detail.order_id')
					->join('users', 'users.id', '=', 'orders.user_id')
                    ->orderBy('order_detail.id', 'desc')
                    ->select('order_detail.*', 'orders.*', 'order_detail.id as subOrderId', 'users.display_name')
                    ->get()->toArray();

		}
		if(count($get_order_data) > 0){
			$data['order_data'] = $get_order_data;
		}
		$data['ExchangeRequestCount']=$this->getOrderCount(Session::get('shopist_admin_user_id'),'ExchangeRequest');
		$data['ExchangeCollectionCount']=$this->getOrderCount(Session::get('shopist_admin_user_id'),'ExchangeCollection');
		$data['ExchangeCollectionCompleteCount']=$this->getOrderCount(Session::get('shopist_admin_user_id'),'ExchangeCollectionComplete');
		$data['ExchangeRedeployementCount']=$this->getOrderCount(Session::get('shopist_admin_user_id'),'ExchangeRedeployement');
		$data['ExchangeCompleteCount']=$this->getOrderCount(Session::get('shopist_admin_user_id'),'ExchangeComplete');
		return view('pages.admin.seller_orders.exchange-order-list', $data);
	}
	public function downloadOrderExcel()
	{
		$type=$_GET['type'];
		$page=$_GET['page'];
		$orderStatusArr = array('WaitDeposit'=>'입금대기','Deposit'=>'결제완료','Prepared'=>'배송준비중','Shipped'=>'배송중','Delivered'=>'배송완료','CancelRequest'=>'취소요청','CancelProcessing'=>'취소처리중','CancelFailed'=>'취소처리실패','CancelComplete'=>'취소완료','ExchangeRequest'=>'교환요청','ExchangeCollection'=>'수거중','ExchangeCollectionComplete'=>'수거완료','ExchangeRedeployement'=>'재배송중','ExchangeComplete'=>'교환완료','ReturnRequest'=>'반품요청','ReturnCollection'=>'수거중','ReturnRefundProgress'=>'환불진행중','ReturnRefundFailed'=>'환불처리실패','ReturnComplete'=>'반품완료');
		if(!empty($type))
		{
			$result = $this->redirectOrderMgmt($type,'array');
			$filename=$orderStatusArr[$type];
			$data = array();
			if(count($result['order_data'])>0)
			{
				$a=1;
				foreach($result['order_data'] as $order)
				{
					$product_detail=json_decode($order->product_detail);
					$row['S.No.']=$a;
					$row['주문번호/시각']=date('Ymd',strtotime($order->created_at)).''.$order->order_id.'   '.$order->created_at.'   '.$order->display_name;
					$row['주문상품']=$product_detail->product_name .'   '.$product_detail->product_desc;
					$row['상품금액']=$product_detail->product_price.'원';
					$row['상태']=$orderStatusArr[$order->status];
					if($page=='order')
					{
						$row['운송장번호']='';
						if($order->status=='Shipped' || $order->status=='Delivered')
						{
							$row['운송장번호']=@$courier_code_arr[$order->shipping_company].'   '.$order->shipping_number;
						}
					}
					elseif($page=='cancel')
					{
						$row['취소요청일']=$order->cancellation_date;
					}
					elseif($page=='return')
					{
						$return_detail = json_decode($order->return_detail);
						$row['사유']=@$return_detail->reason_text;
					}
					elseif($page=='exchange')
					{
						$exchange_detail = json_decode($order->exchange_detail);
						$row['사유']=$exchange_detail->reason_text;
						if($order->status=='ExchangeRedeployement' || $order->status=='ExchangeComplete')
						{
							$row['운송장번호']=@$courier_code_arr[$order->shipping_company].' '.$order->shipping_number; 
						}
						else
						{
							$row['운송장번호']=$exchange_detail->reason_type.' '.$exchange_detail->reason_text;
						}
					}
					
					$row['배송']=$order->shipping_pay_amt.'원';
					$row['배송정보']=$order->shipping_receiver_name.' / '.$order->shipping_contact_1.' '.$order->shipping_address_1.'   '.$order->shipping_address_2.'  '.$order->shipping_zip;
					$total= $order->product_pay_amt+$order->shipping_pay_amt;
					$row['결제내역']=trans('admin.total_payment_amount').': '.$order->total_pay_amount.'원  '.trans('admin.subtotal_label').': '.$total.'원 '.trans('admin.payment_method').': '.$order->payment_method;
					array_push($data,$row);
					$a++;
				}
			}
			// Generate and return the spreadsheet
			return Excel::create($filename, function($excel) use ($data,$filename) {

				$excel->sheet($filename, function($sheet) use ($data)
				{
					$sheet->fromArray($data);
				});
			})->download('xls');
		}
	}
	public function redirectSalesReport()
	{
		$data = array();
		$common_obj  = new CommonFunction();
		$data = $common_obj->commonDataForAllPages();
		$mode=isset($_GET['type']) ? $_GET['type'] :'day';
		$start_date=isset($_GET['start_date']) ? $_GET['start_date'] :date('Y-m-01');
		$end_date=isset($_GET['end_date']) ? $_GET['end_date'] :date('Y-m-d');
		$year=isset($_GET['year']) ? $_GET['year'] :date('Y');
		if($mode=='day')
		{
			$getReportData  = DB::table('order_detail')
				  ->where('created_at','>=', $start_date)
				  ->where('created_at','<=', $end_date)
				  ->where(['seller_id' => Session::get('shopist_admin_user_id')])
				  ->orderBy('group_name', 'desc')
				  ->groupBy('group_name')
				  ->select(DB::raw('COUNT(*) as no_of_order'),DB::raw('SUM(pointGain) as total_pointGain'),DB::raw('SUM(total_pay_amt) as total_pay'),DB::raw('DATE(created_at) as group_name'))
				  ->get()
				  ->toArray();
		}
		else
		{
			$start_date=date($year.'-01-01');
			$end_date=date($year.'-12-31');
			$getReportData  = DB::table('order_detail')
				  ->where('created_at','>=', $start_date)
				  ->where('created_at','<=', $end_date)
				  ->where(['seller_id' => Session::get('shopist_admin_user_id')])
				  ->orderBy('group_name', 'desc')
				  ->groupBy('group_name')
				  ->select(DB::raw('COUNT(*) as no_of_order'),DB::raw('SUM(pointGain) as total_pointGain'),DB::raw('SUM(total_pay_amt) as total_pay'),DB::raw('DATE_FORMAT(created_at,"%Y-%m") as group_name'))
				  ->get()
				  ->toArray();
		}
		//print_r($getReportData);
		$data['result'] = $getReportData;
		$data['type'] = $mode;
		$data['year'] = $year;
		$data['start_date'] = $start_date;
		$data['end_date'] = $end_date;
		return view('pages.admin.seller_orders.sales-report', $data);
	}
}