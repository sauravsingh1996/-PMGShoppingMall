<?php

namespace shopist\Http\Controllers\Auth;

use shopist\Http\Controllers\Controller;
use shopist\Models\Role;
use shopist\Models\User;
use shopist\Models\RoleUser;
use shopist\Models\UserActionLogs;
use shopist\Models\UsersDetail;
use shopist\Models\Option;
use shopist\Models\VendorPackage;
use Illuminate\Support\Facades\Input;
use Validator;
use Request;
use Session;
use Illuminate\Support\Facades\Lang;
use shopist\Models\ManageLanguage;
use shopist\Library\CommonFunction;
use shopist\Models\UserRolePermission;
use shopist\Http\Controllers\OptionController;
use shopist\Library\GetFunction;
use Illuminate\Support\Facades\App;
use shopist\Models\Consultation;
use Illuminate\Support\Facades\URL;


//use Illuminate\Http\Request;

class ConsultationController extends Controller
{
 
    /*
    |--------------------------------------------------------------------------
    | Consultation Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation.
    |
    */
  
    public $classCommonFunction;
    public $classGetFunction;
    public $settingsData = array();
    public $recaptchaData = array();
    public $option;
    public $env;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
      $this->middleware('verifyLoginPage');
      $this->classCommonFunction  =  new CommonFunction();
      $this->classGetFunction     =   new GetFunction();
      $this->recaptchaData     =  get_recaptcha_data();
      $this->option  = new OptionController();
      $this->env = App::environment();
      
      $this->settingsData['_settings_data']   = $this->option->getSettingsData();
    }

    /**
     * 
     * Function to save rental product consultations request data.
     * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
     * Last Updated: 08 Feb 2019
     * @param null
     * @return response
     */
      
    public function saveConsultationRequest()
    {
      if( Request::isMethod('post') && Session::token() == Input::get('_mytoken')) 
      {
        // Getting all input data
        $postData = Input::all();
       
        $rules = [
          'consultation_available_phone_numbers'  => 'required',
          'consultation_time' => 'required',
          'object_id'  => 'required', //product id
          'product_color'  => 'required' 
        ];

        $messages = [
          'consultation_available_phone_numbers.required' => Lang::get('validation.consultation_available_phone_numbers_required'),
          'consultation_time.required' => Lang::get('validation.consultation_time_required'),
          'object_id.required' => Lang::get('validation.missing_required_parameter'),
          'product_color.required' => Lang::get('validation.missing_required_parameter')
        ];   

        $validator = Validator:: make($postData, $rules, $messages);
        
        if($validator->fails())
        {
          return redirect()-> back()
          ->withInput()
          ->withErrors( $validator );
        } else {
          
          // Getting logged in User Id.
          $loggedInUserId = (Session::has('shopist_frontend_user_id')) ? Session::get('shopist_frontend_user_id') : 0;
   
          // Allow user to make request only when logged in.
          if ($loggedInUserId > 0)
          {
            // Getting post form data.
            $availablePhoneNumber = trim(Input::get('consultation_available_phone_numbers'));   
            $consultationTime = trim(Input::get('consultation_time'));   
            $productColor = trim(Input::get('product_color'));   
            $productId = trim(Input::get('object_id'));   
            
            // Loading instance of Consultation Model.
            $Consultation = new Consultation;

            // If there's a record exist with given details already in table, Update record detail to given once.
            // If no matching record exists, create one.
            $consultationUpdateOrCreateObj = $Consultation->updateOrCreate(
              [
              'bintApplicantUserId' => $loggedInUserId,
              'varAvailablePhoneNumber' => $availablePhoneNumber,
              'varConsultationRequestTime' => $consultationTime,
              'bintProductId' => $productId
              ],
              [
              'bintApplicantUserId' => $loggedInUserId,
              'varAvailablePhoneNumber' => $availablePhoneNumber,
              'varConsultationRequestTime' => $consultationTime,
              'varProductColorName' => $productColor,
              'bintProductId' => $productId,
              'updated_at' => date('Y-m-d h:i:s')

              ]
            );

            //Getting Last inserted Id
            $applicationId = $consultationUpdateOrCreateObj->bintApplicationId;
   
            // Defining Data array with empty array.
            $data  = array(); 

            $this->classCommonFunction->set_frontend_lang();

            $data['target']   =   'empty_check';
            $get_data         =   $this->classCommonFunction->get_dynamic_frontend_content_data( $data );
            $get_data['is_enable_recaptcha'] = $this->recaptchaData['enable_recaptcha_for_user_registration'];
            $get_data['settings_data'] = global_settings_data();

            // Calling this function to get consultaion request data.  
            $get_data['consultationData'] =  $Consultation->getConsultaionProductData($applicationId);
            if (!empty($get_data['consultationData'])){
              // Redirect to consultation request thank-you page
              return view('pages.auth.consultation-request-thank-you')->with($get_data);
            } else {
              return redirect()->route('user-login-page');
            }
          } else {
            // Redirecting to Login Page.
            return redirect()->route('user-login-page');
          }
        }
      } else {
        return redirect()->back();
      }
    }
}
