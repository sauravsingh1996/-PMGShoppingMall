<?php
namespace shopist\Http\Controllers;

use shopist\Http\Controllers\Controller;
use Request;
use Session;
use Validator;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;
use shopist\Models\Term;
use shopist\Models\TermExtra;
use Illuminate\Support\Facades\Input;  
use Illuminate\Support\Facades\Lang;
use shopist\Models\Post;
use shopist\Models\PostExtra;
use shopist\Models\Product;
use shopist\Models\ProductExtra;
use shopist\Models\ProductGovtCategory;
use shopist\Models\ObjectRelationship;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;
use shopist\Http\Controllers\VendorsController;
use shopist\Http\Controllers\OptionController;
use shopist\Library\CommonFunction;
use Carbon\Carbon;
use shopist\Models\SaveCustomDesign;
use Excel;


class ProductsController extends Controller
{
  public $option;
  public $carbonObject;
  public $classCommonFunction;
  public $cat_list_arr = array();
  public $parent_id = 0;
  public $vendors;


  public function __construct(){
    $this->option               =   new OptionController();
    $this->carbonObject         =   new Carbon();
    $this->classCommonFunction  =   new CommonFunction();
    $this->vendors              =   new VendorsController();
  } 
  
  /**
   * 
   * Product add content
   *
   * @param null
   * @return response view
   */
  public function productAddContent(){
    $data = array();
    $data = $this->classCommonFunction->commonDataForAllPages();
    $get_data = $this->createProductContentData( $data );
     
    return view('pages.admin.product.add-product-content', $get_data);
  }
  
  /**
   * 
   * Product update content
   *
   * @param null
   * @return response view
   */
  public function productUpdateContent( $params )
  {
    $post_author_id = 0;
    if((is_vendor_login() || is_admin_login()) 
       && (Session::has('shopist_admin_user_id') && is_numeric(Session::get('shopist_admin_user_id')))
    ){
      $post_author_id = Session::get('shopist_admin_user_id');
    }

    $where = ['author_id' => $post_author_id, 'status' => '1'];  
      
    $get_post  =  Product :: where('slug', $params)->where($where)->get()->toArray();
    
    if(count($get_post) > 0) 
    {
      $data = array();
      $get_available_attribute =  array();
      $product_id = $get_post[0]['id'];
      
      $data = $this->classCommonFunction->commonDataForAllPages();
      $get_available_attribute  =  $this->getAllAttributes( $product_id );

      $data['attrs_list_data_by_product']     =   $get_available_attribute;
      $data['product_post_data']              =   $this->getProductDataById($product_id,'admin');
      $data['role_based_pricing_data']        =   get_role_based_pricing_by_product_id($product_id);
      $data['variation_data']                 =   $this->classCommonFunction->get_variation_and_data_by_product_id( $product_id );
      $data['custom_designer_settings_data']  =   $this->option->getCustomDesignerSettingsData();
      $get_variation_data = $this->classCommonFunction->get_variation_by_product_id( $product_id );

      if(!empty($get_variation_data)){
        $data['variation_json']  =  json_encode($get_variation_data);
      }
      else{
        $data['variation_json'] = null;
      }

      $get_post_attr  =  PostExtra::where(['post_id' => $product_id, 'key_name' => '_attribute_post_data'])->first();

      if(!empty($get_post_attr)){
        $data['attribute_post_meta_by_id'] = json_decode($get_post_attr->key_value);
      }
      else{
        $data['attribute_post_meta_by_id'] = null;
      }
      $data['designer_hf_data'] = array();
       
      $get_data = SaveCustomDesign ::where('product_id', $product_id)->first();

      if(!empty($get_data) && $get_data->count() > 0){
        $data['design_json_data']  =  $get_data['design_data'];
      }
      else{
        $data['design_json_data']  =  '';
      }

      $data['art_cat_lists_data']  =   $this->getTermData( 'designer_cat', false, null, 1 );
      $data['fonts_list']  =   $this->getFontsList(false, null, 1);
      $data['shape_list']  =   $this->getShapeList(false, null, 1);
      
      $generalTabActiveClass = '';
      $featureTabActiveClass = '';
      $customizeBtn          = 'style=display:none;';
      $tabSettings           = array();

      if($data['product_post_data']['post_type'] == 'simple_product' || $data['product_post_data']['post_type'] == 'downloadable_product'){
        $generalTabActiveClass = 'show active';
      }
      elseif($data['product_post_data']['post_type'] == 'customizable_product' || $data['product_post_data']['post_type'] == 'rental_product'){
        $generalTabActiveClass = 'show active';
        $customizeBtn          = 'style=display:none;';
      }
      elseif($data['product_post_data']['post_type'] == 'configurable_product'){
        $featureTabActiveClass = 'show active';
      }

      $tabSettings['generalTab']   = $generalTabActiveClass;
      $tabSettings['featureTab']   = $featureTabActiveClass;
      $tabSettings['btnCustomize'] = $customizeBtn;

      $data['tabSettings'] = $tabSettings;

      // Calling this function to get all sub categoriesa and parent categories.
      $data['allCategories']       =   $this->getAllSubCategoriesAndParentCategoriesIdByProductId($product_id);
      
      $data['selected_large_cat'] = isset($data['allCategories']['large_cat']['selected'])?$data['allCategories']['large_cat']['selected']:0;
      $data['selected_middle_cat'] = isset($data['allCategories']['middle_cat']['selected'])?$data['allCategories']['middle_cat']['selected']:0;
      $data['selected_small_cat'] = isset($data['allCategories']['small_cat']['selected'])?$data['allCategories']['small_cat']['selected']:0;
      $data['selected_detail_cat'] = isset($data['allCategories']['detail_cat']['selected'])?$data['allCategories']['detail_cat']['selected']:0;

      $data['selected_brand']    =   $this->getSelectedBrandByObjectId( $product_id );
      
      // Calling this function to get all Large categories list by parent cat id 0.
      $data['largeCategories'] = $this->getCategoriesByParentCatId(0);

      /*if ($data['selected_large_cat'] > 0)
       $data['middleCategories'] = $this->getCategoriesByParentCatId($data['selected_large_cat']);

     if ($data['selected_middle_cat'] > 0)
       $data['smallCategories'] = $this->getCategoriesByParentCatId($data['selected_middle_cat']);

     if ($data['selected_small_cat'] > 0)
       $data['detailCategories'] = $this->getCategoriesByParentCatId($data['selected_small_cat']);
      
     */

      $upsell_products = array();
      if(count(get_upsell_products($product_id)) > 0){
        foreach(get_upsell_products($product_id) as $upsell_ids){
          array_push($upsell_products, get_product_title($upsell_ids). ' #'.$upsell_ids);
        }
      }

      $data['upsell_products'] = json_encode( $upsell_products );

      $crosssell_products = array();
      if(count(get_crosssell_products($product_id)) > 0){
        foreach(get_crosssell_products($product_id) as $crosssell_ids){
          array_push($crosssell_products, get_product_title($crosssell_ids). ' #'.$crosssell_ids);
        }
      }

      $data['crosssell_products'] = json_encode( $crosssell_products );
      $get_data = $this->createProductContentData( $data );
   
      return view('pages.admin.product.update-product-content', $get_data);
    }
    else{
      return view('errors.no_data');
    }
  }
  
  /**
   * 
   * Product list content
   *
   * @param null
   * @return response view
   */
  public function productListContent( $params ){

    $data = array();
    $productSearchTerm = '';
    $pType = 'all';
      
    if(isset($_GET['pType']) && $_GET['pType'] != ''){
      $pType = $_GET['pType'];
    }  
    if(isset($_GET['productSearchTerm']) && $_GET['productSearchTerm'] != ''){
      $productSearchTerm = $_GET['productSearchTerm'];
    }
    
    $perPage=(isset($_GET['perPage']))?$_GET['perPage']:10;
    $data = $this->classCommonFunction->commonDataForAllPages();
   
    // Calling this functions to get only active products whose products.status=1.
    $data['product_all_data']  =  $this->getProductListViewPageData(true, $productSearchTerm, 1, $params, $perPage, $pType);

    $data['search_value']      =  $productSearchTerm;
    $data['per_page']      =  $perPage;
    $data['pType']      =  $pType;
     
    return view('pages.admin.product.product-list', $data);
  }

  /**
   * 
   * Product categories list content
   *
   * @param null
   * @return response view
   */
  public function productCategoriesListContent(){
    $data = array();
    $search_value = '';
        
    if(isset($_GET['term_cat']) && $_GET['term_cat'] != ''){
      $search_value = $_GET['term_cat'];
    }
    
    $data = $this->classCommonFunction->commonDataForAllPages();
    $data['cat_list_data']           =  $this->getTermData( 'product_cat', true, $search_value, -1 );
    $data['only_cat_name']           =  $this->get_categories_name_for_list('product_cat');
    $data['search_value']            =  $search_value;
    $data['action']                  =  route('admin.product_categories_list');
    
    return view('pages.admin.categories-list', $data);
  }
  
  /**
   * 
   * Product tags list content
   *
   * @param null
   * @return response view
   */
  public function productTagsListContent(){
    $data = array();
    $search_value = '';
      
    if(isset($_GET['term_tag']) && $_GET['term_tag'] != ''){
      $search_value = $_GET['term_tag'];
    }
    
    $data = $this->classCommonFunction->commonDataForAllPages();
    $data['tag_list_data']   =  $this->getTermData( 'product_tag', true, $search_value, -1 );
    $data['search_value']    =  $search_value;
    
    return view('pages.admin.product.product-tags-list', $data);
  }
  
  /**
   * 
   * Product attributes list content
   *
   * @param null
   * @return response view
   */
  public function productAttributesListContent(){
    $data = array();
    $search_value = '';
      
    if(isset($_GET['term_attrs']) && $_GET['term_attrs'] != ''){
      $search_value = $_GET['term_attrs'];
    }
    
    $data = $this->classCommonFunction->commonDataForAllPages();
    $data['attribute_list_data']   =  $this->getTermData( 'product_attr', true, $search_value, -1 );
    $data['search_value']          =  $search_value;
    
    return view('pages.admin.product.product-attribute-list', $data);
  }
  
  /**
   * 
   * Product colors list content
   *
   * @param null
   * @return response view
   */
  public function productColorsListContent(){
    $data = array();
    $search_value = '';
      
    if(isset($_GET['term_colors']) && $_GET['term_colors'] != ''){
      $search_value = $_GET['term_colors'];
    }
    
    $data = $this->classCommonFunction->commonDataForAllPages();
    $data['colors_list_data']   =   $this->getTermData( 'product_colors', true, $search_value, -1 );
    $data['search_value']       =   $search_value;
    
    return view('pages.admin.product.product-colors-list', $data);
  }
  
  /**
   * 
   * Product sizes list content
   *
   * @param null
   * @return response view
   */
  public function productSizesListContent(){
    $data = array();
    $search_value = '';
      
    if(isset($_GET['term_sizes']) && $_GET['term_sizes'] != ''){
      $search_value = $_GET['term_sizes'];
    }
    
    $data = $this->classCommonFunction->commonDataForAllPages();
    $data['sizes_list_data']   =   $this->getTermData( 'product_sizes', true, $search_value, -1 );
    $data['search_value']      =   $search_value;
    
    return view('pages.admin.product.product-sizes-list', $data);
  }

  /**
   * 
   * Product comments list content
   *
   * @param null
   * @return response view
   */
  public function productCommentsListContent(){
    $data = array();
    
    $data = $this->classCommonFunction->commonDataForAllPages();
    $data['product_comments'] = $this->getProductCommentsList();
    
    return view('pages.admin.product.comments-list', $data);
  }

  
  /**
   * 
   * Get term data
   *
   * @param term type, pagination, search value, status flag
   * @param term type required
   * @param pagination required. Boolean type TRUE or FALSE, by default false
   * @param search value optional
   * @param status flag by default -1. -1 for all data, 1 for status enable and 0 for disable status
   * @return array
   */
  public function getTermData( $term_type, $pagination = false, $search_val = null, $status_flag = -1){
    $term_data = array();
    
    if($status_flag == -1){
        $where = ['type' => $term_type];
    }
    else{
        $where = ['type' => $term_type, 'status' => $status_flag];
    }
        
    if($search_val && $search_val != ''){
      $get_term_data = Term:: where($where)
                       ->where('name', 'LIKE', $search_val.'%')
                       ->orderBy('term_id', 'desc')
                       ->get()
                       ->toArray();
    }
    else{
      $get_term_data = Term:: where($where)
                       ->orderBy('term_id', 'desc')
                       ->get()
                       ->toArray();
    }
      
    if(count($get_term_data) >0){
      foreach($get_term_data as $term){
        $term_extra = TermExtra:: where(['term_id' => $term['term_id']])
                      ->get();
       
        if(!empty($term_extra) && $term_extra->count() > 0){
          foreach($term_extra as $term_extra_row){
            
            if(!empty($term_extra_row) && $term_extra_row->key_name == '_category_img_url'){
              if(!empty($term_extra_row->key_value)){
                $term['category_img_url'] = $term_extra_row->key_value;
              }
              else{
                $term['category_img_url'] = '';
              }
            }
            elseif(!empty($term_extra_row) && $term_extra_row->key_name == '_category_description'){
              if(!empty($term_extra_row->key_value)){
                $term['category_description'] = $term_extra_row->key_value;
              }
              else{
                $term['category_description'] = '';
              }
            }
            elseif(!empty($term_extra_row) && $term_extra_row->key_name == '_tag_description'){
              if(!empty($term_extra_row->key_value)){
                $term['tag_description'] = $term_extra_row->key_value;
              }
              else{
                $term['tag_description'] = '';
              }
            }
            elseif(!empty($term_extra_row) && $term_extra_row->key_name == '_product_attr_values'){
              if(!empty($term_extra_row->key_value)){
                $term['product_attr_values'] = $term_extra_row->key_value;
              }
              else{
                $term['product_attr_values'] = '';
              }
            }
            elseif(!empty($term_extra_row) && $term_extra_row->key_name == '_product_color_code'){
              if(!empty($term_extra_row->key_value)){
                $term['color_code'] = $term_extra_row->key_value;
              }
              else{
                $term['color_code'] = '';
              }
            }
            elseif(!empty($term_extra_row) && $term_extra_row->key_name == '_brand_country_name'){
              if(!empty($term_extra_row->key_value)){
                $term['brand_country_name'] = $term_extra_row->key_value;
              }
              else{
                $term['brand_country_name'] = '';
              }
            }
            elseif(!empty($term_extra_row) && $term_extra_row->key_name == '_brand_short_description'){
              if(!empty($term_extra_row->key_value)){
                $term['brand_short_description'] = $term_extra_row->key_value;
              }
              else{
                $term['brand_short_description'] = '';
              }
            }
            elseif(!empty($term_extra_row) && $term_extra_row->key_name == '_brand_logo_img_url'){
              if(!empty($term_extra_row->key_value)){
                $term['brand_logo_img_url'] = $term_extra_row->key_value;
              }
              else{
                $term['brand_logo_img_url'] = '';
              }
            }
          }
        }
        
        array_push($term_data, $term);
      }
    }
    
    if($pagination){
      $currentPage = LengthAwarePaginator::resolveCurrentPage();
      $col = new Collection( $term_data );
      $perPage = 10;
      $currentPageSearchResults = $col->slice(($currentPage - 1) * $perPage, $perPage)->all();
      $term_object = new LengthAwarePaginator($currentPageSearchResults, count($col), $perPage);

      if($term_type == 'product_cat'){
        $term_object->setPath( route('admin.product_categories_list') );  
      }
      elseif($term_type == 'product_tag'){
        $term_object->setPath( route('admin.product_tags_list') );  
      }
      elseif($term_type == 'product_attr'){
        $term_object->setPath( route('admin.product_attributes_list') );  
      }
      elseif($term_type == 'product_brands'){
        $term_object->setPath( route('admin.manufacturers_list_content') );  
      }
      elseif($term_type == 'product_colors'){
        $term_object->setPath( route('admin.product_colors_list') );  
      }
      elseif($term_type == 'product_sizes'){
        $term_object->setPath( route('admin.product_sizes_list') );  
      }
      elseif($term_type == 'designer_cat'){
        $term_object->setPath( route('admin.art_categories_list_content') );  
      }
    }
    
    if($pagination){
      return $term_object;
    }
    else{
      return $term_data;
    }
  }
  
  /**
   * 
   * Get term data by term id
   *
   * @param term id
   * @param term id required
   * @return array
   */
  public function getTermDataById( $term_id ){
    $term_data = array();
    
    $get_term_data = Term:: where(['term_id' => $term_id])
                     ->get()
                     ->toArray();
      
    if(count($get_term_data) >0){
      foreach($get_term_data as $term){
       		   $term['brand_logo_img_url'] = '';
			   $term['category_img_url'] = '';
			   $term['category_description'] = '';
			   $term['tag_description'] = '';
			   $term['product_attr_values'] = '';
			   $term['color_code'] = '';
			   $term['brand_country_name'] = '';
			   $term['brand_short_description'] = '';
			    array_push($term_data, $term);
	  }

    }
    
    return $term_data;
  }
  
  /**
   * 
   * Get function for categories name
   *
   * @param cat type
   * @return array
   */
  public function get_categories_name($cat_type){
    $cat_list_array   =   array();
    $get_cats         =   Term:: where(['type' => $cat_type, 'status' => 1])
                          ->get()
                          ->toArray();
    
    if(count($get_cats) > 0){
      foreach($get_cats as $row){     
        $cat_list['id']   = $row['term_id'];
        $cat_list['name'] = $row['name'];
        $cat_list['slug'] = $row['slug'];
        $cat_list_array[] = $cat_list;
      }
    }
    
    return $cat_list_array;
  }
  
  /**
   * 
   * Get function for categories name for list
   *
   * @param cat type
   * @return array
   */
  public function get_categories_name_for_list($cat_type){
    $cat_list_array   =   array();
    $get_cats         =   Term:: where(['type' => $cat_type])
                          ->get()
                          ->toArray();
    
    if(count($get_cats) > 0){
      foreach($get_cats as $row){     
        $cat_list['id']   = $row['term_id'];
        $cat_list['name'] = $row['name'];
        $cat_list['slug'] = $row['slug'];
        $cat_list_array[] = $cat_list;
      }
    }
    
    return $cat_list_array;
  }
    
  /**
   * Get function for parent and child categories
   *
   * @param cat id, cat type
   * @return array
   */
  public function get_categories($cat_id = 0, $cat_type, $field=''){
    $get_categories_data  =  Term::where(['type' => $cat_type, 'parent' => $cat_id, 'status' => 1])->get();
    
    $categories = array();
  
    if($get_categories_data->count() > 0)
    {
      foreach ($get_categories_data as $mainCategory)
      {
        $category = array();
        
        if ($field == 'onlyId'){
          $category['id']                    =  $mainCategory->term_id;
        } else
        {
          $category['id']                    =  $mainCategory->term_id;
          $category['name']                  =  $mainCategory->name;
          $category['slug']                  =  $mainCategory->slug;
          $category['parent']                =  $mainCategory->parent;
          $category['category_icon']         =  $mainCategory->category_icon;
          $category['description'] = '';
          $category['img_url'] = $mainCategory->category_icon;
        }       
        
                
    
                
        $category['children']    =  $this->get_categories($category['id'], $cat_type);

        if($mainCategory->parent == 0){
          $category['parent']    =  'Parent Category';
        }
        else{
          $category['parent']    =  'Sub Category';
        }

        $categories[$mainCategory->term_id] =  $category;
      }
    }
    
    return $categories;
  }
    
  /**
   * Get function for parent categories
   *
   * @param cat id, cat type
   * @return array
   */
  public function get_parent_categories($cat_id = 0, $cat_type){
    $parent_categories = array();
    $get_categories_data  =  Term::where(['type' => $cat_type, 'parent' => $cat_id, 'status' => 1])->get()->toArray();
        
    if(count($get_categories_data) > 0){
        $parent_categories = $get_categories_data;
    }

    return $parent_categories;
  }
  
  /**
   * Get function for all categories array list
   *
   * @param cat array
   * @return array
   */
  public function createCategoriesSimpleList($cat_arr = array()){
    if(count($cat_arr) > 0){
      foreach($cat_arr as $cat){
        $cat_data['id'] = $cat['id'];
        $cat_data['name'] = $cat['name'];
        $cat_data['slug'] = $cat['slug'];
        $cat_data['parent'] = $cat['parent'];
        $cat_data['description'] = $cat['description'];
        $cat_data['img_url'] = $cat['img_url'];
        
        array_push($this->cat_list_arr, $cat_data);
        
        if(count($cat['children']) >0){
          $this->categoriesSimpleListExtra($cat['children']);
        }
      }
    }
  
    return $this->cat_list_arr;
  }
  
  /**
   * Get function for all categories list extra
   *
   * @param cat array
   * @return array
   */
  public function categoriesSimpleListExtra($cat_arr = array()){
    if(count($cat_arr) > 0){
      foreach($cat_arr as $cat){
        $cat_data['id'] = $cat['id'];
        $cat_data['name'] = $cat['name'];
        $cat_data['slug'] = $cat['slug'];
        $cat_data['parent'] = $cat['parent'];
        $cat_data['description'] = $cat['description'];
        $cat_data['img_url'] = $cat['img_url'];
        
        array_push($this->cat_list_arr, $cat_data);
        
        if(count($cat['children']) >0){
          $this->categoriesSimpleListExtra($cat['children']);
        }
      }
    }
  }
  
  /**
   * 
   * Save products for PMG Vendor Page.
   *
   * Last Updated By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Last Updated On : 19-Feb-2019
   * 
   * @param product slug
   * @param product slug by default null
   * @return void
   */
  public function saveProduct($params = null)
  {


    if( Request::isMethod('post') && Session::token() == Input::get('_token') )
    {
      // Getting all input data
      $data = Input::all();

      $rules = [
        'reg_product_name'  => 'required|min:25|max:50',
        'product_category_small' => 'required', 
        'product_shipping_cost_section_data' => 'required', 
        'product_sale_price' => 'required', 
      ];
      $messages = [
        'reg_product_name.required' => Lang::get('validation.reg_product_name_required'),
        'reg_product_name.min' => Lang::get('validation.reg_product_name_required'),
        'reg_product_name.max' => Lang::get('validation.reg_product_name_required'),
        'product_shipping_cost_section_data.required' => Lang::get('validation.product_shipping_cost_section_data_required'),
        'product_sale_price.required' => Lang::get('validation.product_sale_price_required')
      ];  

      $validator = Validator:: make($data, $rules, $messages);
        
      if($validator->fails())
      {
        return redirect()-> back()
        ->withInput()
        ->withErrors( $validator );
      }
      else
      {
        $common_obj  = new CommonFunction();
        $data = $common_obj->commonDataForAllPages(); 
        
        $product_id = 0;
        $post_author_id = 0;
        if((is_vendor_login() || is_admin_login()) 
           && (Session::has('shopist_admin_user_id') && is_numeric(Session::get('shopist_admin_user_id')))
        ){
          $post_author_id = Session::get('shopist_admin_user_id');
        }
        // If session is not found for vendor or super admin do this.
        if ($post_author_id == 0){
           return view('errors.vendor_session_expired');
           exit;
        }

        $where = ['author_id' => $post_author_id, 'status' => '1'];  
          
     
        // Getting Product ID, if save request made from edit product page.
        if(!empty($params)){
          $get_post =  Product :: where('slug', $params)->where($where)->get()->toArray();

          if(count($get_post) > 0){
            $product_id  =  $get_post[0]['id'];
          } else
          {
            return view('errors.no_data');
            exit;
          }
        }
        
        // Code for getting custom new field value for product extra detail input field.
        $product_sale_mode   = ''; // Immediate sale / Advance sale
        $product_condition_status   = ''; // New / Second-hand / Return 
        $product_tax   = ''; // Taxation / Duty-Free
 
        $product_model_name   = '';
        $product_manufacturer   = '';
        $product_origin   = '';
        $product_a_s_availability   = '';
 
        // Import section.
        $product_available_for_minors  = '';
        $product_section_data_import_number_json  = '';
       
        // Price and option section.
        $regular_price  = '';
        $discount_percent  = '';
        $sale_price  = '';
        //$sales_quantity  = ''; 
        $sale_period_mode  = '';
        $sale_period_start_date  = '';
        $sale_period_end_date  = '';
        $stock_management_status  = '';
        $allow_non_bankruptible_deposit  = 'N';
        $product_section_data_options_json  = '';
        // Product stock quantity.
        $sales_total_stock_quantity  = 0;
        $sales_quantity_default   = 0;
        $manage_stock='no';
        $stock_availability='hidden';
        $product_government_category_section_data='';
        $product_shipping_cost_section_data='';
        $product_point='';
        $product_description_text='';
        $seller_product_code='';
        //$productSKU ='';


       
        //$sale_price_start_date = '';
        //$sale_price_end_date   = '';
      

        if(Input::has('product_description_text') && Input::get('product_description_text') !='' ){
          $product_description_text = Input::get('product_description_text');
        } 

        if(Input::has('seller_product_code') && Input::get('seller_product_code') !='' ){
          $seller_product_code = Input::get('seller_product_code');
        } 
        if(Input::has('product_sale_mode') && Input::get('product_sale_mode') !='' ){
          $product_sale_mode = Input::get('product_sale_mode');
        } 

        if(Input::has('product_condition_status') && Input::get('product_condition_status') !='' ){
          $product_condition_status = Input::get('product_condition_status');
        } 

        if(Input::has('product_tax') && Input::get('product_tax') !='' ){
          $product_tax = Input::get('product_tax');
        } 

        // For now make all products taxable. later we can remove it.
        $product_tax ='taxation';

        if(Input::has('product_model_name') && Input::get('product_model_name') !='' ){
          $product_model_name = Input::get('product_model_name');
        } 

        if(Input::has('product_manufacturer') && Input::get('product_manufacturer') !='' ){
          $product_manufacturer = Input::get('product_manufacturer');
        }

        if(Input::has('product_origin') && Input::get('product_origin') !='' ){
          $product_origin = Input::get('product_origin');
        } 
        if(Input::has('product_a_s_availability') && Input::get('product_a_s_availability') !='' ){
          $product_a_s_availability = Input::get('product_a_s_availability');
        } 
  
        if(Input::has('product_available_for_minors') && Input::get('product_available_for_minors') !='' ){
          $product_available_for_minors = Input::get('product_available_for_minors');
        }
        $product_available_for_minors = ($product_available_for_minors=='yes')?'Y':'N'; 

        if(Input::has('product_section_data_import_number') && Input::get('product_section_data_import_number') !='' )
        {
          $product_section_data_import_number_json = Input::get('product_section_data_import_number');
        }


        if(is_numeric(Input::get('product_regular_price')) && Input::has('product_regular_price')){
          $regular_price = Input::get('product_regular_price');
        }

        
        if(Input::has('product_discount_percent') && Input::get('product_discount_percent') !='')
        {
          $discount_percent = Input::get('product_discount_percent');
        }
       
        
 
        if(is_numeric(Input::get('product_sale_price')) && Input::has('product_sale_price')){
          $sale_price = Input::get('product_sale_price');
        } else
        {
          $sale_price = $regular_price;
        }

        if(Input::has('product_point') && Input::get('product_point') !='')
        {
          $product_point = Input::get('product_point');
        }

        if(Input::has('sale_period_mode') && Input::get('sale_period_mode') !='')
        {
          $sale_period_mode = Input::get('sale_period_mode');
        }

        if(Input::has('sale_period_start_date') && Input::get('sale_period_start_date') !=''){
          $sale_period_start_date = Input::get('sale_period_start_date');
        }
        
         
        if(Input::has('sale_period_end_date') && Input::get('sale_period_end_date') !=''){
          $sale_period_end_date = Input::get('sale_period_end_date');
        }
        
        if(Input::has('stock_management_status') && Input::get('stock_management_status') !=''){
          $stock_management_status = Input::get('stock_management_status');
        }
 
        if(Input::has('allow_non_bankruptible_deposit') && Input::get('allow_non_bankruptible_deposit') !=''){
          $allow_non_bankruptible_deposit = Input::get('allow_non_bankruptible_deposit');
        }

        if(Input::has('product_government_category_section_data') && Input::get('product_government_category_section_data') !='' )
        {
          $product_government_category_section_data = Input::get('product_government_category_section_data');
        }

        if(Input::has('product_shipping_cost_section_data') && Input::get('product_shipping_cost_section_data') !='' )
        {
          $product_shipping_cost_section_data = Input::get('product_shipping_cost_section_data');
        }

        if(Input::has('sales_quantity') && is_numeric(Input::get('sales_quantity')))
        {
          $sales_quantity_default = Input::get('sales_quantity');
        }

        // Validate seller product code for PMG Store.
       /* if (Input::get('hf_post_type') == 'update_post' && $product_id > 0)
        {
          $check_seller_product_code  =  Product::where(['seller_product_code' =>  $seller_product_code ])->where('id', '!=' , $product_id)->get()->count();
        } else
        {
          $check_seller_product_code  =  Product::where(['seller_product_code' =>  $seller_product_code ])->get()->count();
        }

        if ($check_seller_product_code > 0)
        {
          Session::flash('seller-product-code-error-message', trans('admin.seller_product_code_duplicate'));
          
          if (Input::get('hf_post_type') == 'update_post' && $product_id > 0)
          {
            return redirect()->route('admin.update_product', $params);
          }else
          {
            return redirect()-> back();
          }
          exit;
        }*/

        // if stock managment is enabled then do this.
        if($stock_management_status == 'yes')
        {
          $manage_stock = 'yes';
        }
        else{
          $manage_stock = 'no';
        }


        $stock_availability_on_sale = 0;
        $stock_availability_out_of_stock = 0;
        $stock_availability_hidden = 0;
        $product_total_required_options_count = 0;
        

        if(Input::has('product_section_data_options') && Input::get('product_section_data_options') !='' )
        {

          $product_section_data_options_json = Input::get('product_section_data_options');

          // Convert JSON string to Array
          $product_section_data_options_json_array = convert_json_string_to_array($product_section_data_options_json);


          $product_total_required_options_count = (isset($product_section_data_options_json_array['requiredOptions'])) ? count($product_section_data_options_json_array['requiredOptions']) : 0;

          // If product required option couunt is more than 0, do this.
          if($product_total_required_options_count > 0)
          {
            // Itearte all required options data for getting total of quantity.
            foreach ($product_section_data_options_json_array['requiredOptions'] as $requiredOptions) 
            {
              $saleMode = (isset($requiredOptions['sale_mode'])) ? $requiredOptions['sale_mode'] : 'hidden';
              
              // Avoid adding quantity count for hidden products.
              if ($saleMode == 'on_sale' || $saleMode == 'out_of_stock')
              {
                $sales_total_stock_quantity = $sales_total_stock_quantity + intval($requiredOptions['sale_quantity']+$requiredOptions['add_inventory']);
              }
                

              // Check how many required product option status is set to on_sale.
              if ($saleMode =='on_sale')
              {
                if ($manage_stock == 'yes' && (isset($requiredOptions['sale_quantity']) && $requiredOptions['sale_quantity'] > 0))
                {
                  $stock_availability_on_sale++;
                } else if($manage_stock == 'no')
                {
                  $stock_availability_on_sale++;
                }
               
              }

              // Check how many required product option status is set to out_of_stock.
              if ($saleMode =='out_of_stock')
              {
                $stock_availability_out_of_stock++;
              }

              // Check how many required product option status is set to hidden.
              if ($saleMode =='hidden')
              {
                 $stock_availability_hidden++;
              }
            }
          }
        }

        
       
    
        // if stock managment is enabled then do this.
        if($manage_stock == 'yes') 
        { 
          // if stock managment is enabled, in stock quantity is 0 or no product status set to on sale then set stock_availability to 'out_of_stock';
          if($product_total_required_options_count > 0)
          {
            if ($product_total_required_options_count==$stock_availability_out_of_stock)
            {
              $stock_availability = 'out_of_stock';
            } else if ($product_total_required_options_count==$stock_availability_hidden)
            {
              $stock_availability = 'hidden';
            } else if ($stock_availability_on_sale > 0)
            {
              if ($sales_total_stock_quantity > 0)
              {
                $stock_availability = 'in_stock';
              } else
              {
               $stock_availability = 'out_of_stock';
              }
            } else if ($stock_availability_on_sale == 0 || $sales_total_stock_quantity == 0) {
                $stock_availability = 'out_of_stock';
            } 
          } else
          {
            if ($sales_quantity_default <= 0)
            {
              $stock_availability = 'out_of_stock';
            } else
            {
              $stock_availability = 'in_stock';
            }
          }
        }  
        else
        {
          if($product_total_required_options_count > 0)
          {
            if ($product_total_required_options_count==$stock_availability_out_of_stock)
            {
              $stock_availability = 'out_of_stock';
            } else if ($product_total_required_options_count==$stock_availability_hidden)
            {
              $stock_availability = 'hidden';
            } else if ($product_total_required_options_count > 0 && $stock_availability_on_sale > 0)
            {
              $stock_availability = 'in_stock';
            } else if ($product_total_required_options_count > 0 && $stock_availability_out_of_stock > 0)
            {
              $stock_availability = 'out_of_stock';
            }  
          } else
          {

            $stock_availability = 'in_stock';
          }
        }

        // Validate product to not allow user to make it hidden if it is added in PMG store.
        if (Input::get('hf_post_type') == 'update_post' && $stock_availability == 'hidden' && $product_id > 0)
        {
          // Get PMG Store products count for hidden product.
          $pmgStoreProductDataCount = DB::table('pmgstore_products')->where('product_id', $product_id)->select('product_id')->get()->count(); 
          if($pmgStoreProductDataCount > 0)
          {
             //Session::flash('pmg-store-error-message', Lang::get('admin.product_added_in_pmg_store_so_you_can_not_hide' ));
             Session::flash('pmg-store-error-message', trans('admin.product_added_in_pmg_store_so_you_can_not_hide'));
             return redirect()->route('admin.update_product', $params);
             exit;
          }
        }

        $page_title = Input::get('reg_product_name');
        $url_slug = string_slug_format(Input::get('reg_product_name'),'product');
        
        // Making instance of product model.
        $post        =  new Product;
        $post_slug   =  '';
        $check_slug  =  Product::where(['slug' =>  $url_slug ])->orWhere('slug', 'like', '%' .  $url_slug  . '%')->get()->count();

        if($check_slug === 0){
          $post_slug = $url_slug;
        }
        elseif($check_slug > 0){
          $slug_count = $check_slug + 1;
          $post_slug = $url_slug . '-' . $slug_count;
        }

        // Getting auther id from session.
        //$author_id = (Session::get('shopist_admin_user_id') > 0)?Session::get('shopist_admin_user_id'):0;
        $author_id =  $post_author_id;
        
        // Set up $productVisibility varibale to hold product status , 1 for visible, 0 for hidden, set up default to 1, if not found.
        $productStatus = 1; 
        
        // Set up $productType varibale to hold product type set up default to 'normal_product', if not found.
        $productType = 'normal_product'; 

        $get_images = json_decode(Input::get('hf_uploaded_all_images'));
        $sourcePath = public_path('uploads/product_images/').'temp/';
        
        if(Input::get('hf_post_type') == 'add_post')
        {
          $post->author_id          =   $author_id;
          $post->content            =   string_encode(Input::get('product_details_editor_pc'));
          $post->content_mobile     =   string_encode(Input::get('product_details_editor_mobile'));
          $post->title              =   Input::get('reg_product_name');
          $post->slug               =   $post_slug;
          $post->status             =   $productStatus;
          
          // Immediate sale / Advance sale
          $post->product_sale_mode          =  $product_sale_mode;  

          // New / Second-hand / Return 
          $post->product_condition_status   =  $product_condition_status;

          // Taxation / Duty-Free
          $post->product_tax                =  $product_tax; 

          $post->product_model_name         =  $product_model_name;
          $post->product_manufacturer       =  $product_manufacturer;
          $post->product_origin             =  $product_origin;
          $post->available_for_minors       =  $product_available_for_minors;

          //$post->sku                =   $productSKU;
          $post->regular_price      =   $regular_price;
          $post->discount_percent      =   $discount_percent;
          $post->sale_price         =   $sale_price;
          //$post->price              =   $price;
          $post->product_point_on_sale =   $product_point;
          $post->manage_stock          =   $manage_stock;
          $post->stock_qty          =   $sales_total_stock_quantity;
          $post->stock_qty_default   =   $sales_quantity_default;
          // Product status of product "in_stock", "out_of_stock" or "hidden".
          $post->stock_availability =   $stock_availability;
          $post->type               =   $productType;
          $post->image_url          =  '';
          $post->sale_period_mode   =  $sale_period_mode;
          $post->sale_period_start_date =  $sale_period_start_date;
          $post->sale_period_end_date =  $sale_period_end_date;
          $post->allow_non_bankruptible_deposit =  $allow_non_bankruptible_deposit;
          $post->txtProductDescriptionText =  $product_description_text;
          $post->seller_product_code =  $seller_product_code;
 
             
          if($post->save())
          {  
            $targetPath = public_path('uploads/product_images/').$post->id.'/';
            if (isset($get_images->product_gallery_images) 
                && count($get_images->product_gallery_images) > 0)
            {
             

              // Iterate all images
              foreach ($get_images->product_gallery_images as $key => $img) 
              {
                $fileName = basename($img->url);
                // Calling this function to movie file from temp folder to target folder.
                moveFileFromSourceLocationToTarget($sourcePath, $targetPath, $fileName);
                $img->url ='/public/uploads/product_images/'.$post->id.'/'.$fileName;
              }
            }

            //Set Up $product_image variable to hold product uploaded first image URL value, if not found then with default image url.
            $product_image = (isset($get_images->product_gallery_images[0]->url))?$get_images->product_gallery_images[0]->url:'/public/images/default-product-no-image_600_600.png';

            Product::where('id', $post->id)
                ->where('author_id', $author_id)
                ->update(['image_url' => $product_image]);

            if(ProductExtra::insert(array(
              
               array(
                'product_id'    =>  $post->id,
                'key_name'      =>  '_product_related_images_url',
                'key_value'     =>  json_encode($get_images),
                'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
              ),
              /*array(
                'product_id'    =>  $post->id,
                'key_name'      =>  '_product_sale_price_start_date',
                'key_value'     =>  $sale_price_start_date,
                'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
              ),
              array(
                'product_id'    =>  $post->id,
                'key_name'      =>  '_product_sale_price_end_date',
                'key_value'     =>  $sale_price_end_date,
                'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
              ),
              array(
                'product_id'    =>  $post->id,
                'key_name'      =>  '_product_manage_stock',
                'key_value'     =>  $manage_stock,
                'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
              ),
              array(
                'product_id'    =>  $post->id,
                'key_name'      =>  '_product_manage_stock_back_to_order',
                'key_value'     =>  Input::get('back_to_order_status'),
                'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
              ),
              
              array(
                'product_id'    =>  $post->id,
                'key_name'      =>  '_product_enable_as_selected_cat',
                'key_value'     =>  $home_page_product,
                'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
              ),
              array(
                'product_id'    =>  $post->id,
                'key_name'      =>  '_product_enable_reviews',
                'key_value'     =>  $enable_review,
                'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
              ),*/
              array(
                'product_id'    =>  $post->id,
                'key_name'      =>  '_product_seo_title',
                'key_value'     =>  $page_title,
                'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
              ),
              array(
                'product_id'    =>  $post->id,
                'key_name'      =>  '_product_a_s_availability',
                'key_value'     =>  $product_a_s_availability,
                'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
              ),
              array(
                'product_id'    =>  $post->id,
                'key_name'      =>  '_product_section_data_import_number_json',
                'key_value'     =>  $product_section_data_import_number_json,
                'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
              ),
              array(
                'product_id'    =>  $post->id,
                'key_name'      =>  '_product_section_data_options_json',
                'key_value'     =>  $product_section_data_options_json,
                'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
              ),
              array(
                'product_id'    =>  $post->id,
                'key_name'      =>  '_product_government_category_section_data',
                'key_value'     =>  $product_government_category_section_data,
                'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
              ),
              array(
                'product_id'    =>  $post->id,
                'key_name'      =>  '_product_shipping_cost_section_data',
                'key_value'     =>  $product_shipping_cost_section_data,
                'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
              )            
              
            ))) 
            {

              /**
               * Save Categories Data
               */
              $cat_array = array();
              $product_final_category_id = "";
              // Getting atleast one product category
              if(Input::has('product_category_details') && Input::get('product_category_details') !='')
              {
                $product_final_category_id = Input::get('product_category_details');
              } else if(Input::has('product_category_small') && Input::get('product_category_small') !='')
              {
                $product_final_category_id = Input::get('product_category_small');
              } else if(Input::has('product_category_middle') && Input::get('product_category_middle') !='')
              {
                $product_final_category_id = Input::get('product_category_middle');
              } else if(Input::has('product_category_large') && Input::get('product_category_large') !='')
              {
                $product_final_category_id = Input::get('product_category_large');
              }

              // Inserting Category data
              if(is_numeric($product_final_category_id) && $product_final_category_id > 0)
              {
                $cat_data = array('term_id'  =>  $product_final_category_id, 'object_id'  =>  $post->id, 'created_at'  =>  date("y-m-d H:i:s", strtotime('now')), 'updated_at'  =>  date("y-m-d H:i:s", strtotime('now')));
                array_push($cat_array, $cat_data);
                 ObjectRelationship::insert( $cat_array );    
              }


              /**
               * Save Brands Data
               */
              $productBrandId = '';
              if(Input::has('product_brand_id') && is_numeric(Input::get('product_brand_id')) && Input::get('product_brand_id') >0 ){
                $productBrandId = Input::get('product_brand_id');
              } else if(Input::has('product_brand_direct_input') && Input::get('product_brand_direct_input') !='' )
              {
                
               
                $brandName = Input::get('product_brand_direct_input');
                $brand_post_slug = string_slug_format($brandName,'brand');
   
                $check_brand_slug  =  Term::where(['slug' => $brand_post_slug])->orWhere('slug', 'like', '%' . $brand_post_slug . '%')->get()->count();

                if($check_brand_slug > 0)
                {
                  $check_brand_slug_count = $check_brand_slug + 1;
                  $brand_post_slug = $brand_post_slug . '-' . $check_brand_slug_count;
                }  

                // Save Brand from direct input
                $termPost       =  new Term;

                $termPost->author_id  =   $author_id;
                $termPost->name  =   $brandName;
                $termPost->slug  =   $brand_post_slug;
                $termPost->type  =   'product_brands';
                $termPost->parent  =   0;
                $termPost->status  =   1;
                $termPost->created_at  = date("y-m-d H:i:s", strtotime('now'));
                $termPost->updated_at  = date("y-m-d H:i:s", strtotime('now'));

                if ($termPost->save()) 
                  $productBrandId = $termPost->id;
                 
    
              }
            
              // Inserting Brand data
              if (is_numeric($productBrandId) && $productBrandId > 0) 
              {
                $brand_array = array();
                $brand_data = array('term_id'  =>  $productBrandId, 'object_id'  =>  $post->id, 'created_at'  =>  date("y-m-d H:i:s", strtotime('now')), 'updated_at'  =>  date("y-m-d H:i:s", strtotime('now')));
                array_push($brand_array, $brand_data);
                 ObjectRelationship::insert( $brand_array );   
              }
 
              Session::flash('success-message', Lang::get('admin.successfully_saved_msg') );
              return redirect()->route('admin.update_product', $post->slug);
            }
          }
        }
      elseif (Input::get('hf_post_type') == 'update_post') 
      {

        // Set up $uploadedImageFiles array to hold files uploaded for a given product.
        $uploadedImageFiles = array();
        $targetPath = public_path('uploads/product_images/').$product_id.'/';

        if (isset($get_images->product_gallery_images) 
          && count($get_images->product_gallery_images) > 0)
        {
          // Iterate all images
          foreach ($get_images->product_gallery_images as $key => $img) 
          {
            $fileName = basename($img->url);
                // Calling this function to movie file from temp folder to target folder.
            moveFileFromSourceLocationToTarget($sourcePath, $targetPath, $fileName);
            $img->url ='/public/uploads/product_images/'.$product_id.'/'.$fileName;
            array_push($uploadedImageFiles,  $fileName);
          }
        }

        //Set Up $product_image variable to hold product first image URL value
        $product_image = (isset($get_images->product_gallery_images[0]->url))?$get_images->product_gallery_images[0]->url:'/public/images/default-product-no-image_600_600.png';

        // Calling this function to remove all garbage image from product image folder. 
        deleteFilesFromGivenDirectoryWithFilter($targetPath, $uploadedImageFiles);

        $data = array(
          'content'            =>  string_encode(Input::get('product_details_editor_pc')),
          'content_mobile'      =>  string_encode(Input::get('product_details_editor_mobile')),
          'title'              =>  Input::get('reg_product_name'),
          'status'             =>  $productStatus,
          'product_sale_mode'     =>  $product_sale_mode,
          'product_condition_status' =>  $product_condition_status,
          'product_tax'           =>  $product_tax,
          'product_model_name'    =>  $product_model_name,
          'product_manufacturer'  =>  $product_manufacturer,
          'product_origin'        =>  $product_origin,
          'available_for_minors'        =>  $product_available_for_minors,
          //'sku'                =>  $productSKU,
          'regular_price'      =>  $regular_price,
          'discount_percent'      =>  $discount_percent,
          'sale_price'         =>  $sale_price,
          //'price'              =>  $price,
          'product_point_on_sale'          =>  $product_point,
          'manage_stock'          =>  $manage_stock,
          'stock_qty'          =>  $sales_total_stock_quantity,
          'stock_qty_default'   =>  $sales_quantity_default,
          'stock_availability' =>  $stock_availability,
          //'stock_availability' =>  $stock_availability,
          'type'               =>  $productType,
          'image_url'          =>  $product_image,
          'sale_period_mode'          =>  $sale_period_mode,
          'sale_period_start_date'    =>  $sale_period_start_date,
          'sale_period_end_date'    =>  $sale_period_end_date,
          'allow_non_bankruptible_deposit'    =>  $allow_non_bankruptible_deposit,
          'txtProductDescriptionText'    =>  $product_description_text,         
          'seller_product_code'    =>  $seller_product_code         
        );
   
        if( Product::where('id', $product_id)->update($data))
        {
          $data_related_url = array(
            'key_value'    =>  json_encode($get_images)
          );

          /*$data_sale_price_start_date = array(
            'key_value'    =>  $sale_price_start_date,
          );

          $data_sale_price_end_date = array(
            'key_value'    =>  $sale_price_end_date,
          );

          $data_manage_stock = array(
            'key_value'    =>  $manage_stock
          );

          $data_manage_stock_back_to_order = array(
            'key_value'    =>  Input::get('back_to_order_status')
          );
          $data_enable_review = array(
            'key_value'    =>  $enable_review
          );*/


          $data_seo_title = array(
            'key_value'    =>  $page_title
          );
          $product_a_s_availability = array(
            'key_value'    => $product_a_s_availability
          ); 

          $product_section_data_import_number = array(
            'key_value'    => $product_section_data_import_number_json
          ); 

          $product_section_data_options = array(
            'key_value'    => $product_section_data_options_json
          );
          $product_government_category_section_data = array(
            'key_value'    => $product_government_category_section_data
          );  

          $product_shipping_cost_section_data = array(
            'key_value'    => $product_shipping_cost_section_data
          );
        
           
          ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_a_s_availability'])->update($product_a_s_availability);
          ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_related_images_url'])->update($data_related_url);
          // ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_sale_price_start_date'])->update($data_sale_price_start_date);
          //ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_sale_price_end_date'])->update($data_sale_price_end_date);
          //ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_manage_stock'])->update($data_manage_stock);
          //ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_manage_stock_back_to_order'])->update($data_manage_stock_back_to_order);
          ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_seo_title'])->update($data_seo_title);
          // ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_enable_reviews'])->update($data_enable_review);
         
          ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_section_data_import_number_json'])->update($product_section_data_import_number);

          ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_section_data_options_json'])->update($product_section_data_options);
          ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_government_category_section_data'])->update($product_government_category_section_data);
          ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_shipping_cost_section_data'])->update($product_shipping_cost_section_data);
 
          $is_object_exist = ObjectRelationship::where('object_id', $product_id)->get();

          /**
           * Save Categories Data
           */
          $cat_array = array();
          $product_final_category_id = "";
          // Getting atleast one product category
          if(Input::has('product_category_details') && Input::get('product_category_details') !='')
          {
            $product_final_category_id = Input::get('product_category_details');
          } else if(Input::has('product_category_small') && Input::get('product_category_small') !='')
          {
            $product_final_category_id = Input::get('product_category_small');
          } else if(Input::has('product_category_middle') && Input::get('product_category_middle') !='')
          {
            $product_final_category_id = Input::get('product_category_middle');
          } else if(Input::has('product_category_large') && Input::get('product_category_large') !='')
          {
            $product_final_category_id = Input::get('product_category_large');
          }

              // Inserting Category data
          if(is_numeric($product_final_category_id) && $product_final_category_id > 0)
          {
            $is_term_object_exist = ObjectRelationship::where('object_id', $product_id)->where('terms.type', 'product_cat')->join('terms',function($join){
                $join->on("terms.term_id","=","object_relationships.term_id");
                    //->on("terms.type","=","product_cat");
            })->select('terms.term_id')->get();
          
            if(count($is_term_object_exist)>0)
            {
              $last_updated_term_id = isset($is_term_object_exist[0]->term_id) ? $is_term_object_exist[0]->term_id : 0;
              ObjectRelationship::where('object_id', $product_id)
                ->where('term_id', $last_updated_term_id)
                ->update(['term_id' => $product_final_category_id,'updated_at' => date("y-m-d H:i:s", strtotime('now'))]);
            } else
            {
              $cat_data = array('term_id'  =>  $product_final_category_id, 'object_id'  =>  $product_id, 'created_at'  =>  date("y-m-d H:i:s", strtotime('now')), 'updated_at'  =>  date("y-m-d H:i:s", strtotime('now')));
              array_push($cat_array, $cat_data);
              ObjectRelationship::insert( $cat_array ); 

            }
          }

          /**
           * Save Brands Data
           */
          $productBrandId = '';
          if(Input::has('product_brand_id') && is_numeric(Input::get('product_brand_id')) && Input::get('product_brand_id') >0 ){
            $productBrandId = Input::get('product_brand_id');
          } else if(Input::has('product_brand_direct_input') && Input::get('product_brand_direct_input') !='' )
          {


            $brandName = Input::get('product_brand_direct_input');
            $brand_post_slug = string_slug_format($brandName,'brand');

            $check_brand_slug  =  Term::where(['slug' => $brand_post_slug])->orWhere('slug', 'like', '%' . $brand_post_slug . '%')->get()->count();

            if($check_brand_slug > 0)
            {
              $check_brand_slug_count = $check_brand_slug + 1;
              $brand_post_slug = $brand_post_slug . '-' . $check_brand_slug_count;
            }  

            // Save Brand from direct input
            $termPost       =  new Term;

            $termPost->author_id  =   $author_id;
            $termPost->name  =   $brandName;
            $termPost->slug  =   $brand_post_slug;
            $termPost->type  =   'product_brands';
            $termPost->parent  =   0;
            $termPost->status  =   1;
            $termPost->created_at  = date("y-m-d H:i:s", strtotime('now'));
            $termPost->updated_at  = date("y-m-d H:i:s", strtotime('now'));

            if ($termPost->save()) 
              $productBrandId = $termPost->id;


          }

          // Inserting Brand data
          if (is_numeric($productBrandId) && $productBrandId > 0) 
          {
             $is_term_object_exist = ObjectRelationship::where('object_id', $product_id)->where('terms.type', 'product_brands')->join('terms',function($join){
                $join->on("terms.term_id","=","object_relationships.term_id");
                    //->on("terms.type","=","product_cat");
            })->select('terms.term_id')->get();
          
            if(count($is_term_object_exist)>0)
            {
              $last_updated_term_id = isset($is_term_object_exist[0]->term_id) ? $is_term_object_exist[0]->term_id : 0;
              ObjectRelationship::where('object_id', $product_id)
                ->where('term_id', $last_updated_term_id)
                ->update(['term_id' => $productBrandId,'updated_at' => date("y-m-d H:i:s", strtotime('now'))]);
            } else
            {
               $brand_array = array();
               $brand_data = array('term_id'  =>  $productBrandId, 'object_id'  =>  $product_id, 'created_at'  =>  date("y-m-d H:i:s", strtotime('now')), 'updated_at'  =>  date("y-m-d H:i:s", strtotime('now')));
               array_push($brand_array, $brand_data);
               ObjectRelationship::insert( $brand_array );  

            }

           
          }
   
          Session::flash('success-message', Lang::get('admin.successfully_updated_msg' ));
          return redirect()->route('admin.update_product', $params);
        }
      }
    }  
  } else
  {
    return redirect()-> back();
  }
}


  /**
   * 
   * Save products
   *
   * @param product slug
   * @param product slug by default null
   * @return void
   */
  /*public function saveProduct($params = null){
    if( Request::isMethod('post') && Session::token() == Input::get('_token') ){

      //vendor product add restricted
      if(is_vendor_login() && Session::has('shopist_admin_user_id') && Input::get('hf_post_type') == 'add_post'){
        $selected_package_details = get_package_details_by_vendor_id( Session::get('shopist_admin_user_id') );
        $get_total_product = Product::where(['author_id' => Session::get('shopist_admin_user_id')])->get()->count();
        
        if(!empty($get_total_product) && $get_total_product > 0){
          $count = $get_total_product + 1;
          
          if($count > $selected_package_details->max_number_product){
            Session::flash('error-message', Lang::get('admin.vendor_product_exceed_msg', ['number' => $selected_package_details->max_number_product]) );
            return redirect()-> back();
          }
        }
      }
      
      $data = Input::all();

      $rules =  ['product_name'  => 'required'];

      $validator = Validator:: make($data, $rules);
      
      if($validator->fails()){
        return redirect()-> back()
        ->withInput()
        ->withErrors( $validator );
      }
      else{
        $product_id = 0;

        //downloadable product file manage
        $downloadable_product_data = array();
        $file_name = Input::get('downloadable_file_name');
        $uploaded_file_url = Input::get('downloadable_uploaded_file_url');
        $online_file_url = Input::get('downloadable_online_file_url');

        if(Input::has('downloadable_file_name') && Input::has('downloadable_uploaded_file_url') && Input::has('downloadable_online_file_url') && count($file_name) > 0 && count($uploaded_file_url) > 0 && count($online_file_url)){
          foreach($file_name as $key => $name){
            $url = str_replace(url('/'), '', $uploaded_file_url[$key]);
            $downloadable_product_data[$key] = array('file_name' => $name, 'uploaded_file_url' => $url, 'online_file_url' => $online_file_url[$key]);
          }
        }

        $download_limit = '';
        $download_expiry = '';

        if(Input::get('download_limit')){
          $download_limit = Input::get('download_limit');
        }


        //role based pricing
        $role_price = array();
        $available_user_role = get_available_user_roles();

        if(count($available_user_role) > 0 && Input::has('RoleRegularPricing') && Input::has('RoleSalePricing')){
          $role_based_regular_pricing = Input::get('RoleRegularPricing');
          $role_based_sale_pricing = Input::get('RoleSalePricing');


          foreach($role_based_regular_pricing as $key=> $role){
            $role_sale_price = '';
            $role_regular_price = $role;

            if($role_regular_price){
              $role_sale_price = $role_based_sale_pricing[$key];
            }

            $role_price[$key] = array('regular_price' => $role_regular_price, 'sale_price' => $role_sale_price);
          }
        }
        
        //manage cross sell and upsell products
        $selected_upsell_products = array();
        $selected_crosssell_products = array();
        
        $get_selected_upsell_product = json_decode(Input::get('selected_upsell_products'));
        $get_selected_crosssell_product = json_decode(Input::get('selected_crosssell_products'));
        
        if(!empty($get_selected_upsell_product) && count($get_selected_upsell_product) > 0){
          foreach($get_selected_upsell_product as $upsell_products){
            $explod_val = explode('#', $upsell_products);
            $get_id = end($explod_val);
            array_push($selected_upsell_products, $get_id);
          }
        }
        
        if(!empty($get_selected_crosssell_product) && count($get_selected_crosssell_product) > 0){
          foreach($get_selected_crosssell_product as $crosssell_products){
            $explod_val = explode('#', $crosssell_products);
            $get_id = end($explod_val);
            array_push($selected_crosssell_products, $get_id);
          }
        }
        
        
        if(!empty($params)){
          $get_post =  Product :: where('slug', $params)->get()->toArray();

          if(count($get_post) > 0){
            $product_id  =  $get_post[0]['id'];
          }
        }
        
        $price          = '';
        $regular_price  = '';
        $sale_price     = '';
        $stock_qty      = 0;
        $sale_price_start_date = '';
        $sale_price_end_date   = '';
        $stock_availability    = ''; 

        if(is_numeric(Input::get('inputRegularPrice')) && Input::has('inputRegularPrice')){
          $regular_price = Input::get('inputRegularPrice');
        }

        if(is_numeric(Input::get('inputSalePrice')) && Input::has('inputRegularPrice')){
          $sale_price = Input::get('inputSalePrice');
        }
 
        
        if(($regular_price && $sale_price) && (abs($sale_price) < abs($regular_price)) && $sale_price > 0){
          $price = Input::get('inputSalePrice');
        }
        else{
          $price = Input::get('inputRegularPrice');
        }

        $today = date("Y-m-d");

        if(Input::get('inputSalePriceStartDate') >= $today){
          $sale_price_start_date = Input::get('inputSalePriceStartDate');
        }

        if(Input::get('inputSalePriceEndDate') >= $today){
          $sale_price_end_date = Input::get('inputSalePriceEndDate');
        }

        if(Input::get('download_expiry') >= $today){
          $download_expiry = Input::get('download_expiry');
        }

        if(is_numeric(Input::get('inputStockQty'))){
          $stock_qty = Input::get('inputStockQty');
        }


        $manage_stock         = 'yes';
        $enable_recommended   = 'yes';
        $enable_features      = 'yes';
        $enable_latest        = 'yes';
        $enable_related       = 'yes';
        $enable_custom_design = 'yes';
        $enable_taxes         = 'yes';
        $enable_review        = 'yes';
        $enable_p_page        = 'yes';
        $enable_d_page        = 'yes';
        $enable_review_totals = 'yes';
        $enable_product_video = 'yes';
        $enable_manufacturer  = 'yes';
        $visibilityschedule   = 'yes';
        $home_page_product    = 'yes';
        $is_pricing_enable    = 'no';

        $_stock           = (Input::has('manage_stock')) ? true : false;
        $_recommended     = (Input::has('enable_recommended_product')) ? true : false;
        $_features        = (Input::has('enable_features_product')) ? true : false;
        $_latest          = (Input::has('enable_latest_product')) ? true : false;
        $_related         = (Input::has('inputEnableForRelatedProduct')) ? true : false;
        $_custom_design   = (Input::has('inputEnableForCustomDesignProduct')) ? true : false;
        $_taxes           = (Input::has('inputEnableTaxesForProduct')) ? true : false;
        $_review          = (Input::has('inputEnableReviews')) ? true : false;
        $_review_p_page   = (Input::has('inputEnableAddReviewLinkToProductPage')) ? true : false;
        $_review_d_page   = (Input::has('inputEnableAddReviewLinkToDetailsPage')) ? true : false;
        $_product_video   = (Input::has('inputEnableProductVideo')) ? true : false;
        $_manufacturer    = (Input::has('inputEnableProductManufacturer')) ? true : false;
        $_visibility      = (Input::has('inputVisibilitySchedule')) ? true : false;
        $_home_product    = (Input::has('inputEnableForHomePage')) ? true : false;
        $_is_role_based_pricing_enable    = (Input::has('inputEnableDisableRoleBasedPricing')) ? true : false;


        if($_stock){
          $manage_stock = 'yes';
        }
        else{
          $manage_stock = 'no';
        }

        if($_recommended){
          $enable_recommended = 'yes';
        }
        else{
          $enable_recommended = 'no';
        }

        if($_features){
          $enable_features = 'yes';
        }
        else{
          $enable_features = 'no';
        }

        if($_latest){
          $enable_latest = 'yes';
        }
        else{
          $enable_latest = 'no';
        }

        if($_related){
          $enable_related = 'yes';
        }
        else{
          $enable_related = 'no';
        }

        if($_custom_design && Input::get('change_product_type') == 'customizable_product'){
          $enable_custom_design = 'yes';
        }
        else{
          $enable_custom_design = 'yes';
        }

        if($_taxes){
          $enable_taxes = 'yes';
        }
        else{
          $enable_taxes = 'no';
        }

        if($_review){
          $enable_review = 'yes';
        }
        else{
          $enable_review = 'no';
        }

        if($_review_p_page){
          $enable_p_page = 'yes';
        }
        else{
          $enable_p_page = 'no';
        }

        if($_review_d_page){
          $enable_d_page = 'yes';
        }
        else{
          $enable_d_page = 'no';
        }

        if($_product_video){
          $enable_product_video = 'yes';
        }
        else{
          $enable_product_video = 'no';
        }

        if($_manufacturer){
          $enable_manufacturer = 'yes';
        }
        else{
          $enable_manufacturer = 'no';
        }

        if($_visibility){
          $visibilityschedule = 'yes';
        }
        else{
          $visibilityschedule = 'no';
        } 

        if($_home_product){
          $home_page_product = 'yes';
        }
        else{
          $home_page_product = 'no';
        }

        if($_is_role_based_pricing_enable){
          $is_pricing_enable = 'yes';
        }
        else{
          $is_pricing_enable = 'no';
        }

        if($manage_stock == 'yes'){
          if ($manage_stock == 'yes' && $stock_qty == 0 && Input::get('back_to_order_status') == 'not_allow') {
            $stock_availability = 'out_of_stock';
          }
          else{
            $stock_availability = 'in_stock';
          }
        }  
        else{
          $stock_availability = Input::get('stock_availability_status');
        }

        //designer settings 
        $cavas_small_width = 0;
        $cavas_small_height = 0;
        $cavas_medium_width = 0;
        $cavas_medium_height = 0;
        $cavas_large_width = 0;
        $cavas_large_height = 0;

        $enable_design_layout = 'no';
        $enable_global_settings = 'no';

        $get_designer_settings = $this->option->getCustomDesignerSettingsData();

        $_is_enable_design_layout     = (Input::has('inputEnableDesignLayout')) ? true : false;
        $_is_enable_global_settings   = (Input::has('inputEnableGlobalSettings')) ? true : false;


        if($_is_enable_global_settings){
          $enable_global_settings = 'yes';
        }
        else{
          $enable_global_settings = 'no';
        }

        if($_is_enable_design_layout){
          $enable_design_layout = 'yes';
        }
        else{
          $enable_design_layout = 'no';
        }


        // canvas size
        if(Input::has('specific_canvas_small_devices_width') && $enable_global_settings == 'no'){
          $cavas_small_width = Input::get('specific_canvas_small_devices_width');
        }
        elseif ($enable_global_settings == 'yes') {
          $cavas_small_width = '';
        }
        else{
          $cavas_small_width = $get_designer_settings['general_settings']['canvas_dimension']['small_devices']['width'];
        }

        if(Input::has('specific_canvas_small_devices_height') && $enable_global_settings == 'no'){
          $cavas_small_height = Input::get('specific_canvas_small_devices_height');
        }
        elseif ($enable_global_settings == 'yes') {
          $cavas_small_height = '';
        }
        else{
          $cavas_small_height = $get_designer_settings['general_settings']['canvas_dimension']['small_devices']['height'];
        }


        if(Input::has('specific_canvas_medium_devices_width') && $enable_global_settings == 'no'){
          $cavas_medium_width = Input::get('specific_canvas_medium_devices_width');
        }
        elseif ($enable_global_settings == 'yes'){
          $cavas_medium_width = '';
        }
        else{
          $cavas_medium_width = $get_designer_settings['general_settings']['canvas_dimension']['medium_devices']['width'];
        }

        if(Input::has('specific_canvas_medium_devices_height') && $enable_global_settings == 'no'){
          $cavas_medium_height = Input::get('specific_canvas_medium_devices_height');
        }
        elseif ($enable_global_settings == 'yes'){
          $cavas_medium_height = '';
        }
        else{
          $cavas_medium_height = $get_designer_settings['general_settings']['canvas_dimension']['medium_devices']['height'];
        }


        if(Input::has('specific_canvas_large_devices_width') && $enable_global_settings == 'no'){
          $cavas_large_width = Input::get('specific_canvas_large_devices_width');
        }
        elseif ($enable_global_settings == 'yes'){
          $cavas_large_width = '';
        }
        else{
          $cavas_large_width = $get_designer_settings['general_settings']['canvas_dimension']['large_devices']['width'];
        }

        if(Input::has('specific_canvas_large_devices_height') && $enable_global_settings == 'no'){
          $cavas_large_height = Input::get('specific_canvas_large_devices_height');
        }
        elseif ($enable_global_settings == 'yes') {
          $cavas_large_height = '';
        }
        else{
          $cavas_large_height = $get_designer_settings['general_settings']['canvas_dimension']['large_devices']['height'];
        }


        $designer_settings = array(
          'canvas_dimension' => array('small_devices' => array('width' => $cavas_small_width, 'height' => $cavas_small_height), 'medium_devices' => array('width'=> $cavas_medium_width, 'height' => $cavas_medium_height), 'large_devices' => array('width' => $cavas_large_width, 'height' => $cavas_large_height)),
          'enable_layout_at_frontend' => $enable_design_layout,
          'enable_global_settings' => $enable_global_settings
        );


        $videoSourceName = '';

        if(Input::get('inputVideoSourceName')){
          $videoSourceName = Input::get('inputVideoSourceName');
        }

        $page_title = '';
        $url_slug   = '';

        if(Input::has('seo_title') && !empty(Input::get('seo_title'))){
          $page_title = Input::get('seo_title');
        }
        else{
          $page_title = Input::get('product_name');
        }

        if(Input::has('seo_url_format') && !empty(Input::get('seo_url_format'))){
          $url_slug = string_slug_format(Input::get('seo_url_format'));
        }
        else{
          $url_slug = string_slug_format(Input::get('product_name'));
        }

        $post        =  new Product;
        $post_slug   =  '';
        $check_slug  =  Product::where(['slug' => string_slug_format( $url_slug )])->orWhere('slug', 'like', '%' . string_slug_format( $url_slug ) . '%')->get()->count();

        if($check_slug === 0){
          $post_slug = string_slug_format( $url_slug );
        }
        elseif($check_slug > 0){
          $slug_count = $check_slug + 1;
          $post_slug = string_slug_format( $url_slug ). '-' . $slug_count;
        }


        $author_id = 0;
        if(Input::has('vendor_list') && !empty(Input::get('vendor_list'))){
          $author_id = Input::get('vendor_list');
        }
        else{
          $author_id = Session::get('shopist_admin_user_id');
        }

        $get_images = json_decode(Input::get('hf_uploaded_all_images'));
        $product_image = $get_images->product_image;
  
        if(Input::get('hf_post_type') == 'add_post'){
          $post->author_id          =   $author_id;
          $post->content            =   string_encode(Input::get('eb_description_editor'));
          $post->title              =   Input::get('product_name');
          $post->slug               =   $post_slug;
          $post->status             =   Input::get('product_visibility');
      $post->product_visibility_status   =   Input::get('products_visibility');
          $post->sku                =   Input::get('ProductSKU');
          $post->regular_price      =   $regular_price;
          $post->sale_price         =   $sale_price;
          $post->price              =   $price;
          $post->stock_qty          =   $stock_qty;
          $post->stock_availability =   $stock_availability;
          $post->type               =   Input::get('change_product_type');
          $post->image_url          =   $product_image;

          if($post->save()){  
            if(ProductExtra::insert(array(
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_product_related_images_url',
                                          'key_value'     =>  Input::get('hf_uploaded_all_images'),
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_product_sale_price_start_date',
                                          'key_value'     =>  $sale_price_start_date,
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_product_sale_price_end_date',
                                          'key_value'     =>  $sale_price_end_date,
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_product_manage_stock',
                                          'key_value'     =>  $manage_stock,
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_product_manage_stock_back_to_order',
                                          'key_value'     =>  Input::get('back_to_order_status'),
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_product_extra_features',
                                          'key_value'     =>  string_encode(Input::get('eb_features_editor')),
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_product_enable_as_recommended',
                                          'key_value'     =>  $enable_recommended,
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_product_enable_as_features',
                                          'key_value'     =>  $enable_features,
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_product_enable_as_latest',
                                          'key_value'     =>  $enable_latest,
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_product_enable_as_related',
                                          'key_value'     =>  $enable_related,
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_product_enable_as_custom_design',
                                          'key_value'     =>  $enable_custom_design,
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_product_enable_as_selected_cat',
                                          'key_value'     =>  $home_page_product,
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_product_enable_taxes',
                                          'key_value'     =>  $enable_taxes,
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_product_custom_designer_settings',
                                          'key_value'     =>  serialize($designer_settings),
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_product_custom_designer_data',
                                          'key_value'     =>  Input::get('hf_custom_designer_data'),
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_product_enable_reviews',
                                          'key_value'     =>  $enable_review,
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_product_enable_reviews_add_link_to_product_page',
                                          'key_value'     =>  $enable_p_page,
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_product_enable_reviews_add_link_to_details_page',
                                          'key_value'     =>  $enable_d_page,
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_product_enable_video_feature',
                                          'key_value'     =>  $enable_product_video,
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_product_video_feature_display_mode',
                                          'key_value'     =>  Input::get('inputVideoDisplayMode'),
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_product_video_feature_title',
                                          'key_value'     =>  Input::get('inputTitleForVideo'),
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_product_video_feature_panel_size',
                                          'key_value'     =>  serialize(array('width' => Input::get('inputVideoPanelWidth'), 'height' => Input::get('inputVideoPanelHeight'))),
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_product_video_feature_source',
                                          'key_value'     =>  $videoSourceName,
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_product_video_feature_source_embedded_code',
                                          'key_value'     =>  Input::get('inputEmbedCode'),
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_product_video_feature_source_online_url',
                                          'key_value'     =>  Input::get('inputAddOnlineVideoUrl'),
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'meta_key'      =>  '_product_enable_manufacturer',
                                          'meta_value'    =>  $enable_manufacturer,
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_product_enable_visibility_schedule',
                                          'key_value'     =>  $visibilityschedule,
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_product_seo_title',
                                          'key_value'     =>  $page_title,
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_product_seo_description',
                                          'key_value'     =>  Input::get('seo_description'),
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_product_seo_keywords',
                                          'key_value'     =>  Input::get('seo_keywords'),
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_product_compare_data',
                                          'key_value'     =>  serialize(Input::get('inputCompareData')),
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_is_role_based_pricing_enable',
                                          'key_value'     =>  $is_pricing_enable,
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_role_based_pricing',
                                          'key_value'     =>  serialize($role_price),
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_downloadable_product_files',
                                          'key_value'     =>  serialize($downloadable_product_data),
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_downloadable_product_download_limit',
                                          'key_value'     =>  $download_limit,
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_downloadable_product_download_expiry',
                                          'key_value'     =>  $download_expiry,
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_upsell_products',
                                          'key_value'     =>  serialize($selected_upsell_products),
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_crosssell_products',
                                          'key_value'     =>  serialize($selected_crosssell_products),
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      ),
                                      array(
                                          'product_id'    =>  $post->id,
                                          'key_name'      =>  '_selected_vendor',
                                          'key_value'     =>  $author_id,
                                          'created_at'    =>  date("y-m-d H:i:s", strtotime('now')),
                                          'updated_at'    =>  date("y-m-d H:i:s", strtotime('now'))
                                      )



            ))){

            //save categories
            if(Input::has('inputCategoriesName') && count(Input::get('inputCategoriesName'))>0){
              $cat_array = array();

              foreach(Input::get('inputCategoriesName') as $cat_id){
                $cat_data = array('term_id'  =>  $cat_id, 'object_id'  =>  $post->id, 'created_at'  =>  date("y-m-d H:i:s", strtotime('now')), 'updated_at'  =>  date("y-m-d H:i:s", strtotime('now')));

                array_push($cat_array, $cat_data);
              }

              if(count($cat_array) > 0){
                ObjectRelationship::insert( $cat_array );    
              }
            }

            //save manufacturer
            if(Input::has('inputManufacturerName') && count(Input::get('inputManufacturerName'))>0){
              $manufacturer_array = array();

              foreach(Input::get('inputManufacturerName') as $brands_id){
                $manufacturer_data = array('term_id'  =>  $brands_id, 'object_id'  =>  $post->id, 'created_at'  =>  date("y-m-d H:i:s", strtotime('now')), 'updated_at'  =>  date("y-m-d H:i:s", strtotime('now')));

                array_push($manufacturer_array, $manufacturer_data);   
              }

              if(count($manufacturer_array) > 0){
                ObjectRelationship::insert( $manufacturer_array );    
              }
            }

            //save tags
            if(Input::has('inputTagsName') && count(Input::get('inputTagsName'))>0){
              $tags_array = array();

              foreach(Input::get('inputTagsName') as $tags_id){
                $tags_data = array('term_id'  =>  $tags_id, 'object_id'  =>  $post->id, 'created_at'  =>  date("y-m-d H:i:s", strtotime('now')), 'updated_at'  =>  date("y-m-d H:i:s", strtotime('now')));

                array_push($tags_array, $tags_data);   
              }

              if(count($tags_array) > 0){
                ObjectRelationship::insert( $tags_array );    
              }
            }

            //save colors
            if(Input::has('inputColorsName') && count(Input::get('inputColorsName'))>0){
              $colors_array = array();

              foreach(Input::get('inputColorsName') as $colors_id){
                $colors_data = array('term_id'  =>  $colors_id, 'object_id'  =>  $post->id, 'created_at'  =>  date("y-m-d H:i:s", strtotime('now')), 'updated_at'  =>  date("y-m-d H:i:s", strtotime('now')));

                array_push($colors_array, $colors_data);   
              }

              if(count($colors_array) > 0){
                ObjectRelationship::insert( $colors_array );    
              }
            }

            //save sizes
            if(Input::has('inputSizesName') && count(Input::get('inputSizesName'))>0){
              $sizes_array = array();

              foreach(Input::get('inputSizesName') as $sizes_id){
                $sizes_data = array('term_id'  =>  $sizes_id, 'object_id'  =>  $post->id, 'created_at'  =>  date("y-m-d H:i:s", strtotime('now')), 'updated_at'  =>  date("y-m-d H:i:s", strtotime('now')));

                array_push($sizes_array, $sizes_data);   
              }

              if(count($sizes_array) > 0){
                ObjectRelationship::insert( $sizes_array );    
              }
            }

            Session::flash('success-message', Lang::get('admin.successfully_saved_msg') );
            return redirect()->route('admin.update_product', $post->slug);
            }
          }
        }
        elseif (Input::get('hf_post_type') == 'update_post'){
          $data = array(
                        'content'            =>  string_encode(Input::get('eb_description_editor')),
                        'title'              =>  Input::get('product_name'),
                        'status'             =>  Input::get('product_visibility'),
            'product_visibility_status'   =>  Input::get('products_visibility'),
                        'sku'                =>  Input::get('ProductSKU'),
                        'regular_price'      =>  $regular_price,
                        'sale_price'         =>  $sale_price,
                        'price'              =>  $price,
                        'stock_qty'          =>  $stock_qty,
                        'stock_availability' =>  $stock_availability,
                        'type'               =>  Input::get('change_product_type'),
                        'image_url'          =>  $product_image
          );
          if( Product::where('id', $product_id)->update($data)){
            $data_related_url = array(
                              'key_value'    =>  Input::get('hf_uploaded_all_images')
            );

            $data_sale_price_start_date = array(
                              'key_value'    =>  $sale_price_start_date,
            );

            $data_sale_price_end_date = array(
                              'key_value'    =>  $sale_price_end_date,
            );

            $data_manage_stock = array(
                              'key_value'    =>  $manage_stock
            );

            $data_manage_stock_back_to_order = array(
                              'key_value'    =>  Input::get('back_to_order_status')
            );

            $data_extra_features = array(
                              'key_value'    =>  string_encode(Input::get('eb_features_editor'))
            );

            $data_enable_recommended = array(
                              'key_value'    =>  $enable_recommended
            );

            $data_enable_features = array(
                              'key_value'    =>  $enable_features
            );

            $data_enable_latest = array(
                              'key_value'    =>  $enable_latest
            );

            $data_enable_related = array(
                              'key_value'    =>  $enable_related
            );

            $data_enable_custom_design = array(
                              'key_value'    =>  $enable_custom_design
            );

            $data_enable_home_product = array(
                              'key_value'    =>  $home_page_product
            );

            $data_enable_taxes = array(
                              'key_value'    =>  $enable_taxes
            );

            $data_custom_designer_settings = array(
                              'key_value'    =>  serialize($designer_settings)
            );

            $data_custom_designer_data = array(
                              'key_value'    =>  Input::get('hf_custom_designer_data')
            );

            $data_enable_review = array(
                              'key_value'    =>  $enable_review
            );

            $data_p_page = array(
                              'key_value'    =>  $enable_p_page
            );

            $data_d_page = array(
                              'key_value'    =>  $enable_d_page
            );

            $data_enable_product_video = array(
                              'key_value'    =>  $enable_product_video
            );

            $data_display_mode = array(
                              'key_value'    =>  Input::get('inputVideoDisplayMode')
            );

            $data_title_for_video = array(
                              'key_value'    =>  Input::get('inputTitleForVideo')
            );

            $data_video_feature_panel_size = array(
                              'key_value'    =>  serialize(array('width' => Input::get('inputVideoPanelWidth'), 'height' => Input::get('inputVideoPanelHeight')))
            );

            $data_video_source_name = array(
                              'key_value'    =>  $videoSourceName
            );

            $data_video_embed_code = array(
                              'key_value'    =>  Input::get('inputEmbedCode')
            );

            $data_video_online_url = array(
                              'key_value'    =>  Input::get('inputAddOnlineVideoUrl')
            );

            $data_enable_manufacturer = array(
                              'key_value'    =>  $enable_manufacturer
            );

            $data_visibilityschedule = array(
                              'key_value'    =>  $visibilityschedule
            );

            $data_seo_title = array(
                              'key_value'    =>  $page_title
            );

            $data_seo_description = array(
                              'key_value'    =>  Input::get('seo_description')
            );

            $data_seo_keywords = array(
                              'key_value'    =>  Input::get('seo_keywords')
            );

            $data_compare_product = array(
                              'key_value'    => serialize(Input::get('inputCompareData'))
            );

            $data_is_role_based_enable = array(
                              'key_value'    => $is_pricing_enable
            );

            $data_role_based_pricing = array(
                              'key_value'    => serialize($role_price)
            );

            $data_downloadable_product_files = array(
                              'key_value'    => serialize($downloadable_product_data)
            );

            $data_downloadable_product_download_limit = array(
                              'key_value'    => $download_limit
            );

            $data_downloadable_product_download_expiry = array(
                              'key_value'    => $download_expiry
            );

            $upsell_selected_product = array(
                              'key_value'    => serialize($selected_upsell_products)
            );

            $crosssell_selected_product = array(
                              'key_value'    => serialize($selected_crosssell_products)
            );

            $selected_vendor = array(
                              'key_value'    => $author_id
            );


            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_related_images_url'])->update($data_related_url);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_sale_price_start_date'])->update($data_sale_price_start_date);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_sale_price_end_date'])->update($data_sale_price_end_date);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_manage_stock'])->update($data_manage_stock);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_manage_stock_back_to_order'])->update($data_manage_stock_back_to_order);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_extra_features'])->update($data_extra_features);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_enable_as_recommended'])->update($data_enable_recommended);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_enable_as_features'])->update($data_enable_features);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_enable_as_latest'])->update($data_enable_latest);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_enable_as_related'])->update($data_enable_related);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_enable_as_custom_design'])->update($data_enable_custom_design);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_enable_as_selected_cat'])->update($data_enable_home_product);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_enable_taxes'])->update($data_enable_taxes);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_custom_designer_settings'])->update($data_custom_designer_settings);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_custom_designer_data'])->update($data_custom_designer_data);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_enable_reviews'])->update($data_enable_review);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_enable_reviews_add_link_to_product_page'])->update($data_p_page);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_enable_reviews_add_link_to_details_page'])->update($data_d_page);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_enable_video_feature'])->update($data_enable_product_video);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_video_feature_display_mode'])->update($data_display_mode);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_video_feature_title'])->update($data_title_for_video);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_video_feature_panel_size'])->update($data_video_feature_panel_size);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_video_feature_source'])->update($data_video_source_name);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_video_feature_source_embedded_code'])->update($data_video_embed_code);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_video_feature_source_online_url'])->update($data_video_online_url);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_enable_manufacturer'])->update($data_enable_manufacturer);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_enable_visibility_schedule'])->update($data_visibilityschedule);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_seo_title'])->update($data_seo_title);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_seo_description'])->update($data_seo_description);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_seo_keywords'])->update($data_seo_keywords);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_product_compare_data'])->update($data_compare_product);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_is_role_based_pricing_enable'])->update($data_is_role_based_enable);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_role_based_pricing'])->update($data_role_based_pricing);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_downloadable_product_files'])->update($data_downloadable_product_files);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_downloadable_product_download_limit'])->update($data_downloadable_product_download_limit);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_downloadable_product_download_expiry'])->update($data_downloadable_product_download_expiry);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_selected_vendor'])->update($selected_vendor);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_upsell_products'])->update($upsell_selected_product);
            ProductExtra::where(['product_id' => $product_id, 'key_name' => '_crosssell_products'])->update($crosssell_selected_product);

            $is_object_exist = ObjectRelationship::where('object_id', $product_id)->get();

            if(count($is_object_exist)>0){
              ObjectRelationship::where('object_id', $product_id)->delete();
            }

            //save categories
            if(Input::has('inputCategoriesName') && count(Input::get('inputCategoriesName'))>0){
              $cat_array = array();

              foreach(Input::get('inputCategoriesName') as $cat_id){
                $cat_data = array('term_id'  =>  $cat_id, 'object_id'  => $product_id, 'created_at'  =>  date("y-m-d H:i:s", strtotime('now')), 'updated_at'  =>  date("y-m-d H:i:s", strtotime('now')));

                array_push($cat_array, $cat_data);
              }

              if(count($cat_array) > 0){
                ObjectRelationship::insert( $cat_array );    
              }
            }

            //save manufacturer
            if(Input::has('inputManufacturerName') && count(Input::get('inputManufacturerName'))>0){
              $manufacturer_array = array();

              foreach(Input::get('inputManufacturerName') as $brands_id){
                $manufacturer_data = array('term_id'  => $brands_id, 'object_id'  => $product_id, 'created_at'  =>  date("y-m-d H:i:s", strtotime('now')), 'updated_at'  =>  date("y-m-d H:i:s", strtotime('now')));

                array_push($manufacturer_array, $manufacturer_data);   
              }

              if(count($manufacturer_array) > 0){
                ObjectRelationship::insert( $manufacturer_array );    
              }
            }

            //save tags
            if(Input::has('inputTagsName') && count(Input::get('inputTagsName'))>0){
              $tags_array = array();

              foreach(Input::get('inputTagsName') as $tags_id){
                $tags_data = array('term_id'  => $tags_id, 'object_id'  => $product_id, 'created_at'  =>  date("y-m-d H:i:s", strtotime('now')), 'updated_at'  =>  date("y-m-d H:i:s", strtotime('now')));

                array_push($tags_array, $tags_data);   
              }

              if(count($tags_array) > 0){
                ObjectRelationship::insert( $tags_array );    
              }
            }

            //save colors
            if(Input::has('inputColorsName') && count(Input::get('inputColorsName'))>0){
              $colors_array = array();

              foreach(Input::get('inputColorsName') as $colors_id){
                $colors_data = array('term_id'  => $colors_id, 'object_id'  => $product_id, 'created_at'  =>  date("y-m-d H:i:s", strtotime('now')), 'updated_at'  =>  date("y-m-d H:i:s", strtotime('now')));

                array_push($colors_array, $colors_data);   
              }

              if(count($colors_array) > 0){
                ObjectRelationship::insert( $colors_array );    
              }
            }

            //save sizes
            if(Input::has('inputSizesName') && count(Input::get('inputSizesName'))>0){
              $sizes_array = array();

              foreach(Input::get('inputSizesName') as $sizes_id){
                $sizes_data = array('term_id'  => $sizes_id, 'object_id'  => $product_id, 'created_at'  =>  date("y-m-d H:i:s", strtotime('now')), 'updated_at'  =>  date("y-m-d H:i:s", strtotime('now')));

                array_push($sizes_array, $sizes_data);   
              }

              if(count($sizes_array) > 0){
                ObjectRelationship::insert( $sizes_array );    
              }
            }

            Session::flash('success-message', Lang::get('admin.successfully_updated_msg' ));
            return redirect()->route('admin.update_product', $params);
          }
        }
      }  
    }
    else{
      return redirect()-> back();
    }
  }*/
  
  /**
   * Get function for products data
   *
   * @param products id
   * @param products id required
   * @return array
   */
  public function getProductDataById( $product_id , $visibilityStatus = '')
  {  
    $post_array       =   array();
    $user_filter_arr = ['id'=> $product_id];
    if(Session::get('enum_user_type_status') != 'Y' && $visibilityStatus != 'admin' )
    {
      $user_filter_arr = $user_filter_arr + array('product_visibility_status' => 'normal');
    }
    $get_post         =   Product :: where($user_filter_arr)->first();
    $get_post_meta    =   ProductExtra :: where('product_id', $product_id)->get();
    
    if(!empty($get_post)){
      $post_array['id']                       =  $get_post->id;
      $post_array['author_id']                =  $get_post->author_id;
      $post_array['txtProductDescriptionText']=  $get_post->txtProductDescriptionText;
      $post_array['seller_product_code']=  $get_post->seller_product_code;
      $post_array['post_content']             =  $get_post->content;
      $post_array['content_mobile']           =  $get_post->content_mobile;
      $post_array['post_title']               =  $get_post->title;
      $post_array['post_slug']                =  $get_post->slug;
      $post_array['post_status']              =  $get_post->status;
      $post_array['visibility_status']        =  $get_post->product_visibility_status;
      $post_array['post_sku']                 =  $get_post->sku;
      $post_array['post_regular_price']       =  $get_post->regular_price;
      $post_array['discount_percent']       =  $get_post->discount_percent;
      $post_array['post_sale_price']          =  $get_post->sale_price;
      $post_array['post_price']               =  $get_post->price;
      $post_array['product_point_on_sale']    =  $get_post->product_point_on_sale;
      $post_array['manage_stock']               =  $get_post->manage_stock;
      $post_array['post_stock_qty']           =  $get_post->stock_qty;   
      $post_array['stock_qty_default']           =  $get_post->stock_qty_default; 
      $post_array['post_stock_availability']  =  $get_post->stock_availability;
      $post_array['post_type']                =  $get_post->type;
      $post_array['post_image_url']           =  $get_post->image_url;
      $post_array['product_sale_mode']           =  $get_post->product_sale_mode;
      $post_array['product_condition_status']           =  $get_post->product_condition_status;
      $post_array['product_tax']           =  $get_post->product_tax;
      $post_array['product_model_name']           =  $get_post->product_model_name;
      $post_array['product_manufacturer']           =  $get_post->product_manufacturer;
      $post_array['product_origin']           =  $get_post->product_origin;
      $post_array['available_for_minors']           =  $get_post->available_for_minors;
      $post_array['sale_period_mode']           =  $get_post->sale_period_mode;
      $post_array['sale_period_start_date']           =  $get_post->sale_period_start_date;
      $post_array['sale_period_end_date']           =  $get_post->sale_period_end_date;
      $post_array['allow_non_bankruptible_deposit']           =  $get_post->allow_non_bankruptible_deposit;
      $post_array['post_product_description_text']           =  $get_post->txtProductDescriptionText;

      if(!empty($get_post_meta)){
        foreach($get_post_meta as $val){
          if($val->key_name == '_product_related_images_url'){
            $post_array[$val->key_name] = json_decode($val->key_value);
            $post_array['product_related_img_json'] = $val->key_value;
          }
          elseif($val->key_name == '_product_custom_designer_panel_size' || $val->key_name == '_product_video_feature_panel_size' ||  $val->key_name == '_product_selected_categories' || $val->key_name == '_product_selected_tags'){
            $post_array[$val->key_name] = unserialize($val->key_value);  
          }
          elseif($val->key_name == '_product_custom_designer_data'){
            $post_array[$val->key_name] = json_decode($val->key_value);
            $post_array['product_custom_designer_json'] = $val->key_value;
          }
          elseif($val->key_name == '_product_custom_designer_settings'){
            $post_array[$val->key_name] = unserialize($val->key_value);
          }
          elseif($val->key_name == '_product_compare_data' || $val->key_name == '_product_color_filter_data'){
            $post_array[$val->key_name] = unserialize($val->key_value);
          }
          elseif($val->key_name == '_role_based_pricing'){
            $post_array[$val->key_name] = unserialize($val->key_value);
          }
          elseif($val->key_name == '_downloadable_product_files'){
            $post_array[$val->key_name] = unserialize($val->key_value);
          }
          else{
            $post_array[$val->key_name] = $val->key_value;  
          }
        }
      }
    }
    
    return $post_array;
  }
  
  /**
   * Get function for brands products
   *
   * @param $term slug
   * @return array
   */
  public function getBrandDataBySlug($term_slug){
    $brand_data =  array();
    $get_brand_term = Term :: where(['slug' => $term_slug, 'type' => 'product_brands', 'status' => 1])->first();
    
    if(!empty($get_brand_term)){
      $brand_term_details = $this->getTermDataById($get_brand_term->term_id);
      $brand_data['brand_details']  =  array_shift($brand_term_details);
      $user_filter_arr = ['products.status' => 1, 'object_relationships.term_id' => $get_brand_term->term_id ];
    if(Session::get('enum_user_type_status') != 'Y')
    {
     $user_filter_arr = $user_filter_arr + array('product_visibility_status' => 'normal'); 
    }
      $brand_data['products'] =  null;
      $get_object_data =  DB::table('products')
                          ->where($user_filter_arr)
                          ->join('object_relationships', 'object_relationships.object_id', '=', 'products.id')
                          ->select('products.*')
                          ->orderBy('products.id', 'desc')
                          ->paginate(10);
      
      if(count($get_object_data) > 0){
        $brand_data['products'] =  $get_object_data;
      }
    }
     
    return $brand_data;
  }
  
  /**
   * Get function for categories list by object id
   *
   * @param object id
   * @return array
   */
  public function getCatByObjectId($object_id){
    $get_cat_array = array('term_id' => array(), 'term_details' => array());
    $get_cat_list  =  DB::table('terms')
                      ->where(['object_relationships.object_id' => $object_id, 'terms.type' => 'product_cat' ])
                      ->join('object_relationships', 'object_relationships.term_id', '=', 'terms.term_id')
                      ->select('terms.*')        
                      ->get()
                      ->toArray();
     
    if(count($get_cat_list) > 0){
      $term_id   = array();
      $term_data = array();
      
      foreach($get_cat_list as $row){
        array_push($term_id, $row->term_id);
        
        $get_term = $this->getTermDataById( $row->term_id );
        if(count($get_term) > 0){
          array_push($term_data, array_shift( $get_term ));
        }
      }
      
      $get_cat_array['term_id']      = $term_id;
      $get_cat_array['term_details'] = $term_data;
    }
    
    return $get_cat_array;
  }
  
  /**
   * Get function for top parent
   *
   * @param cat id
   * @return parent id
   */
  public function getTopParentId($cat_id){
    $get_term = $this->getTermDataById($cat_id);
    
    if(count($get_term)>0){
      if($get_term[0]['parent'] > 0){
        $this->getTopParentId($get_term[0]['parent']);
      }
      else{
        $this->parent_id = $get_term[0]['term_id'];
      }
      
      if(!empty($this->parent_id) > 0){
        return $this->parent_id;
      }
    }
  }
  
  /**
   * Get function for tags list by object id
   *
   * @param object id
   * @return array
   */
  public function getTagsByObjectId($object_id){
    $get_tag_array = array('term_id' => array(), 'term_details' => array());
    $get_tag_list  =  DB::table('terms')
                      ->where(['object_relationships.object_id' => $object_id, 'terms.type' => 'product_tag' ])
                      ->join('object_relationships', 'object_relationships.term_id', '=', 'terms.term_id')
                      ->select('terms.*')        
                      ->get()
                      ->toArray();
     
    if(count($get_tag_list) > 0){
      $term_id = array();
      $term_data = array();
      
      foreach($get_tag_list as $row){
        array_push($term_id, $row->term_id);
        
        $get_term = $this->getTermDataById( $row->term_id );
        if(count($get_term) > 0){
          array_push($term_data, array_shift( $get_term ));
        }
      }
      
      $get_tag_array['term_id']      = $term_id;
      $get_tag_array['term_details'] = $term_data;
    }
    
    return $get_tag_array;
  }
  
  /**
   * Get function for colors list by object id
   *
   * @param object id
   * @return array
   */
  public function getColorsByObjectId($object_id){
    $get_colors_array = array('term_id' => array(), 'term_details' => array());
    $get_colors_list  =  DB::table('terms')
                         ->where(['object_relationships.object_id' => $object_id, 'terms.type' => 'product_colors' ])
                         ->join('object_relationships', 'object_relationships.term_id', '=', 'terms.term_id')
                         ->select('terms.*')        
                         ->get()
                         ->toArray();
     
    if(count($get_colors_list) > 0){
      $term_id = array();
      $term_data = array();
      
      foreach($get_colors_list as $row){
        array_push($term_id, $row->term_id);
        
        $get_term = $this->getTermDataById( $row->term_id );
        if(count($get_term) > 0){
          array_push($term_data, array_shift( $get_term ));
        }
      }
      
      $get_colors_array['term_id']      = $term_id;
      $get_colors_array['term_details'] = $term_data;
    }
    
    return $get_colors_array;
  }
  
  /**
   * Get function for sizes list by object id
   *
   * @param object id
   * @return array
   */
  public function getSizesByObjectId($object_id){
    $get_sizes_array = array('term_id' => array(), 'term_details' => array());
    $get_sizes_list  =  DB::table('terms')
                        ->where(['object_relationships.object_id' => $object_id, 'terms.type' => 'product_sizes' ])
                        ->join('object_relationships', 'object_relationships.term_id', '=', 'terms.term_id')
                        ->select('terms.*')        
                        ->get()
                        ->toArray();
     
    if(count($get_sizes_list) > 0){
      $term_id = array();
      $term_data = array();
      
      foreach($get_sizes_list as $row){
        array_push($term_id, $row->term_id);
        
        $get_term = $this->getTermDataById( $row->term_id );
        if(count($get_term) > 0){
          array_push($term_data, array_shift( $get_term ));
        }
      }
      
      $get_sizes_array['term_id']      = $term_id;
      $get_sizes_array['term_details'] = $term_data;
    }
    
    return $get_sizes_array;
  }
  
  /**
   * Get function for manufacturer list by object id
   *
   * @param object id
   * @return array
   */
  public function getManufacturerByObjectId($object_id){
    $get_brands_array = array('term_id' => array(), 'term_details' => array());
    $get_brands_list  = DB::table('terms')
                        ->where(['object_relationships.object_id' => $object_id, 'terms.type' => 'product_brands' ])
                        ->join('object_relationships', 'object_relationships.term_id', '=', 'terms.term_id')
                        ->select('terms.*')        
                        ->get()
                        ->toArray();
     
    if(count($get_brands_list) > 0){
      $term_id = array();
      $term_data = array();
      
      foreach($get_brands_list as $row){
        array_push($term_id, $row->term_id);
        
        $get_term = $this->getTermDataById( $row->term_id );
        if(count($get_term) > 0){
          array_push($term_data, array_shift( $get_term ));
        }
      }
      
      $get_brands_array['term_id']      = $term_id;
      $get_brands_array['term_details'] = $term_data;
    }
    
    return $get_brands_array;
  }

  /**
   * 
   * Get products list view page data 
   *
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Created On : 20-April-2019
   * 
   * @param pagination required. Boolean type TRUE or FALSE, by default false
   * @param search value optional
   * @param status flag by default -1. -1 for all data, 1 for status enable and 0 for disable status
   * @return array
   */
  public function getProductListViewPageData($pagination = false, $search_val = null, $status_flag = -1, $author_id=0, $perPage=5, $pType='all', $pids='all', $callType='', $whereNotInIds=array())
  {
    $where = '';
     
    $perPage = ($perPage > 30) ? 30 :$perPage;
    
    $post_author_id = 0;
    if (is_numeric($author_id) && $author_id > 0) {
      $post_author_id = $author_id;
    } else  if((is_vendor_login() || is_admin_login()) && Session::has('shopist_admin_user_id'))
    {
      $post_author_id = Session::get('shopist_admin_user_id');
    }
     
    if($status_flag != -1)
    {
      $where = ['P.author_id' => $post_author_id, 'P.status' => $status_flag];
    }
    else{
      $where = ['P.author_id' => $post_author_id];
    }  
    

    // Query to fetch products data.
     
    if(!empty($search_val) && $search_val != '' && !empty($where))
    {
      // Query to fetch products data.
      $get_posts_for_product = DB::table('products AS P')
        ->join('object_relationships as OBR', 'OBR.object_id', '=', 'P.id')
        ->join('terms as T', function($join) {
          $join->on('T.term_id', '=', 'OBR.term_id')->where(function($q) {
              $q->where('T.type', '=', 'product_cat');
          });
        })->where($where)
        ->where('P.title', 'LIKE', '%'. $search_val .'%');
      
    }
    elseif(!empty($search_val) && $search_val != '' && empty($where)){
      // Query to fetch products data.
      $get_posts_for_product = DB::table('products AS P')
        ->join('object_relationships as OBR', 'OBR.object_id', '=', 'P.id')
        ->join('terms as T', function($join) {
          $join->on('T.term_id', '=', 'OBR.term_id')->where(function($q) {
              $q->where('T.type', '=', 'product_cat');
          });
        })->where('P.title', 'LIKE', '%'. $search_val .'%');
    }
    elseif (empty($search_val)  && !empty($where)) {
     
      // Query to fetch products data.
      $get_posts_for_product = DB::table('products AS P')
        ->join('object_relationships as OBR', 'OBR.object_id', '=', 'P.id')
        ->join('terms as T', function($join) {
          $join->on('T.term_id', '=', 'OBR.term_id')->where(function($q) {
              $q->where('T.type', '=', 'product_cat');
          });
        })->where($where);
    }
    else{
     
       // Query to fetch products data.
      $get_posts_for_product = DB::table('products AS P')
        ->join('object_relationships as OBR', 'OBR.object_id', '=', 'P.id')
        ->join('terms as T', function($join) {
          $join->on('T.term_id', '=', 'OBR.term_id')->where(function($q) {
              $q->where('T.type', '=', 'product_cat');
          });
        });
    }

    /*if ($callType =='pmgstore')
    {
      $get_posts_for_product->where([['P.stock_availability', '=', 'in_stock']]);
    } else if ($callType =='pmgstoreFrontEnd')
    {
      $get_posts_for_product->where(function ($query) {
          $query->where('P.stock_availability', '=', 'in_stock')
                ->orWhere('P.stock_availability', '=', 'out_of_stock');
      });
    }*/

    $queryObj = $get_posts_for_product; 


    if ($callType =='pmgstore' || $callType =='pmgstoreFrontEnd')
    {
      $queryObj = $queryObj->select('P.id','P.stock_availability')
                ->get()->toArray();
    } else
    {
      $queryObj = $queryObj->select('P.id','P.stock_availability')
        ->orderBy('P.id', 'desc')->get()->toArray();
    }
    
    // Filter these ids products from result.
    if (isset($whereNotInIds) && count($whereNotInIds) > 0){
      $get_posts_for_product->whereNotIn('P.id', $whereNotInIds);
    }
 
    if ($pType =='on_sale')
    {
      $get_posts_for_product->where([['P.stock_availability', '=', 'in_stock']]);
    } else if ($pType =='out_of_stock')
    {
       
       $get_posts_for_product->where([['P.stock_availability', '=', 'out_of_stock']]);
    } else if ($pType =='hidden'){
       
       $get_posts_for_product->where([['P.stock_availability', '=', 'hidden']]);
    }

    if ($pids !='' && $pids !='all')
    {
      $pids=(isset($pids))? explode(",",$pids):array();
      $get_posts_for_product = $get_posts_for_product->whereIn('P.id',$pids);
      if ($callType =='pmgstore' || $callType =='pmgstoreFrontEnd')
      {
        $ids_ordered = implode(',', $pids);
        $get_posts_for_product = $get_posts_for_product->orderByRaw(DB::raw("FIELD(P.id, $ids_ordered)"));
      }
    }
    
    if ($callType =='export')
    {

      $get_posts_for_product = $get_posts_for_product->select('P.*','T.term_id','T.name as categoryName')
      ->orderBy('P.id', 'desc')->get()->toArray();
      $product_data = $get_posts_for_product;

    } else if ($callType =='pmgstore' || $callType =='pmgstoreFrontEnd')
    {

      
      $get_posts_for_product = $get_posts_for_product->select('P.id','P.stock_availability','P.txtProductDescriptionText','P.seller_product_code','P.available_for_minors','P.title','P.sale_price','P.stock_qty','P.stock_qty_default','P.slug','P.created_at','P.type','P.image_url','T.term_id','T.name as categoryName')
       ->get()->toArray();
      $product_data = $get_posts_for_product;

    } else
    {
     
      $get_posts_for_product = $get_posts_for_product->select('P.*','T.term_id','T.name as categoryName')
      ->orderBy('P.id', 'desc')->paginate($perPage)->toArray();
      $product_data =  (isset($get_posts_for_product['data']) && count($get_posts_for_product['data']) > 0)?$get_posts_for_product['data']:array();

    }
 
    if (isset($product_data) && count($product_data) > 0)
    {
      $array_updated = array();
      foreach ($product_data as $data) 
      {
            
          $get_product_option_data = DB::table('product_extras as PE')
            ->join('products as P', 'P.id', '=', 'PE.product_id')->where('PE.product_id', '=', $data->id)->where('PE.key_name', '=', '_product_section_data_options_json')->select('PE.key_value')->first();

          $option_data = (isset($get_product_option_data->key_value)) ? $get_product_option_data->key_value : '';
          $option_array = convert_json_string_to_array($option_data);
          
          if(isset($option_array['requiredOptions']) && !empty($option_array['requiredOptions']))
          {
            $quantity = $data->stock_qty;
          }else{
            $quantity = $data->stock_qty_default;
          }
          $data->stock_qty_custom=$quantity;
          $array_updated[]=$data;
         
      }
    } 
       
    if ($pType =='on_sale'){
      $get_product_status = 'in_stock';
    } else if ($pType =='out_of_stock'){
       
       $get_product_status = 'out_of_stock';
    } else if ($pType =='hidden'){
       
       $get_product_status = 'hidden';
    } else if ($pType =='all'){
       
       $get_product_status = 'all';
    }
    
    $totalProduct=0;    $totalProductInStock=0;    $totalProductOutOfStock=0;  $totalProductHidden=0; 
    if (isset($queryObj) && count($queryObj) > 0)
    {
      $array_updated = array();
      foreach ($queryObj as $row) 
      {
        $totalProduct++;
        if ($row->stock_availability=='in_stock'){
          $totalProductInStock++;
        }
        if ($row->stock_availability=='out_of_stock'){
          $totalProductOutOfStock++;
        }
        if ($row->stock_availability=='hidden'){
          $totalProductHidden++;
        } 

      }
    }
    if ($callType !='pmgstore' && $callType !='pmgstoreFrontEnd')
    {
      $get_posts_for_product['totalProduct'] = $totalProduct;
      $get_posts_for_product['totalProductInStock'] = $totalProductInStock;
      $get_posts_for_product['totalProductOutOfStock'] = $totalProductOutOfStock;
      $get_posts_for_product['totalProductHidden'] = $totalProductHidden;
    }
 
    // return data.
    return $get_posts_for_product;
  }

  /**
   * 
   * Get products list data
   *
   * @param pagination required. Boolean type TRUE or FALSE, by default false
   * @param search value optional
   * @param status flag by default -1. -1 for all data, 1 for status enable and 0 for disable status
   * @return array
   */
  public function getProducts($pagination = false, $search_val = null, $status_flag = -1, $author_id)
  {
    $where = '';

    if(
      (is_vendor_login() && Session::has('shopist_admin_user_id')) 
      || (!empty($author_id) && $author_id > 0 && $author_id != 'all')
    ) {
      
      $post_author_id = 0;
      
      if(!empty($author_id) && $author_id > 0 && $author_id != 'all'){
        $post_author_id = $author_id;
      }
      else{
        $post_author_id = Session::get('shopist_admin_user_id');
      }

      if($status_flag != -1){
        $where = ['author_id' => $post_author_id, 'status' => $status_flag];
      }
      else{
        $where = ['author_id' => $post_author_id];
      }
    }
    else{
      if($status_flag != -1){
        $where = ['status' => $status_flag];
      }
    }


    if(!empty($search_val) && $search_val != '' && !empty($where))
    {
      $get_posts_for_product = Product:: where($where)
      ->where('title', 'LIKE', '%'. $search_val .'%')
      ->orderBy('id', 'desc')
      ->paginate(30);
    }
    elseif(!empty($search_val) && $search_val != '' && empty($where)){
      $get_posts_for_product = Product:: where('title', 'LIKE', '%'. $search_val .'%')
      ->orderBy('id', 'desc')
      ->paginate(30);
    }
    elseif (empty($search_val)  && !empty($where)) {
      $get_posts_for_product = Product:: where($where)
      ->orderBy('id', 'desc')
      ->paginate(30);
    }
    else{
      $get_posts_for_product = Product:: orderBy('id', 'desc')
      ->paginate(30);
    }

    return $get_posts_for_product;
  }
  
  /**
   * Get products by user id and name
   *
   * @param user_id, user_name
   * @return array
   */
  public function getProductsByUserId( $user_id, $user_name, $filter = array() ){
    $data_array    =  array();
    $product_data  =  array();
    $filter_arr    =  array();
    $get_posts_for_product = null;
    $final_data = array();
    
    $product_data['min_price']          =   0;
    $product_data['max_price']          =   300;
    $product_data['selected_colors']    =  array();
    $product_data['selected_sizes']     =  array();
    $product_data['selected_colors_hf'] =  '';
    $product_data['selected_sizes_hf']  =  '';
    $product_data['sort_by']            =  '';
    
    //color filter
    if(isset($filter['selected_colors'])){
      $parse_colors = explode(',', $filter['selected_colors']);

      if(count($parse_colors) > 0){
        $product_data['selected_colors'] = $parse_colors;

        foreach($parse_colors as $color){
          $get_color_term = Term::where(['slug' => $color, 'type' => 'product_colors'])->first();

          if(!empty($get_color_term) && $get_color_term->term_id){
            array_push($filter_arr, array('id' => $get_color_term->term_id, 'name' => $get_color_term->name, 'slug' => $get_color_term->slug, 'search_type' => 'color-filter'));
          }
        }
      }
    }
        
    //size filter
    if(isset($filter['selected_sizes'])){
      $parse_sizes = explode(',', $filter['selected_sizes']);

      if(count($parse_sizes) > 0){
        $product_data['selected_sizes']  =  $parse_sizes;

        foreach($parse_sizes as $size){
          $get_size_term = Term::where(['slug' => $size, 'type' => 'product_sizes'])->first();

          if(!empty($get_size_term) && $get_size_term->term_id){
            array_push($filter_arr, array('id' => $get_size_term->term_id, 'name' => $get_size_term->name, 'slug' => $get_size_term->slug, 'search_type' => 'size-filter'));
          }
        }
      }
    }
      
    if(count($filter_arr) > 0){
      foreach($filter_arr as $term_filter){
      $user_filter_arr = ['products.author_id' => $user_id, 'products.status' => 1];
      
      if(Session::get('enum_user_type_status') != 'Y')
      {
        $user_filter_arr = $user_filter_arr + array('products.product_visibility_status' => 'normal');
      }
        $get_posts_for_product  = DB::table('products')
                                  ->where($user_filter_arr);
        
        if( isset($filter['price_min']) && isset($filter['price_max']) && $filter['price_min'] >= 0 && $filter['price_max'] >=0){
          $get_posts_for_product->where(['object_relationships.term_id' => $term_filter['id']]);
          $get_posts_for_product->whereRaw('products.price >=' . $filter['price_min']);
          $get_posts_for_product->whereRaw('products.price <=' . $filter['price_max']);
          $get_posts_for_product->join('object_relationships', 'object_relationships.object_id', '=', 'products.id');
        }

        $get_posts_for_product->select('products.*'); 
        $get_posts_for_product = $get_posts_for_product->get()->toArray();
        
        if(count($get_posts_for_product) > 0){
          foreach($get_posts_for_product as $post){
            $post_data = (array)$post;
            $data_array[$post->id] = $post_data;
          }
        }
      }
    }
    else{
    $user_filter_arr = ['author_id' => $user_id, 'status' => 1];
    if(Session::get('enum_user_type_status') != 'Y')
    {
      $user_filter_arr=  $user_filter_arr + array('product_visibility_status' => 'normal');
    }
       $get_posts_for_product  = DB::table('products')
                                ->where($user_filter_arr);
      
      if( isset($filter['price_min']) && isset($filter['price_max']) && $filter['price_min'] >= 0 && $filter['price_max'] >=0 ){
        $get_posts_for_product->whereRaw('price >=' . $filter['price_min']);
        $get_posts_for_product->whereRaw('price <=' . $filter['price_max']);
      }
      
      $get_posts_for_product->select('products.*'); 
      
      //sorting
      if(isset($filter['sort']) && $filter['sort'] == 'alpaz'){
        $get_posts_for_product->orderBy('title', 'ASC');
      }
      elseif (isset($filter['sort']) && $filter['sort'] == 'alpza') {
        $get_posts_for_product->orderBy('title', 'DESC');
      }
      elseif (isset($filter['sort']) && $filter['sort'] == 'low-high') {
        $get_posts_for_product->orderBy('price', 'ASC');
      }
      elseif (isset($filter['sort']) && $filter['sort'] == 'high-low') {
        $get_posts_for_product->orderBy('price', 'DESC');
      }
      elseif (isset($filter['sort']) && $filter['sort'] == 'old-new') {
        $get_posts_for_product->orderBy('created_at', 'ASC');
      }
      elseif (isset($filter['sort']) && $filter['sort'] == 'new-old') {
        $get_posts_for_product->orderBy('created_at', 'DESC');
      }
      
      $get_posts_for_product = $get_posts_for_product->paginate(10);
    }
    
    if( isset($filter['price_min']) && isset($filter['price_max']) && $filter['price_min'] >= 0 && $filter['price_max'] >=0){
      $product_data['min_price']  =   $filter['price_min'];
      $product_data['max_price']  =   $filter['price_max'];
    }

    if(isset($filter['selected_colors'])){
      $product_data['selected_colors_hf'] =  $filter['selected_colors'];
    }

    if(isset($filter['selected_sizes'])){
      $product_data['selected_sizes_hf']  =  $filter['selected_sizes'];
    }

    if(isset($filter['sort'])){
      $product_data['sort_by'] = $filter['sort'];
    }
     
    
    if(count($filter_arr) > 0){
      if(count($data_array) > 0){
        if(isset($filter['sort']) && $filter['sort'] != 'all'){
          if($filter['sort'] == 'alpaz'){
            $data_array = $this->classCommonFunction->sortBy($data_array, 'title', 'asc');
          }
          elseif($filter['sort'] == 'alpza'){
            $data_array = $this->classCommonFunction->sortBy($data_array, 'title', 'desc');
          }
          elseif($filter['sort'] == 'low-high'){
            $data_array = $this->classCommonFunction->sortBy($data_array, 'price', 'asc');
          }
          elseif($filter['sort'] == 'high-low'){
            $data_array = $this->classCommonFunction->sortBy($data_array, 'price', 'desc');
          }
          elseif($filter['sort'] == 'old-new'){
            $data_array = $this->classCommonFunction->sortBy($data_array, 'created_at', 'asc');
          }
          elseif($filter['sort'] == 'new-old'){
            $data_array = $this->classCommonFunction->sortBy($data_array, 'created_at', 'desc');
          }
        }
        else{
          $data_array = $this->classCommonFunction->sortBy($data_array, 'id', 'desc');
        }
      }
    
      if(count($data_array) > 0){
        foreach($data_array as $row){
          array_push($final_data, (object)$row);
        }
      }
      
      $currentPage = LengthAwarePaginator::resolveCurrentPage();
      $col = new Collection( $final_data );
      $perPage = 10;
      $currentPageSearchResults = $col->slice(($currentPage - 1) * $perPage, $perPage)->all();
      $posts_object = new LengthAwarePaginator($currentPageSearchResults, count($col), $perPage);
      $posts_object->setPath(route('store-products-page-content', $user_name) );

      $product_data['products'] = $posts_object;
    }
    else{
      $product_data['products'] = $get_posts_for_product;
    }
    
    return $product_data;
  }

  /**
  * Get product comments list
  *
  * @param null
  * @return array
  */
  
  public function getProductCommentsList(){
    $comments_data = array();
    
    if(is_vendor_login() && Session::has('shopist_admin_user_id')){
      $where = ['products.author_id' => Session::get('shopist_admin_user_id'), 'comments.target' => 'product'];
    }
    else{
      $where = ['comments.target' => 'product'];
    }
    
    $get_comments = DB::table('comments')->where($where)
                    ->join('products', 'comments.object_id', '=', 'products.id')
                    ->join('users', 'comments.user_id', '=', 'users.id')
                    ->select('comments.*', 'products.title', 'products.slug', 'users.display_name', 'users.user_photo_url')   
                    ->paginate(10);
      
    if(count($get_comments) > 0){
        $comments_data = $get_comments;
    }
    
    return $comments_data;
  }
  
  /**
   * Get function for advance products
   *
   * @param null
   * @return array
   */
  public function getAdvancedProducts(){
    $best_sales_arr      =  array();
    $todays_deal_arr     =  array();
    $advanced_arr        =  array();
  $user_filter_arr     = array();
    if(Session::get('enum_user_type_status') != 'Y')
  {
    $user_filter_arr = $user_filter_arr + array('product_visibility_status' => 'normal');
  }
    if(Request::is('/')){
      $get_recommended_items = DB::table('products')->where($user_filter_arr)
                               ->select('products.*')
                               ->join(DB::raw("(SELECT product_id FROM product_extras WHERE key_name = '_product_enable_as_recommended' AND key_value = 'yes') T1") , 'products.id', '=', 'T1.product_id')
                               ->take(8)
                               ->get()
                               ->toArray();

      $get_features_items =    DB::table('products')->where($user_filter_arr)
                               ->select('products.*')
                               ->join(DB::raw("(SELECT product_id FROM product_extras WHERE key_name = '_product_enable_as_features' AND key_value = 'yes') T1") , 'products.id', '=', 'T1.product_id')
                               ->take(8)
                               ->get()
                               ->toArray();
    }
    
    $get_latest_items =      DB::table('products')->where($user_filter_arr)
                             ->select('products.*')
                             ->join(DB::raw("(SELECT product_id FROM product_extras WHERE key_name = '_product_enable_as_latest' AND key_value = 'yes') T1") , 'products.id', '=', 'T1.product_id')
                             ->take(5)
                             ->get()
                             ->toArray();
   
    if(Request::is('/')){ 
      $get_todays_items      =  DB::table('posts')
                                ->where('posts.post_type', 'shop_order')
                                ->whereDate('posts.created_at', '=', $this->carbonObject->today()->toDateString())
                                ->join('orders_items', 'orders_items.order_id', '=', 'posts.id')
                                ->orderBy('posts.id', 'desc')
                                ->select('orders_items.*')
                                ->take(5)
                                ->get()
                                ->toArray();
    }
    
    $get_best_sales        =  DB::table('product_extras')
                              ->select('product_id', DB::raw('max(cast(key_value as SIGNED INTEGER)) as max_number'))
                              ->where('key_name', '_total_sales')
                              ->groupBy('product_id')
                              ->orderBy('max_number', 'desc')
                              ->take(5)
                              ->get()
                              ->toArray();
     
    //best sales
    if(count($get_best_sales) > 0){
      foreach($get_best_sales as $items4){
        $get_post_for_best_sales = $this->getProductDataById($items4->product_id);
        
        if(count($get_post_for_best_sales)>0){
          array_push($best_sales_arr, $get_post_for_best_sales);
        }
      }
    }
    
    if(Request::is('/')){
      //todays deal
      if(count($get_todays_items) > 0){
        foreach($get_todays_items as $items5){
          if(!empty($items5->order_data)){
            $parse = json_decode($items5->order_data, true);

            if(count($parse) > 0){
              foreach($parse as $items6){
                if(isset($items6['id'])){
                  if(!$this->classCommonFunction->is_item_already_exists_in_array($items6['id'], $todays_deal_arr)){
                    $get_post_for_todays_deal = $this->getProductDataById($items6['id']);

                    if(count($get_post_for_todays_deal) > 0){
                      array_push($todays_deal_arr, $get_post_for_todays_deal);
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    
    if(Request::is('/')){
      $advanced_arr['recommended_items']  =   $get_recommended_items;
      $advanced_arr['features_items']     =   $get_features_items;
      $advanced_arr['todays_deal']        =   $todays_deal_arr; 
    }
    $advanced_arr['latest_items']         =   $get_latest_items;
    $advanced_arr['best_sales']           =   $best_sales_arr; 
     
    return $advanced_arr;
  }
  
  /**
   * Get function for vendor advance products
   *
   * @param vendor_id
   * @return array
   */
  public function getVendorAdvancedProducts( $vendor_id ){
    $best_sales_arr      =  array();
    $todays_deal_arr     =  array();
    $advanced_arr        =  array();
    $user_filter_arr = ['products.author_id' => $vendor_id];
  if(Session::get('enum_user_type_status') != 'Y')
  {
    $user_filter_arr = $user_filter_arr + array('product_visibility_status' => 'normal');
  }
    $get_recommended_items = DB::table('products')
                             ->where($user_filter_arr) 
                             ->select('products.*')
                             ->join(DB::raw("(SELECT product_id FROM product_extras WHERE key_name = '_product_enable_as_recommended' AND key_value = 'yes') T1") , 'products.id', '=', 'T1.product_id')
                             ->take(8)
                             ->get()
                             ->toArray();

    $get_features_items =    DB::table('products')
                             ->where($user_filter_arr) 
                             ->select('products.*')
                             ->join(DB::raw("(SELECT product_id FROM product_extras WHERE key_name = '_product_enable_as_features' AND key_value = 'yes') T1") , 'products.id', '=', 'T1.product_id')
                             ->take(8)
                             ->get()
                             ->toArray();
    
    $get_latest_items =      DB::table('products')
                             ->where($user_filter_arr) 
                             ->select('products.*')
                             ->join(DB::raw("(SELECT product_id FROM product_extras WHERE key_name = '_product_enable_as_latest' AND key_value = 'yes') T1") , 'products.id', '=', 'T1.product_id')
                             ->take(5)
                             ->get()
                             ->toArray();
    
    $get_todays_items      =  DB::table('posts')
                              ->where('posts.post_type', 'shop_order')
                              ->whereDate('posts.created_at', '=', $this->carbonObject->today()->toDateString())
                              ->join('orders_items', 'orders_items.order_id', '=', 'posts.id')
                              ->orderBy('posts.id', 'desc')
                              ->select('orders_items.*')
                              ->limit(10)
                              ->get()
                              ->toArray();
    
    $get_best_sales        =  DB::table('product_extras')
                              ->select('product_id', DB::raw('max(cast(key_value as SIGNED INTEGER)) as max_number'))
                              ->where('key_name', '_total_sales')
                              ->groupBy('product_id')
                              ->orderBy('max_number', 'desc')
                              ->limit(10)
                              ->get()
                              ->toArray();
     
    //best sales
    if(count($get_best_sales) > 0){
      foreach($get_best_sales as $items4){
        $get_post_for_best_sales = $this->getProductDataById($items4->product_id);
        
        if(isset($get_post_for_best_sales['author_id']) && $get_post_for_best_sales['author_id'] == $vendor_id){
          if(count($get_post_for_best_sales)>0){
            array_push($best_sales_arr, $get_post_for_best_sales);
          }
        }
      }
    }
    
    //todays deal
    if(count($get_todays_items) > 0){
      foreach($get_todays_items as $items5){
        if(!empty($items5->order_data)){
          $parse = json_decode($items5->order_data, true);
          
          if(count($parse) > 0){
            foreach($parse as $items6){
              if(isset($items6['id'])){
                if(!$this->classCommonFunction->is_item_already_exists_in_array($items6['id'], $todays_deal_arr)){
                  $get_post_for_todays_deal = $this->getProductDataById($items6['id'],'admin');
                
                  if($get_post_for_todays_deal['author_id'] == $vendor_id){
                    if(count($get_post_for_todays_deal) > 0){
                      array_push($todays_deal_arr, $get_post_for_todays_deal);
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    
    $advanced_arr['recommended_items']    =   $get_recommended_items;
    $advanced_arr['features_items']       =   $get_features_items;
    $advanced_arr['latest_items']         =   $get_latest_items;
    $advanced_arr['best_sales']           =   $best_sales_arr; 
    $advanced_arr['todays_deal']          =   $todays_deal_arr; 
     
    return $advanced_arr;
  }
  
  /**
   * Get function for product search filter with pagination
   *
   * @param search options
   * @return array
   */
  public function getFilterProductsDataWithPagination( $filter = array(),$perPage=20 ){
    $data_array    =  array();
    $product_data  =  array();
    $filter_arr    =  array();
    $get_posts_for_product = null;
	$sorting_condition = array();
	$filterQuery = 0;
    $final_data = array();
    $user_filter_arr =array();
    $product_data['min_price']          =   0;
    $product_data['max_price']          =   300;
    $product_data['selected_colors']    =  array();
    $product_data['selected_sizes']     =  array();
    $product_data['selected_colors_hf'] =  '';
    $product_data['selected_sizes_hf']  =  '';
    $product_data['sort_by']            =  '';
	$product_data['author_id']          =  0;
	$product_after_all_filteration =array();
	$countOfTotalSales  = array();
	$all_filter_products =array();
	$sorting_value = 'created_at';
    $sorting_order = 'DESC';   
	  
	 //Product Filter that have Status 1 (i.e. Products are disbale or deleted) Or Stock availability.
	  $user_filter_arr = ['products.status' => 1];
	  
	  //It checks Age of user If user is logged In.
	  if(is_frontend_user_logged_in()){
		 $frontend_user_data = get_current_frontend_user_info();
		 
		 $dob =  new \DateTime($frontend_user_data['dob']);
		 $now =  new \DateTime();
	
		//Calculate the time difference between the two dates.
		$difference = $now->diff($dob);
				 
		//Get the difference in years, as we are looking for the user's age.
		$age = $difference->y;
		if($age < 19){
			 $user_filter_arr+= ['products.available_for_minors' => 'Y'];
		 }
	  }
	 if(isset($filter['author_id']) && !empty($filter['author_id'])){
	    $user_filter_arr+= ['products.author_id' => $filter['author_id']];
	 }
	 $get_posts_for_product  = DB::table('products')
                                  ->where($user_filter_arr);
		
	  //Filter On the basis of Product title
      if(isset($filter['srch_term'])){
        $get_posts_for_product->where('title', 'like', '%'. $filter['srch_term'] .'%');
      }
    
      
	
	  
	   
      $get_posts_for_product = $get_posts_for_product->select('id')->get();
	 
		if(isset($get_posts_for_product) && count($get_posts_for_product)>0){
			  foreach($get_posts_for_product as $product){
				 
				 $saleModeStatus = $this->check_sale_mode($product->id);
				 $manageStockStatus = $this->check_manage_stock($product->id);
				
				 if($saleModeStatus == 1 && $manageStockStatus == 1){
					 array_push($all_filter_products,$product->id);
				 }
			  }
			
		  }
		
		
      //sorting
	  if(isset($filter['sort']) && $filter['sort'] == 'low_price_item') {
			$sorting_value = 'sale_price';
			$sorting_order = 'ASC';
      }
      elseif (isset($filter['sort']) && $filter['sort'] == 'high_price_item') {
		 $sorting_value = 'sale_price' ;
		 $sorting_order = 'DESC';
      }
      elseif (isset($filter['sort']) && $filter['sort'] == 'old-new') {
		  $sorting_value = 'created_at';
		  $sorting_order = 'ASC';
      }
      elseif (isset($filter['sort']) && $filter['sort'] == 'new_item') {
		  $sorting_value = 'created_at';
		  $sorting_order = 'DESC';
      }elseif (isset($filter['sort']) && $filter['sort'] == 'sales_quantity_item') {		
		
		$countOfTotalSales =  DB::table('products')
							->whereIn('products.id',$all_filter_products)
							->leftjoin('product_extras',function($join){
								$join->on('products.id','=','product_extras.product_id')
								->where(['product_extras.key_name' => '_total_sales']);
							})
							->select('products.*','product_extras.product_id', DB::raw('product_extras.key_value as total'))
							->orderBy('total','DESC')->paginate($perPage);
		$filterQuery =1;
			
      }
	  elseif (isset($filter['sort']) && $filter['sort'] == 'prodct_review_item') {		
			DB::enableQueryLog();
		$countOfTotalSales =  DB::table('products')
							->whereIn('products.id',$all_filter_products)
							->leftjoin('comments','products.id','=','comments.object_id')
							->select('products.*','comments.object_id',DB::raw('sum(comments.rating)/count(comments.object_id) as average'))
							->groupBy('products.id')
							->orderBy('average','DESC')->paginate($perPage);
		$filterQuery =1;
      }
	  elseif (isset($filter['sort']) && $filter['sort'] == 'heart_item') {		
		$countOfTotalSales =  DB::table('products')
							->whereIn('products.id',$all_filter_products)
							->leftjoin('wish_list','products.id','=','wish_list.product_id')
							->select('products.*','wish_list.product_id',DB::raw('count(wish_list.product_id) as total'))
							->groupBy('products.id')
							->orderBy('total','DESC')->paginate($perPage);
							
							
		$filterQuery =1;
      }
	  if($filterQuery == 1){
		  	$product_after_all_filteration = $countOfTotalSales;
	  }else{
			$product_after_all_filteration  = DB::table('products')
                                  ->whereIn('id',$all_filter_products)
								  ->orderBy($sorting_value,$sorting_order)
								  ->paginate($perPage);
	  }
								  
		
    if(isset($filter['sort'])){
      $product_data['sort_by'] = $filter['sort'];
    }
     
    $product_data['products'] = $product_after_all_filteration;
   
    return $product_data;
  }
  
  /**
   * Get function for products by cat slug
   *
   * @param cat options
   * @return array
   */
  public function getProductByCatSlug($cat_slug, $filter = array() ,$search_term = '',$author_id=''){
    $data_array         =   array();
    $post_array         =   array();
    $selected_cat       =   array();
    $color_size_obj_id  =   array(); 
    $filter_arr         =   array();
	
	$post_array['selected_cat']  =  isset($filter['selected_cat'])? $filter['selected_cat'] : $cat_slug;  
	$get_term = Term::where(['slug' => $cat_slug, 'type' => 'product_cat'])->first();
	$get_product_term = Term::where(['slug' => $post_array['selected_cat'], 'type' => 'product_cat'])->first();
  
  
    if(!empty($get_term) && isset($get_term->term_id)){
      $str    = '';
      $cat_id = $get_term->term_id;
      
      $post_array['min_price']          =  0;
      $post_array['max_price']          =  300;
      $post_array['selected_colors']    =  array();
      $post_array['selected_sizes']     =  array();
      $post_array['selected_colors_hf'] =  '';
      $post_array['selected_sizes_hf']  =  '';
      $post_array['sort_by']  =  '';
      $post_array['view']  =  10;
      
      
      $get_term_data = $this->getTermDataById( $get_term->term_id );
     
      $get_child_cat = $this->get_categories($get_product_term->term_id, 'product_cat');
  
      //$parent_id     = $this->getTopParentId( $get_term->term_id );
      $parent_id     = $get_term->term_id;

      $cat_data['id']    =  $get_term_data[0]['term_id'];
      $cat_data['name']  =  $get_term_data[0]['name'];
      $cat_data['slug']  =  $get_term_data[0]['slug'];
      
      if($get_term_data[0]['parent'] == 0){
        $cat_data['parent']  =  'Parent Categories';
      }
      else{
        $cat_data['parent']  =  'Sub Categories';
      }
      
      $cat_data['parent_id']  =  $get_term_data[0]['parent'] ;
      $cat_data['description']  =  $get_term_data[0]['category_description'];
      $cat_data['img_url']  =  $get_term_data[0]['category_img_url'];
      $cat_data['search_type']  =  'category-filter';
    
      $user_filter_arr = ['products.status' => 1,];

   
      if(count($get_child_cat) > 0)
	  {
		$all_cat = array();
        $cats_arr = $this->createCategoriesSimpleList( $get_child_cat );
                
        if(count($cats_arr) > 0){
          $cats_arr = array_map(function($cats_arr){
            return $cats_arr + ['search_type' => 'category-filter'];
          }, $cats_arr);
        }
              
        if(count($filter_arr) > 0 && count($cats_arr) > 0){
          $cats_arr = array_merge($filter_arr, $cats_arr);
        }
       
        foreach($cats_arr as $cat)
		{
          if( (count($filter_arr) > 0 && ($cat['search_type'] == 'color-filter' || $cat['search_type'] == 'size-filter')) || (count($filter_arr) == 0 && $cat['search_type'] == 'category-filter')){
			$user_filter_array = $user_filter_arr + array('object_relationships.term_id' => $cat['id']);
      
            $get_post_data =  DB::table('products');
            $get_post_data->where($user_filter_array)->where('stock_availability','!=','hidden');
      
          

            $get_post_data->join('object_relationships', 'object_relationships.object_id', '=', 'products.id');

            $get_post_data->select('products.*');
			
			if( isset($author_id) && !empty($author_id))
			{
				$get_post_data->where(['author_id' => $author_id]);
            }
			if( isset($search_term) && !empty($search_term)){
                $get_post_data->where('title', 'LIKE', '%'. $search_term .'%');
            }
            $get_post_data = $get_post_data->get()->toArray();
			
            
            if(count($get_post_data) > 0){
              foreach($get_post_data as $post){
                $filter_cat = array();
                
                if($cat['search_type'] == 'color-filter' || $cat['search_type'] == 'size-filter'){
                  $filter_cat = $this->getCatByObjectId( $post->id );
                }

                if( (($cat['search_type'] == 'color-filter' || $cat['search_type'] == 'size-filter') && $this->classCommonFunction->is_product_cat_in_selected_cat($filter_cat, $all_cat)) || ($cat['search_type'] == 'category-filter') ){
                  $post_data = (array)$post;
                  $data_array[$post->id] = $post_data;
           
                }
              }
            }
          }   

          if($cat['search_type'] == 'category-filter'){
            array_push($selected_cat, $cat['id']);
          }
        }
      }
      else{ 
        $parent_cat_ary = array();
        $parent_cat_ary[] = $get_product_term;
        $all_cat = $parent_cat_ary;
        
        if(count($filter_arr) > 0){
          $parent_cat_ary = array_merge($filter_arr, $parent_cat_ary);
        }
    
        if(count($parent_cat_ary) > 0){ 
          foreach($parent_cat_ary as $cat){
           
              $user_filter_array = $user_filter_arr + array('object_relationships.term_id' => $cat['term_id']);
              $get_post_data =  DB::table('products');
              $get_post_data->where($user_filter_array)->where('stock_availability','!=','hidden');
			  if( isset($author_id) && !empty($author_id))
			  {
				  $get_post_data->where(['author_id' => $author_id]);
			  }
              if( isset($search_term) && !empty($search_term)){
                $get_post_data->where('title', 'LIKE', '%'. $search_term .'%');

              }

              $get_post_data->join('object_relationships', 'object_relationships.object_id', '=', 'products.id');

              $get_post_data->select('products.*');
              $get_post_data = $get_post_data->get()->toArray();

              if(count($get_post_data) > 0){
                foreach($get_post_data as $post){
                  $filter_cat = array();

                  if($cat['search_type'] == 'color-filter' || $cat['search_type'] == 'size-filter'){
                    $filter_cat = $this->getCatByObjectId( $post->id );
                  }

                
                    $post_data = (array)$post;
                    $data_array[$post->id] = $post_data;
                 
        
                }
              }
          

            if($cat['search_type'] == 'category-filter'){
              array_push($selected_cat, $cat['id']);
            }
          }
        }
      }
      if(isset($filter['sort'])){
        $post_array['sort_by'] = $filter['sort'];
      }
      
      if(count($data_array) > 0){
        if(isset($filter['sort']) && $filter['sort'] != 'all'){
          if($filter['sort'] == 'alpaz'){
            $data_array = $this->classCommonFunction->sortBy($data_array, 'title', 'asc');
          }
          elseif($filter['sort'] == 'alpza'){
            $data_array = $this->classCommonFunction->sortBy($data_array, 'title', 'desc');
          }
          elseif($filter['sort'] == 'low-high'){
            $data_array = $this->classCommonFunction->sortBy($data_array, 'price', 'asc');
          }
          elseif($filter['sort'] == 'high-low'){
            $data_array = $this->classCommonFunction->sortBy($data_array, 'price', 'desc');
          }
          elseif($filter['sort'] == 'old-new'){
            $data_array = $this->classCommonFunction->sortBy($data_array, 'created_at', 'asc');
          }
          elseif($filter['sort'] == 'new-old'){
            $data_array = $this->classCommonFunction->sortBy($data_array, 'created_at', 'desc');
          }
        }
        else{
          $data_array = $this->classCommonFunction->sortBy($data_array, 'id', 'desc');
        }
      }
     
      $currentPage = LengthAwarePaginator::resolveCurrentPage();
      $col = new Collection( $data_array );
      $perPage = isset($filter['view_by'])? $filter['view_by'] :10;
      $currentPageSearchResults = $col->slice(($currentPage - 1) * $perPage, $perPage)->all();
   
      $posts_object = new LengthAwarePaginator($currentPageSearchResults, count($col), $perPage);
      $posts_object->setPath( route('categories-page', $cat_data['slug']) );
      
      
      if($cat_data['parent_id'] > 0){
        $parent_cat = $this->getTermDataById( $cat_data['parent_id'] );
        
        $str = '<nav id="PMGBreadcrumb" aria-label="breadcrumb"><ol class="breadcrumb"><li class="breadcrumb-item"><a href="'. route('home-page') .'">PMG</a></li><li class="breadcrumb-item"><a href="'. route('shop-page') .'">'. Lang::get('frontend.all_products_label' ) .'</a></li><li class="breadcrumb-item"><a href="'. route('categories-page', $parent_cat[0]['slug']) .'">'. $parent_cat[0]['name'] .'</a></li><li class="breadcrumb-item active" aria-current="page">'. $cat_data['name'] .'</li></ol></nav>';
      }
      else{
        $str = '<nav id="PMGBreadcrumb" aria-label="breadcrumb"><ol class="breadcrumb"><li class="breadcrumb-item"><a href="'. route('home-page') .'">PMG</a></li><li class="breadcrumb-item"><a href="'. route('shop-page') .'">'. Lang::get('frontend.all_products_label' ) .'</a></li><li class="breadcrumb-item active" aria-current="page">'. $cat_data['name'] .'</li></ol></nav>';
      }
   
      $post_array['products']        =  $posts_object;
      $post_array['breadcrumb_html'] =  $str;
      $post_array['selected_cat']    =  $selected_cat;
      $post_array['parent_id']       =  $cat_data['id'];
      $post_array['parent_slug']     =  $cat_data['slug'];
      $post_array['parent_name']     =  $cat_data['name'];
    } 
    return $post_array;
  }
    
  /**
   * Get function for attributes
   *
   * @param product id
   * @return array
   */
  public function getAllAttributes($product_id){
    $get_available_attribute = array();
    $get_attr_from_global  =  $this->getTermData( 'product_attr', false, null, 1 );
        
    if(count($get_attr_from_global) > 0){
      foreach($get_attr_from_global as $term){
        $ary = array();
        $ary['attr_id']     = $term['term_id'];
        $ary['attr_name']   = $term['name'];
        $ary['attr_values'] = $term['product_attr_values'];
        $ary['attr_status'] = $term['status'];
        $ary['created_at']  = $term['created_at'];
        $ary['updated_at']  = $term['updated_at'];

        array_push($get_available_attribute, $ary);
      }
    }
    
    $get_attr_by_products  =  PostExtra::where(['post_id' => $product_id, 'key_name' => '_attribute_post_data'])->get()->toArray();
    
    if(count($get_attr_by_products)>0){
      $parseJsonToArray = json_decode($get_attr_by_products[0]['key_value']);
      
      if(!empty($parseJsonToArray)){
        foreach($parseJsonToArray as $row){
          $ary = array();
          $ary['attr_id']     = $row->id;
          $ary['attr_name']   = $row->attr_name;
          $ary['attr_values'] = $row->attr_val;
          $ary['attr_status'] = 1;
          $ary['created_at']  = $get_attr_by_products[0]['created_at'];
          $ary['updated_at']  = $get_attr_by_products[0]['updated_at'];

          array_push($get_available_attribute, $ary);
        }
      }
    }
    
    return $get_available_attribute;
  }
  
  /**
   * Get products by cat id
   *
   * @param cat id
   * @return array
   */
  public function getProductsByTermId($term_id){
    $object_array = array();
	$user_filter_arr = ['products.status' => 1,'products.stock_availability' => 'in_stock','object_relationships.term_id' => $term_id ];
	if(is_frontend_user_logged_in()){
		 $frontend_user_data = get_current_frontend_user_info();
		 
		 $user_dob = new \DateTime($frontend_user_data['dob']);
		 $current_date = new \DateTime;
		 $user_age =  $user_dob->diff($current_date)->y;
		 if($user_age<19){
			 $user_filter_arr+= ['products.available_for_minors' => 'Y'];
		 }
	  }
    $get_post_data =  DB::table('products')
                      ->where($user_filter_arr)
                      ->join('object_relationships', 'object_relationships.object_id', '=', 'products.id')
                      ->select('products.*')
                      ->orderBy('products.id', 'desc')
                      ->get()
                      ->toArray();
    
    if(count($get_post_data) > 0){
      $object_array = $get_post_data;
    }
    
    return $object_array;
  }
  
  /**
   * Get related items
   *
   * @param product id
   * @return array
   */
  
  public function getRelatedItems($product_id){
    $related_items  =  array();
    $related_products  =  array();
    
    //categories product search
    $cat_lists = $this->getCatByObjectId($product_id);
    
    if(count($cat_lists) > 0 && isset($cat_lists['term_id']) && count($cat_lists['term_id']) > 0){
      foreach($cat_lists['term_id'] as $cat_id){
        $cat_term = $this->getTermDataById($cat_id);
        
        if(count($cat_term) > 0){
          $get_cat_product_list  =  $this->getProductsByTermId($cat_term[0]['term_id']);
          
          if(count($get_cat_product_list) >0){
            foreach($get_cat_product_list as $product){
              if($product->id != $product_id){
                array_push($related_items, $product);
              }
            }
          }
        }
      }
    }
	//Filter all Products For Manage Stock or Sale Period Mode.
	if(isset($related_items) && count($related_items)>0){
		  foreach($related_items as $product){
			 
			 $saleModeStatus = $this->check_sale_mode($product->id);
			 $manageStockStatus = $this->check_manage_stock($product->id);
			
			 if($saleModeStatus == 1 && $manageStockStatus == 1){
				 array_push($related_products,$product);
			 }
		  }
		
	  }
  
    return $related_products;
  }
  /** Function to get Related Products By seller Id
  *   Date  : 18-04-2019
  *  <ayushma.jain@gaurish.com> Ayushma Jain
  **/
  public function getRelatedSellersItems($product_id){
    $related_seller_items  =  array();
    $related_seller_products  =  array();
	$user_filter_arr= array();
    
    //categories product search
    $seller_id = get_vendor_id_by_product_id($product_id);
	$user_filter_arr = ['status'=>1,'stock_availability' => 'in_stock','author_id'=>$seller_id];
	
	if(is_frontend_user_logged_in()){
		 $frontend_user_data = get_current_frontend_user_info();
		 
		 $user_dob = new \DateTime($frontend_user_data['dob']);
		 $current_date = new \DateTime;
		 $user_age =  $user_dob->diff($current_date)->y;
		 if($user_age<19){
			 $user_filter_arr+= ['products.available_for_minors' => 'Y'];
		 }
	  }
	  $related_seller_items  = DB::table('products')->where($user_filter_arr)->select('*')
													->orderBy('products.id', 'desc')
													->get()->toArray();
			
	  //Filter all Products For Manage Stock or Sale Period Mode.
	  if(isset($related_seller_items) && count($related_seller_items)>0){
		  foreach($related_seller_items as $product){
				 
			 $saleModeStatus = $this->check_sale_mode($product->id);
			 $manageStockStatus = $this->check_manage_stock($product->id);
				
			 if($saleModeStatus == 1 && $manageStockStatus == 1){
				 array_push($related_seller_products,$product);
			  }
		  }
			
	  }
    
    return $related_seller_products;
  }
  
  /**
  * Function : Funttion to download excel for product review data.
  * <anuj@gaurish.com>
  **/
  public function exportProductsListData()
  {
    $productSearchTerm = '';
    $pType = 'all';
      
    if(isset($_POST['d_pType']) && $_POST['d_pType'] != ''){
      $pType = $_POST['d_pType'];
    }  
    if(isset($_POST['d_productSearchTerm']) && $_POST['d_productSearchTerm'] != ''){
      $productSearchTerm = $_POST['d_productSearchTerm'];
    }
    
    $perPage=(isset($_POST['d_perPage']))?$_POST['d_perPage']:10;
    $data = $this->classCommonFunction->commonDataForAllPages();

    //$pids=(isset($_POST['d_pids']))? $_POST['d_pids']:'';
    $pids= 'all';
     
    $post_author_id = (is_vendor_login() && Session::has('shopist_admin_user_id'))?Session::get('shopist_admin_user_id'):0;
    
    $callType = "export";

    // Calling this functions to get only active products whose products.status=1.
    $product_all_data  =  $this->getProductListViewPageData(true, $productSearchTerm, 1, $post_author_id, $perPage, $pType, $pids, $callType);
 
    $data = array(); //$a=0;
    if(count($product_all_data)>0)
    {  
      foreach($product_all_data as $list)
      {
        if (isset($list->id) && is_numeric($list->id)) 
        {
          $createdAtDate = '';
          if ($list->created_at !='' && $list->created_at !='0000-00-00 00:00:00'){
            $createdAtDate = date('Y.m.d',strtotime($list->created_at));
          }

          $updatedAtDate = '';
          if ($list->updated_at !='' && $list->updated_at !='0000-00-00 00:00:00'){
            $updatedAtDate = date('Y.m.d',strtotime($list->updated_at));
          }
   
          //$row['S.No.']=$a;
          $row['상품번호']=$list->id;
          $row['상품명']=$list->title;
          //$row['판매가']=number_format($list->sale_price);
          $row['판매가']=$list->sale_price;
          $row['카테고리']=$list->categoryName;
          
          if ($list->stock_availability=='in_stock')
          {
            $statusValue =  '판매중';
          } else if ($list->stock_availability=='out_of_stock')
          {
            $statusValue =  '품절';
          } else
          {
            $statusValue =  '숨김';
          }
          
          $row['상태']=$statusValue;
          $row['재고']=(isset($list->stock_qty_custom) && $list->stock_qty_custom != '')?$list->stock_qty_custom:0;
          $row['등록일']=$createdAtDate;
          $row['수정일']=$updatedAtDate;
          array_push($data,$row);
           //$a++;
        } 
      }
    } 
     
    $filename = '제품수출 - '.date('Y.m.d h:i:s').'-'.mt_rand();
    // Generate and return the spreadsheet
    return Excel::create($filename, function($excel) use ($data) {

      $excel->sheet('제품수출', function($sheet) use ($data)
      {
        $sheet->fromArray($data, null, 'A1', true);

      });
    })->download('xls'); 
  }

  /**
   * 
   *Export products 
   *
   * @param null
   * @return void
   */
  public function manageExportProducts(){
    $export_data  = array();
    $get_products = array();
    $post_author_id = 0;
    if((is_vendor_login() || is_admin_login()) 
       && (Session::has('shopist_admin_user_id') && is_numeric(Session::get('shopist_admin_user_id')))
    ){
      $post_author_id = Session::get('shopist_admin_user_id');
    }

    $where = ['author_id' => $post_author_id, 'status' => '1'];  
    $get_products = Product :: where($where)->orderBy('id', 'DESC')->get()->toArray();
    
    if(count($get_products) > 0){
      foreach($get_products as $rows){
        $regular_price = '';
        $sku = '';
        $short_features = '';
        $recommended = FALSE;
        $features = FALSE;
        $latest = FALSE;
        $related = FALSE;
        $home_page = FALSE;
        $reviews = FALSE;
        $p_reviews = FALSE;
        $d_reviews = FALSE;
        $seo_title = '';
        $seo_desc = '';
        $seo_keywords = '';
        $visibility = FALSE;
        
        $regular_price = $rows['regular_price'];
        $sku = $rows['sku'];
        
        if($rows['status'] == 1){
          $visibility = TRUE;
        }

        $get_post_extras = ProductExtra::where(['product_id' => $rows['id']])->get()->toArray();
        if(count($get_post_extras) > 0){
          foreach($get_post_extras as $post_extras){
            if($post_extras['key_name'] == '_product_extra_features'){
              $short_features = $post_extras['key_value'];
            }
            if($post_extras['key_name'] == '_product_enable_as_recommended'){
              if($post_extras['key_value'] == 'yes'){
                $recommended = TRUE;
              }
            }
            if($post_extras['key_name'] == '_product_enable_as_features'){
              if($post_extras['key_value'] == 'yes'){
                $features = TRUE;
              }
            }
            if($post_extras['key_name'] == '_product_enable_as_latest'){
              if($post_extras['key_value'] == 'yes'){
                $latest = TRUE;
              }
            }
            if($post_extras['key_name'] == '_product_enable_as_related'){
              if($post_extras['key_value'] == 'yes'){
                $related = TRUE;
              }
            }
            if($post_extras['key_name'] == '_product_enable_as_selected_cat'){
              if($post_extras['key_value'] == 'yes'){
                $home_page = TRUE;
              }
            }
            if($post_extras['key_name'] == '_product_enable_reviews'){
              if($post_extras['key_value'] == 'yes'){
                $reviews = TRUE;
              }
            }
            if($post_extras['key_name'] == '_product_enable_reviews_add_link_to_product_page'){
              if($post_extras['key_value'] == 'yes'){
                $p_reviews = TRUE;
              }
            }
            if($post_extras['key_name'] == '_product_enable_reviews_add_link_to_details_page'){
              if($post_extras['key_value'] == 'yes'){
                $d_reviews = TRUE;
              }
            }
            if($post_extras['key_name'] == '_product_seo_title'){
              $seo_title = $post_extras['key_value'];
            }
            if($post_extras['key_name'] == '_product_seo_description'){
              $seo_desc = $post_extras['key_value'];
            }
            if($post_extras['key_name'] == '_product_seo_keywords'){
              $seo_keywords = $post_extras['key_value'];
            }
          }
        }

        array_push($export_data, array('title' => $rows['title'], 'description' => $rows['content'], 'regular_price' => $regular_price, 'sku' => $sku, 'extra_features' => $short_features, 'enable_recommended' => ($recommended) ? 'TRUE' : 'FALSE', 'enable_features' => ($features) ? 'TRUE' : 'FALSE', 'enable_latest' => ($latest) ? 'TRUE' : 'FALSE', 'enable_related' => ($related) ? 'TRUE' : 'FALSE', 'enable_home' => ($home_page) ? 'TRUE' : 'FALSE', 'visibility' => ($visibility) ? 'TRUE' : 'FALSE', 'reviews' => ($reviews) ? 'TRUE' : 'FALSE', 'p_reviews' => ($p_reviews) ? 'TRUE' : 'FALSE', 'd_reviews' => ($d_reviews) ? 'TRUE' : 'FALSE', 'seo_title' => $seo_title, 'seo_desc' => $seo_desc, 'seo_keywords' => $seo_keywords));
      }
    }

    $filename = 'products_export_'.time().'-'.mt_rand().'.csv';
    $headers = array(
      "Content-type" => "text/csv",
      "Content-Disposition" => "attachment; filename=". $filename,
      "Pragma" => "no-cache",
      "Cache-Control" => "must-revalidate, post-check=0, pre-check=0",
      "Expires" => "0"
    );

    $columns = array('Title', 'Description(HTML)', 'Regular Price', 'SKU', 'Features(HTML)', 'Recommended Product', 'Features Product', 'Latest Product', 'Related Product', 'Home Page Product', 'Visibility', 'Enable Reviews', 'Enable Review Product Page', 'Enable Review Details Page', 'SEO Title', 'SEO Description', 'SEO Keywords(Comma Separator)');

    $callback = function() use ($export_data, $columns){
      $file = fopen('php://output', 'w');
      fputcsv($file, $columns);

      if(count($export_data) > 0){
        foreach($export_data as $data) {
          fputcsv($file, array($data['title'], $data['description'], $data['regular_price'], $data['sku'], $data['extra_features'], $data['enable_recommended'], $data['enable_features'], $data['enable_latest'], $data['enable_related'], $data['enable_home'], $data['visibility'], $data['reviews'], $data['p_reviews'], $data['d_reviews'], $data['seo_title'], $data['seo_desc'], $data['seo_keywords']));
        }
      }

      fclose($file);
    };

    return Response::stream($callback, 200, $headers);
  }
  
  /**
   * 
   * Get designer shape list
   *
   * @param null
   * @return void
   */
  public function getShapeList($pagination = false, $search_val = null, $status_flag = -1){
    $data = array();
    
    if($status_flag == -1){
      $where = ['post_type' => 'designer_shape'];
    }
    else{
      $where = ['post_type' => 'designer_shape', 'post_status' => $status_flag];
    }
    
    if($search_val && $search_val != null){
      $get_post = Post:: where($where)
                         ->where('post_title', 'LIKE', '%'. $search_val .'%')
                         ->orderBy('id', 'desc')
                         ->get()
                         ->toArray();
    }
    else{
      $get_post = Post:: where($where)
                         ->orderBy('id', 'desc')
                         ->get()
                         ->toArray();
    }
    
    if(count($get_post) > 0){
      $data = $get_post;
    }
    
    if($pagination){
      $currentPage = LengthAwarePaginator::resolveCurrentPage();
      $col = new Collection( $data );
      $perPage = 10;
      $currentPageSearchResults = $col->slice(($currentPage - 1) * $perPage, $perPage)->all();
      $posts_object = new LengthAwarePaginator($currentPageSearchResults, count($col), $perPage);
      $posts_object->setPath( route('admin.shape_list_content') );
    }
    
    if($pagination){
      return $posts_object;
    }
    else{
     return $data; 
    }
  }
  
  /**
   * 
   * Get designer fonts list
   *
   * @param null
   * @return void
   */
  public function getFontsList($pagination = false, $search_val = null, $status_flag = -1){
    $data = array();
    
    if($status_flag == -1){
      $where = ['post_type' => 'custom_font'];
    }
    else{
      $where = ['post_type' => 'custom_font', 'post_status' => $status_flag];
    }
    
    if($search_val && $search_val !=null){
      $get_post = Post:: where($where)
                         ->where('post_title', 'LIKE', '%'. $search_val .'%')
                         ->orderBy('id', 'desc')
                         ->get()
                         ->toArray();
    }
    else{
      $get_post = Post:: where($where)
                         ->orderBy('id', 'desc')
                         ->get()
                         ->toArray();
    }
    
    if(count($get_post) > 0){
      foreach($get_post as $row){
        $get_meta = PostExtra :: where('post_id', $row['id'])->first();
        if(!empty($get_meta)){
          $row['url'] = $get_meta['key_value'];
        }
        
        array_push($data, $row);
      }
    }
    
    if($pagination){
      $currentPage = LengthAwarePaginator::resolveCurrentPage();
      $col = new Collection( $data );
      $perPage = 10;
      $currentPageSearchResults = $col->slice(($currentPage - 1) * $perPage, $perPage)->all();
      $posts_object = new LengthAwarePaginator($currentPageSearchResults, count($col), $perPage);
      $posts_object->setPath( route('admin.fonts_list_content') );
    }
    
    if($pagination){
      return $posts_object;
    }
    else{
     return $data; 
    }
  }
  
  /**
   * 
   * Get post meta
   *
   * @param post_id, key_name
   * @return object
   */
  public function get_post_meta($post_id, $key_name){
    $get_post_meta = null;
    $post_meta  = PostExtra::where(['post_id' => $post_id, 'key_name' => $key_name])->first();
    if(!empty($post_meta)){
      $get_post_meta = $post_meta;
    }
    
    return $get_post_meta;
  }
  
  /**
   * 
   * Create product content data
   *
   * @param array
   * @return array
   */
  function createProductContentData($data){
    $data['tabSettings']['btnCustomize']   =   'style=display:none;';
    $data['categories_lists']              =   $this->get_categories( 0, 'product_cat');
    $data['tags_lists']                    =   $this->getTermData( 'product_tag', false, null, 1 );
    $data['attrs_list_data']               =   $this->getTermData( 'product_attr', false, null, 1 );
    $data['colors_lists']                  =   $this->getTermData( 'product_colors', false, null, 1 );
    $data['sizes_lists']                   =   $this->getTermData( 'product_sizes', false, null, 1 );
    $data['manufacturer_lists']            =   $this->getTermData( 'product_brands', false, null, 1 );
    $data['available_user_roles']          =   get_available_user_roles();
    $data['vendors_list']                  =   $this->vendors->getAllVendors( false, null, 1 );
    $data['fields_name']                   =   $this->option->getProductCompareData();
    $data['settings_data']                 =   $this->option->getSettingsData();
    $data['currency_symbol']               =   $this->classCommonFunction->get_currency_symbol( $data['settings_data']['general_settings']['currency_options']['currency_name'] );
    
    $data['product_all_images_json']      =    json_encode(  
                                                            array(                                                                                                                                                    'product_image'            => '',
                                                              'product_gallery_images'   => array(),
                                                              'shop_banner_image'        => ''
                                                            )
                                                          );
    
    // Calling this function to get all categories list by parent cat id.
    $data['mainCategories'] = $this->getCategoriesByParentCatId(0);
   
    // Calling this function to get all brands list from term table.
    $data['allBrands'] = $this->getCategoriesByParentCatId(0, 'product_brands');

    // Calling this function to get all product government category for normal products from product_government_category table.
    $data['govtCategory']  =  ProductGovtCategory :: where('display_product_type', 'N')->select('id','name')->orderBy('id', 'ASC')->get()->toArray();
    $data['return_shipping_data'] = $this->getSellerDefaultShippingInfo("return_shipping_data");
    
    return $data;
  }

  /**
   * Get function for getting all categories list by parent category id.
   * 
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Created On : 26-Feb-2019
   *
   * @param parentCatId, catType
   * @return array
   */
 public function getCategoriesByParentCatId($parentCatId = 0, $catType="product_cat", $orderByField="intPosition", $orderByValue="asc", $values="")
  {
    
    
    $getCategoriesData  =  Term::where(['type' => $catType, 'parent' => $parentCatId, 'status' => 1])->orderBy($orderByField, $orderByValue)->get();
   
    $categories = array();

    if($getCategoriesData->count() > 0){
      foreach ($getCategoriesData as $mainCategory)
      {
        $category = array();
        // Adding logics and condition for Hiding few defined categories from seller screen only.
        if(is_vendor_login() && $mainCategory->display_status =='all')
        {
          $category['name']                  =  $mainCategory->name;
          $category['term_id']                  =  $mainCategory->term_id;
          if ($values == 'all')
          {
            $category['slug']                  =  $mainCategory->slug;
            $category['category_icon']                  =  $mainCategory->category_icon;
            $category['intPosition']                  =  $mainCategory->intPosition;
            $category['category_price_type']                  =  $mainCategory->category_price_type;
            $category['category_price']                  =  $mainCategory->category_price;
          }
          //$category['slug']                  =  $mainCategory->slug;
          $categories[] =  $category;
        } else if(is_admin_login() 
          && ($mainCategory->display_status =='all' || $mainCategory->display_status =='pmgadmin')
        ){
          $category['name']                  =  $mainCategory->name;
          $category['term_id']                  =  $mainCategory->term_id;
          if ($values == 'all')
          {
            $category['slug']                  =  $mainCategory->slug;
            $category['category_icon']                  =  $mainCategory->category_icon;
            $category['intPosition']                  =  $mainCategory->intPosition;
            $category['category_price_type']                  =  $mainCategory->category_price_type;
            $category['category_price']                  =  $mainCategory->category_price;
          }
          $categories[] =  $category;

        }/* else {
          $category['name']                  =  $mainCategory->name;
          $category['slug']                  =  $mainCategory->slug;
          $categories[$mainCategory->term_id] =  $category;
        }  */      
      }
    }
   
    return $categories;
  } 

  /**
   * Post function for getting all categories list by parent category id.
   * 
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Created On : 26-Feb-2019
   *
   * @return array
   */
  public function postGetCategoriesByParentCatId()
  {
    $categories = array();
    if( Request::isMethod('post') && Session::token() == Input::get('_token') )
    {

      $parentCatId = Input::get('id');
      $elementId = Input::get('elementId');
     
      if (!empty(Input::get('id')))
      {
        if ((is_admin_login() || is_vendor_login())&& $elementId == '.selectSmallCategory')
        {
          //getting category charge type and price value when load small categories.
          $categories = $this->getCategoriesByParentCatId($parentCatId, "product_cat", "intPosition", "asc", "all");
        } else
        {
          $categories = $this->getCategoriesByParentCatId($parentCatId);
        }
        
      }
    }
    print_r(json_encode($categories));
  }

  /**
   * Function for getting top 100 categories by slaes quentity and sales amount price value.
   * 
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Created On : 06-May-2019
   *
   * @return array
   */
   
  public function getCategoriesDataByRating($orderByType='totalQty')
  {
    $finalData = array();
    //DB::enableQueryLog();
    if (is_admin_login() && $orderByType != '')
    {
      $post_author_id = 0;
      if(Session::has('shopist_admin_user_id') && is_numeric(Session::get('shopist_admin_user_id'))
      ){
        $post_author_id = Session::get('shopist_admin_user_id');
      }

      // Query to get top 100 categories by slaes quentity and sales amount price value.
      $selectCategoryQuery = "
      SELECT 
        IF(CR.total_sales_quantity IS NULL, 0, CR.total_sales_quantity) AS totalQty,
        IF(CR.total_sales_amount IS NULL, 0, CR.total_sales_amount) AS totalAmt,
        T.term_id,T.name,T.parent
      FROM categories_rating as CR
      RIGHT JOIN terms as T ON T.term_id=CR.category_id
      WHERE T.status=? AND T.author_id=? AND T.type=?
      ORDER BY {$orderByType} DESC LIMIT 100";
      //ORDER BY {$orderByType}, COALESCE(parent, term_id), parent IS NOT NULL, term_id ASC";

      $categories = DB::select($selectCategoryQuery, ['1', $post_author_id, 'product_cat']);
      $allActiveCategories = $this->getAllActiveCategories();
      $finalData = array();
      if (isset($categories) && count($categories))
      {
        foreach ($categories as $row) 
        {
          $categoryNamesArray  = $this->getParentsDataByCategoryId($row->term_id, $row->parent, 'name', $allActiveCategories);
          $row->breadcrumb = implode(" > ", $categoryNamesArray);
          $finalData[] = $row;
        }
      }

    }

    return $finalData;
  }

  /**
   * Function for getting parent categories data by child category.
   * 
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Created On : 06-May-2019
   *
   * @return array
   */
   
  public function getParentsDataByCategoryId($categoryId=0,$parentCategoryId=0, $valueType="term_id", $allActiveCategories=array())
  {
    $result = [];
    if (is_numeric($categoryId) && is_numeric($parentCategoryId))
    {
      $categoryData = array();
      
      $categoryData[] = $categoryId;
      
      $this->getCategoryByParentHierarchy($parentCategoryId, $categoryData, $allActiveCategories);

      // Sort array by key index in descending order.
      krsort($categoryData);
 
      // Re-index array starting to zero, simply do the following:
      $categoryData = array_values($categoryData);
      $finalConcatName='';
      $selectedLargeCat =(isset($categoryData[0]) && is_numeric($categoryData[0]))? $categoryData[0] : 0;
      if ($selectedLargeCat > 0)
      {
        $largeCategoryValue = (isset($allActiveCategories[$selectedLargeCat]->$valueType))?$allActiveCategories[$selectedLargeCat]->$valueType:''; 
        $result=[$largeCategoryValue];

        $selectedMiddleCat =(isset($categoryData[1]) && is_numeric($categoryData[1]))? $categoryData[1] : 0;
        if ($selectedMiddleCat > 0) 
        {
          $middleCategoryValue = (isset($allActiveCategories[$selectedMiddleCat]->$valueType))?$allActiveCategories[$selectedMiddleCat]->$valueType:''; 
          $result=[$largeCategoryValue, $middleCategoryValue];
           
          $selectedSmallCat =(isset($categoryData[2]) && is_numeric($categoryData[2]))? $categoryData[2] : 0;
          
          if ($selectedSmallCat > 0) 
          {
            $smallCategoryValue = (isset($allActiveCategories[$selectedSmallCat]->$valueType))?$allActiveCategories[$selectedSmallCat]->$valueType:''; 
            $result=[$largeCategoryValue, $middleCategoryValue, $smallCategoryValue];

            $selectedDetailCat =(isset($categoryData[3]) && is_numeric($categoryData[3]))? $categoryData[3] : 0;
            if ($selectedDetailCat > 0)
            {
              $detailCategoryValue = (isset($allActiveCategories[$selectedDetailCat]->$valueType))?$allActiveCategories[$selectedDetailCat]->$valueType:'';
              $result=[$largeCategoryValue, $middleCategoryValue, $smallCategoryValue, $detailCategoryValue];
            }
          }
        } 
      }
    }
    return $result;
  } 

  /**
   * Function for getting all active categories data.
   * 
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Created On : 06-May-2019
   *
   * @return array
   */
  public function getAllActiveCategories()
  {
    $categoriesArray = array();
    $post_author_id = 0;
    if(Session::has('shopist_admin_user_id') && is_numeric(Session::get('shopist_admin_user_id')))
    {
        $post_author_id = Session::get('shopist_admin_user_id');
    }

    // Query to get all active categories
    $getAllActiveCategoriesQuery = "
    SELECT T.term_id,T.name,T.parent
    FROM terms as T WHERE T.status=? AND T.author_id=? AND T.type=?";
    $allActiveCategories = DB::select($getAllActiveCategoriesQuery, ['1', $post_author_id, 'product_cat']);
    if (isset($allActiveCategories) && count($allActiveCategories))
    {
      foreach ($allActiveCategories as $value) {
        $categoriesArray[$value->term_id]= $value;
      }
    }
    return $categoriesArray;
  } 

  /**
   * Post function for getting all government categorie field by category id.
   * 
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Created On : 08-April-2019
   *
   * @return array
   */
  public function postGetGovernmentCategorieFieldsByCatId()
  {
    $categories = array();
    if( Request::isMethod('post') && Session::token() == Input::get('_token') )
    {
      $govtCatId = Input::get('id');
      if (!empty(Input::get('id'))){
        // Invoking that non-static method.
        $ProductGovtCategory = new ProductGovtCategory();
        $categories = $ProductGovtCategory->getGovtCategorieFieldByCatId($govtCatId);
      }
    }
    print_r(json_encode($categories));
  }

  /**
   * Get categories by parent category id in parent hierarchy reverse order.
   * 
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Created On : 28-Feb-2019
   *
   * @param productId, catType
   * @return array
   */
  public function getCategoryByParentHierarchy($parentId = 0, &$categoryData, $allActiveCategories=array())
  {
    // If you get categoryData 
    if ($parentId > 0) 
    {
      if(isset($allActiveCategories) && count($allActiveCategories) > 0)
      {
        $parentCategoryData[] = (isset($allActiveCategories[$parentId]))? $allActiveCategories[$parentId] : array();
      } else{
        $parentCategoryData   =  DB::table('terms')
          ->where(['terms.term_id' => $parentId, 'terms.type' => 'product_cat' ])
          ->select('terms.term_id','terms.parent')        
          ->get()
          ->toArray();
      }
        
      if(count($parentCategoryData) > 0)
      {
        foreach($parentCategoryData as $row)
        {
          //echo '<br/>cat:'.$row->term_id;
          $categoryData[]=$row->term_id;
          $this->getCategoryByParentHierarchy($row->parent, $categoryData);
         
        }
      }
    }

  }


  /**
   * Get function for getting all sub categories and parent categories id by product id.
   * 
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Created On : 28-Feb-2019
   *
   * @param productId, catType
   * @return array
   */
  public function getAllSubCategoriesAndParentCategoriesIdByProductId($productId = 0, $catType="product_cat")
  {
    $categiryDataByProductId = array();
    $allCategories = array();

    //$get_cat_array = array('term_id' => array(), 'term_details' => array());
    $categiryData   =  DB::table('terms')
                  ->where(['object_relationships.object_id' => $productId, 'terms.type' => 'product_cat' ])
                  ->join('object_relationships', 'object_relationships.term_id', '=', 'terms.term_id')
                  ->select('terms.term_id','terms.parent')        
                  ->get()
                  ->toArray();
     
    if(count($categiryData) > 0){
       
      foreach($categiryData as $row)
      {
        //echo '<br/>cat:'.$row->term_id;
        $allCategories[] = $row->term_id;

        // Calling this function to get all categrories by parent hierarchy
        $this->getCategoryByParentHierarchy($row->parent, $allCategories);
        
      }
    }
    // Sort array by key index in descending order.
    krsort($allCategories);

    // Re-index array starting to zero, simply do the following:
    $allCategories = array_values($allCategories);
    
    // Set Up Array of $finallAllCategoriesArray for Product edit Page to populate all four categories box i.e for large, middle, small and detail dyanmically with selected category for each.
    $finallAllCategoriesArray = array();
    if (isset($allCategories[0]) && $allCategories[0] > 0)
    {
        $selectedLargeCat =$allCategories[0];
        $allLargeCat =$this->getCategoriesByParentCatId(0);
        $finallAllCategoriesArray['large_cat'] = array(
            'selected'=>$selectedLargeCat,
            'all'=>$allLargeCat
        );
        
        $selectedMiddleCat =(isset($allCategories[1]) && $allCategories[1] > 0)? $allCategories[1] : '';
            
        $allMiddleCat =$this->getCategoriesByParentCatId($selectedLargeCat);
        $finallAllCategoriesArray['middle_cat'] = array(
          'selected'=>$selectedMiddleCat,
          'all'=>$allMiddleCat
        );
          
        if ($selectedMiddleCat > 0) 
        {
          $selectedSmallCat =(isset($allCategories[2]) && $allCategories[2] > 0)? $allCategories[2] : '';
          $allSmallCat =$this->getCategoriesByParentCatId($selectedMiddleCat);
          $finallAllCategoriesArray['small_cat'] = array(
            'selected'=>$selectedSmallCat,
            'all'=>$allSmallCat
          );

          if ($selectedSmallCat > 0) 
          {
            $selectedDetailCat =(isset($allCategories[3]) && $allCategories[3] > 0)? $allCategories[3] : '';
            
            $allDetailCat =$this->getCategoriesByParentCatId($selectedSmallCat);
            $finallAllCategoriesArray['detail_cat'] = array(
              'selected'=>$selectedDetailCat,
              'all'=>$allDetailCat
            );
          }
        }
    }

    return $finallAllCategoriesArray;
  }

 /**
   * Get function to fetch selected brand value by product id.
   * 
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Created On : 01-March-2019
   *
   * @param productId 
   * @return array
   */
  public function getSelectedBrandByObjectId($productId){
    $brandData = array();
    $getBrandDetail = DB::table('terms')
                        ->where(['object_relationships.object_id' => $productId, 'terms.type' => 'product_brands' ])
                        ->join('object_relationships', 'object_relationships.term_id', '=', 'terms.term_id')
                        ->select('terms.term_id','terms.name')        
                        ->get()
                        ->toArray();
     
    if(count($getBrandDetail) > 0)
    {
      foreach($getBrandDetail as $row)
      {
        $brandData['brand_id'] = $row->term_id;
        $brandData['brand_name'] = $row->name;
        /*$brandDetails = $this->getTermDataById( $row->term_id );
        if(count($brandDetails) > 0)
        {
          $brandData['brand_details'] = $brandDetails;
        }*/
      }
    }
    
    return $brandData;
  }
  
  /**
   * Get function for getting all categories list by parent category id for frontend user.
   * 
   * Created By : Ayushma Jain < ayushma.jain@gaurish.com >
   * Created On : 22-March-2019
   *
   * @param parentCatId, catType
   * @return array
   */
 public function getCategoriesByParentCatIdFrontendUser($parentCatId = 0, $catType="product_cat")
  {
    
    $getCategoriesData  =  Term::where(['type' => $catType, 'parent' => $parentCatId, 'status' => 1])->orderBy('name', 'asc')->get();
    
    $categories = array();

    if($getCategoriesData->count() > 0){
      foreach ($getCategoriesData as $mainCategory)
      {
        $category = array();
        $category['name']                  =  $mainCategory->name;
    $category['slug']                  =  $mainCategory->slug;
        $categories[$mainCategory->term_id] =  $category;   
      }
    }
    return $categories;
  } 
  
  /**
   * Function to check sale mode status for Products.
   * 
   * Created By : Ayushma Jain < ayushma.jain@gaurish.com >
   * Created On : 17-April-2019
   *
   * @param @product id
   * If It returns 0 then Product is not available otherwise it is avalible for users.
   */
 public function check_sale_mode($product_id = 0)
  {
	  
	 //Hide Product.
	 $sale_mode_status = 0;
	 $product_detail  = DB::table('products')
                                  ->where(['products.id'=>$product_id])
								  ->select(['sale_period_mode','sale_period_start_date','sale_period_end_date'])->get()->toArray();
						
							
	if($product_detail[0]->sale_period_mode == 'yes'){
	    // $sale_end_date = strtotime($product_detail[0]->sale_period_end_date);
	     //$sale_start_date = strtotime($product_detail[0]->sale_period_start_date);
		 //$current_date = strtotime(date('Y-m-d'));
		 
		 if($product_detail[0]->sale_period_start_date != '0000-00-00' && !empty($product_detail[0]->sale_period_start_date) && $product_detail[0]->sale_period_end_date!='0000-00-00' && !empty($product_detail[0]->sale_period_end_date) && (strtotime($product_detail[0]->sale_period_start_date) <= strtotime(date('Y-m-d'))) && ( strtotime($product_detail[0]->sale_period_end_date) >= strtotime(date('Y-m-d'))))
		{
			$sale_mode_status = 1;
		}
		
		
	}else{
		$sale_mode_status = 1;
	}
	return $sale_mode_status;
  } 
   /**
   * Function to check manage stock for Products.
   * 
   * Created By : Ayushma Jain < ayushma.jain@gaurish.com >
   * Created On : 17-April-2019
   *
   * @param @product id
   * If It returns 0 then Product is not available otherwise it is avalible for users.
   */
 public function check_manage_stock($product_id = 0)
  {
	  $option_array = array();
	 //Hide Product.
	
	 $is_stock_status = 0;
	 $quantity =0;
	 $product_detail  = DB::table('products')
                                  ->where(['products.id'=>$product_id])
								  ->select(['manage_stock','stock_qty','stock_qty_default','stock_availability'])->get()->toArray();
	if($product_detail[0]->manage_stock == 'yes'){ 
	    $product_options = DB::table('product_extras')
                       ->where(['product_id'=>$product_id,'key_name'=>'_product_section_data_options_json'])
					   ->select(['key_value'])->get()->toArray();
					   
	if(isset($product_options[0]->key_value)){			   
	  $option_array = convert_json_string_to_array($product_options[0]->key_value);
	}
		
	  if(!empty($option_array['requiredOptions'])){
		  $quantity = $product_detail[0]->stock_qty;
		   
	  }else{
		   $quantity = $product_detail[0]->stock_qty_default;
	  }
	 
	  if($quantity <= 0){
		  if($product_detail[0]->stock_availability != 'hidden'){
			$is_stock_status = 1;
		  }
	  }else{
		  if($product_detail[0]->stock_availability != 'hidden'){
			$is_stock_status = 1;
		}
	  }
	}else{
		if($product_detail[0]->stock_availability != 'hidden'){
			$is_stock_status = 1;
		}
	} 
	return $is_stock_status;
  } 
 

  /**
   * Function to change products availability status values.
   * 
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Created On : 22-April-2019
   *
   * @param productId 
   * @return array
   */
  public function changeProductStatus($product_id = 0)
  {
    // Set up function $actionStatus with default 0, if undfined.
    $actionStatus = 0;
    $productStockAvailabilitySelected = '';
    $arrayProductStatus = array("in_stock","out_of_stock","hidden");
    $productId=$product_id;
    if( Request::isMethod('post') && Session::token() == Input::get('_token') )
    {

      if(Input::has('pid') && is_numeric(Input::get('pid')))
      {
        $productId = Input::get('pid');
      }

      if(Input::has('productStatusSelected') && Input::get('productStatusSelected') !='')
      {
        $productStockAvailabilitySelected = Input::get('productStatusSelected');
      }

      
      if ($productId > 0 && in_array($productStockAvailabilitySelected, $arrayProductStatus))
      {
        // Calling this function to get prduct data by id.
        $get_product_data = $this->getProductDataById($productId);
        
        $option_data = (isset($get_product_data['_product_section_data_options_json'])) ? $get_product_data['_product_section_data_options_json'] : '';
        $option_array = convert_json_string_to_array($option_data);

        $onSaleCount = 0; $outOfStockCount = 0; $hiddenCount = 0;  $requiredOptionsCount = count($option_array['requiredOptions']);          
        if(isset($option_array['requiredOptions']) && $requiredOptionsCount>0)
        {
          foreach ($option_array['requiredOptions'] as $reqOption) 
          {
             if (isset($reqOption['sale_mode']) && $reqOption['sale_mode'] == 'on_sale') 
             {
                $onSaleCount++;
             } else if(isset($reqOption['sale_mode']) && $reqOption['sale_mode'] == 'out_of_stock')
             {
                $outOfStockCount++;
             } else if(isset($reqOption['sale_mode']) && $reqOption['sale_mode'] == 'hidden')
             {
                $hiddenCount++;
             }
          }
          $quantity = (isset($get_product_data['post_stock_qty'])) ? $get_product_data['post_stock_qty'] : 0;
        }else{
          $quantity = (isset($get_product_data['stock_qty_default'])) ? $get_product_data['stock_qty_default'] : 0;
        }
        
        $oldStockAvailability = (isset($get_product_data['post_stock_availability'])) ? $get_product_data['post_stock_availability'] : '';
        $manage_stock = (isset($get_product_data['manage_stock'])) ? $get_product_data['manage_stock'] : '';
         
        $finalStockAvailability = $oldStockAvailability;
        if ($productStockAvailabilitySelected == 'in_stock')
        {
          if (($manage_stock == 'yes' && $quantity > 0) || $manage_stock == 'no')
          {
            if($requiredOptionsCount > 0 && $onSaleCount == 0)
            {
              $finalStockAvailability = $oldStockAvailability;
              $actionStatus = 3;
            } else {
              //onsale
              $finalStockAvailability = 'in_stock';
              $actionStatus = 1;
            }  
           
          } else
          {
            $finalStockAvailability = $oldStockAvailability;
            $actionStatus = 2;
          }
        } else if ($productStockAvailabilitySelected == 'out_of_stock' || $productStockAvailabilitySelected == 'hidden'){
          $finalStockAvailability = $productStockAvailabilitySelected;
          $actionStatus = 1;
        }
       
        if ($actionStatus == 1) 
        {
          $data = array(
            'stock_availability'            =>  $finalStockAvailability
          );
     
          if(Product::where('id', $productId)->update($data))
          {
            $actionStatus = 1;
          } else
          {
            $actionStatus = 0;
            $finalStockAvailability = $oldStockAvailability;
          }
        }
      }
    }
    print_r(json_encode(array('status'=>$actionStatus, 'stockAvailability'=>$finalStockAvailability, 'quantity'=>number_format($quantity))));
  } 

  
  /**
   * Function to delete selected products itme from products list view page. 
   * 
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Created On : 23-April-2019
   *
   * @param productId 
   * @return array
   */
  public function deleteSelectedProductById($product_id = 0)
  {
    // Set up function $actionStatus with default 0, if undfined.
    $actionStatus = 0;
     
    // if you got valid request, do this.  
    if( Request::isMethod('post') && Session::token() == Input::get('_token') )
    {
      if (Input::has('pids') && Input::get('pids') !='' && Input::get('pids') !='0')
      { 
        
        $post_author_id = 0;
        if((is_vendor_login() || is_admin_login()) 
         && (Session::has('shopist_admin_user_id') && is_numeric(Session::get('shopist_admin_user_id')))
         ){
            $post_author_id = Session::get('shopist_admin_user_id');
        }

        $stringOfProductIds = Input::get('pids');
        $arrayOfProductIds = explode(",",$stringOfProductIds);
        if (count($arrayOfProductIds) > 0) 
        {
          // Archiving (Inactive or hide) selected products from product list view page.
          DB::table('products')->whereIn('id', $arrayOfProductIds)->where('author_id', $post_author_id)->update(array('status' => 0));
          $actionStatus = 1;
        }
      }
    }
    print_r(json_encode(array('status'=>$actionStatus)));
  } 

  /**
   * Function to get defualt shipping information of seller to show on add/edit product info page.
   * 
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Created On : 23-April-2019
   *
   * @param productId 
   * @return array
   */
  public function getSellerDefaultShippingInfo($field="")
  {
    // Set up function $shippingDataArray with default empty, if undfined.
    $shippingDataArray = array();
   
    // if you got valid request, do this.  
    if($field == 'return_shipping_data' || (Request::isMethod('post') && Session::token() == Input::get('_token')))
    {
      $post_author_id = 0;
      if((is_vendor_login() || is_admin_login()) 
       && (Session::has('shopist_admin_user_id') && is_numeric(Session::get('shopist_admin_user_id')))
       ){
          $post_author_id = Session::get('shopist_admin_user_id');
      }
      if ($post_author_id > 0) 
      {
        $fieldName = 'shipping_method';
        if ($field == 'return_shipping_data'){
          $fieldName = 'return_shipping_data';
        } 
        // Get logged in seller information
        $sellerDetails = DB::table('users_details')->where('user_id', $post_author_id)->select('details')->first();

        if (isset($sellerDetails->details)) 
        {
          // Convert JSON string to Array
          $allDetails = convert_json_string_to_array($sellerDetails->details);
          $shippingData =  isset($allDetails[$fieldName]) ? $allDetails[$fieldName] : '';
          $shippingDataArray = convert_json_string_to_array($shippingData);
        }
       
      }
    }
    if ($field == 'return_shipping_data')
    {
       return $shippingDataArray;
    } else {
       print_r(json_encode(array($shippingDataArray)));
    }
   
  } 

  /**
   * Function to get PMG Store Products.
   * 
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Created On : 08-May-2019
   *
   * @return array
   */
  public function pmgStoreProducts()
  {
    $post_author_id = 1;
    // Get PMG Store products id of first 5 products.
    $productIdsData = DB::table('pmgstore_products')->where('author_id', $post_author_id)
                      ->orderBy('intPosition', 'asc')->select('product_id')->take(5)->get(); 

    $productIds = array(0);
    if (count($productIdsData) > 0){
      foreach ($productIdsData as $row) 
      {
        $productIds[] = (isset($row->product_id) && is_numeric($row->product_id)) ? $row->product_id : 0;
      }
    }
    $productIdsString = implode(",", $productIds);

    // Calling this function to get all active and in stock products of PMG master admin.
    $pmgStoreProducts = $this->getProductListViewPageData(false, null, 1, $post_author_id,0,'all', $productIdsString, 'pmgstoreFrontEnd');

    return $pmgStoreProducts;

  }

  
  
  /**
   * Function to get PMG Store Products.
   * 
   * Created By : Ayushma Jain < ayushma.jain@gaurish.com >
   * Created On : 08-May-2019
   *
   * @return array
   */
	public function getParentsCategoryUsingProductId($product_id = '')
	{		
		
		$categoryNamesArray =array();
		$is_term_object_exist = ObjectRelationship::where('object_id', $product_id)->where('terms.type', 'product_cat')->join('terms',function($join){
                $join->on("terms.term_id","=","object_relationships.term_id");
              })->select('terms.term_id', 'terms.parent')->get();
          
        if(isset($is_term_object_exist) && count($is_term_object_exist)>0)
        {
			$last_updated_term_id = isset($is_term_object_exist[0]->term_id) ? $is_term_object_exist[0]->term_id : 0;
			 $parentID= isset($is_term_object_exist[0]->parent) ? $is_term_object_exist[0]->parent: 0;
			 
			 $allActiveCategories = $this->getAllActiveCategories(1);
			$categoryNamesArray  = $this->getParentsDataByCategoryId($last_updated_term_id,$parentID, 'term_id', $allActiveCategories);
			
		}
			
		return $categoryNamesArray;
	}

}

