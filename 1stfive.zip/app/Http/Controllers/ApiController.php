<?php
namespace shopist\Http\Controllers;

use shopist\Http\Controllers\Controller;
use Request;
use Session;
use Validator;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Lang;
use shopist\Models\Post;
use shopist\Models\PostExtra;
use shopist\Models\ObjectRelationship;
use Illuminate\Support\Facades\DB;
use shopist\Http\Controllers\ProductsController;
use shopist\Models\Term;
use shopist\Library\CommonFunction;
use shopist\Models\TermExtra;
use shopist\Models\Option;
use shopist\Models\UsersDetail;

class ApiController extends Controller
{
  /**
   * 
   * Page add content
   *
   * @param null
   * @return response view
   */
  public function openAddressSearchPopup(){
		$data = array();
		return view('pages.common.jusoPopup', $data);
  }
  public function openShippingTrackingStatus()
  {
		$courier_code=$_GET['code'];
		$tracking_id=$_GET['track_id'];
		$data['key']="39xNc768KXVXgqdxkaeXVA";//API KEY
		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, "https://info.sweettracker.co.kr/api/v1/trackingInfo?t_key=39xNc768KXVXgqdxkaeXVA&t_code=$courier_code&t_invoice=$tracking_id"); 
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));   
		$output = curl_exec($ch);
		curl_close($ch);
		$data['response']=json_decode($output);
		return view('pages.common.trackingStatusPopup', $data);
  }

  /**
   * Get Status Product Certification Number by using Safety Korea Open API.
   * Created On : 16-03-2019
   * Created By : Deepak Goswami
   */
  public function getCertificationNumberStatusBySafetyKoreaOpenAPI()
  {
  	$data['status_code'] = '0';
  	$data['status_message'] = 'Invalid Certification Number';
	$certicationNumber=$_POST['certicationNumber'];
	//$data['key']="950db004-2880-425f-9b8c-4c871b8d689e";//PMG KEY for Safety API
	$ch = curl_init();

	//curl_setopt($ch, CURLOPT_URL, "http://www.safetykorea.kr/openapi/api/recall/recallList.json?conditionKey=certNum&conditionValue=HM07003-18092"); 
	curl_setopt($ch, CURLOPT_URL, "http://www.safetykorea.kr/openapi/api/cert/certificationList.json?conditionKey=certNum&conditionValue={$certicationNumber}"); 

	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 

	//curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));   
	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
		'Content-Type: application/json',
		'AuthKey: 950db004-2880-425f-9b8c-4c871b8d689e'
	));
	$output = curl_exec($ch);
	curl_close($ch);
	$response=json_decode($output);
	
	// Validating the response of certifcation check API for a Certification number is correct or not.
	if ((isset($response->resultCode) && $response->resultCode == '2000')
		&& (isset($response->resultMsg) && $response->resultMsg == 'Success')
		&& (isset($response->resultData) && count($response->resultData) > 0)
 	){
		$data['status_code'] = '1';
  		$data['status_message'] = 'Success';
	}
 	print_r(json_encode($data));
  } 

	public function generateSettlement()
	{
		//May 15 settlment for April 28 ~ May 12,
		//May 30 settlement for May 13 ~ May 27.
		$day = date('d');
		if($day <= 15)
		{
			$start_date=date('Y-m-28',strtotime("-1 month"));
			$end_date=date('Y-m-12');
			$settlement_date = date('Y-m-15');
		}
		else
		{
			$start_date=date('Y-m-13');
			$end_date=date('Y-m-27');
			$settlement_date = date('Y-m-t');
		}
		//echo $start_date.' '.$end_date.' '.$settlement_date;
		//Get all seller
		$result = DB::table('users')->where('vendor_type','!=','')->select(DB::raw('group_concat(id) as id'))->get()->toArray();
		if(isset($result[0]->id))
		{
			$categories_fee = $this->getAllCategoryFee();
			$seller=explode(',',$result[0]->id);
			//print_r($seller);
			foreach($seller as $vendor)
			{
				//select all vendor's order from 
				$order_data = DB::table('order_detail')->where(['seller_id'=>$vendor,'status'=>'Completed'])->where('delivery_date','>=',$start_date)->where('delivery_date','<=',$end_date)->get()->toArray();
				//print_r($order_data);
				if(count($order_data)>0)
				{
					foreach($order_data as $order)
					{
						$product_detail=json_decode($order->product_detail);
						$total_sales_amount = $order->total_pay_amt;
						$total_point_deduction = $order->pointGain;
						$total_tax = 0;
						if(isset($product_detail->taxable) && $product_detail->taxable =='yes')
						{
							$total_tax = round(($order->product_pay_amt*9.09)/100);
						}
						$total_supply_value = $order->total_pay_amt-$total_tax;
						$total_fee = 0;
						
						//Get product category id
						$is_term_object_exist = ObjectRelationship::where('object_id', $order->product_id)->where('terms.type', 'product_cat')->join('terms',function($join){
							$join->on("terms.term_id","=","object_relationships.term_id");
						})->select('terms.term_id', 'terms.parent')->get();
						if(count($is_term_object_exist)>0)
						{
							$last_updated_term_id = isset($is_term_object_exist[0]->term_id) ? $is_term_object_exist[0]->term_id : 0;
							$parentID= isset($is_term_object_exist[0]->parent) ? $is_term_object_exist[0]->parent: 0;
						}
						//echo $last_updated_term_id." ".$parentID;
						if(isset($categories_fee[$last_updated_term_id]))
						{
							if($categories_fee[$last_updated_term_id]->category_price_type=='fixed')
							{
								$total_fee = $categories_fee[$last_updated_term_id]->category_price;
							}
							else
							{
								$total_fee = round(($total_supply_value*$categories_fee[$last_updated_term_id]->category_price)/100); 
							}
						}
						if(isset($categories_fee[$parentID]))
						{
							if($categories_fee[$parentID]->category_price_type=='fixed')
							{
								$total_fee = $categories_fee[$parentID]->category_price;
							}
							else
							{
								$total_fee = round(($total_supply_value*$categories_fee[$parentID]->category_price)/100); 
							}
						}
						//echo $total_fee;
						$checkSettlement = DB::table('settlement')->where(['seller_id' => $vendor,'settlement_period' => $settlement_date])->first(['id','order_ids']);
						if(!empty($checkSettlement))
						{
							//update existing settlement records
							$settlement_id = $checkSettlement->id;
							$settlement_orderIds = explode(',',$checkSettlement->order_ids);
							if(!in_array($order->id,$settlement_orderIds))
							{
								array_push($settlement_orderIds,$order->id);
								DB::table('settlement')->where(['id' => $settlement_id])->update(
									['order_ids' => implode(',',$settlement_orderIds),'total_sales_amount' => DB::raw("total_sales_amount + $total_sales_amount"),'total_point_deduction' => DB::raw("total_point_deduction + $total_point_deduction"),'total_fee_charge' => DB::raw("total_fee_charge + $total_fee"),'total_supply_value' => DB::raw("total_supply_value + $total_supply_value"),'total_tax' => DB::raw("total_tax + $total_tax"),'updated_at' => DB::raw('now()')]
								);
							}
							
						}
						else
						{
							//Insert new records
							DB::table('settlement')->insert(
								['seller_id' => $vendor, 'order_ids' => $order->id,'total_sales_amount' => $total_sales_amount,'total_point_deduction' => $total_point_deduction,'total_fee_charge' => $total_fee,'total_supply_value' => $total_supply_value,'total_tax' => $total_tax,'settlement_period' => $settlement_date,'settlement_status' => 'pending','created_at' => DB::raw('now()')]
							);
						}
					}
				}
			}
		}
	}
	public function getAllCategoryFee()
	{
		$category=array();
		//Get all category charges
		$result = DB::table('terms')->where('category_price','>',0)->select('term_id','category_price_type','category_price')->get()->toArray();
		if(count($result)>0)
		{
			foreach($result as $row)
			{
				$category[$row->term_id]=$row;
			}
		}
		return $category;
	}
  
}