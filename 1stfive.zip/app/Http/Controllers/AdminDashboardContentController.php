<?php
namespace shopist\Http\Controllers;

use shopist\Http\Controllers\Controller;
use shopist\Library\CommonFunction;
use shopist\Models\Product;
use shopist\Models\Post;
use shopist\Models\User;
use shopist\Models\PostExtra;  
use shopist\Models\IntruptedUser;
use Carbon\Carbon;
use Session;
use Validator;
use Request;
use shopist\Models\UserActionLogs;
use shopist\Http\Controllers\VendorsController;
use shopist\Http\Controllers\Admin\UserController;
use shopist\Http\Controllers\OrderController;
use shopist\Models\ObjectRelationship;
use Illuminate\Support\Facades\Lang;
use Illuminate\Support\Facades\Input;
use Intervention\Image\Facades\Image;
use shopist\Library\GetFunction;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\DB;
use shopist\Models\VendorPackage;
use shopist\Models\FaqSearch;
use shopist\Models\UsersDetail;
use shopist\Models\NoticeMgmt;
use shopist\Models\Consultation;
use Excel;
use shopist\Http\Controllers\ProductsController;

class AdminDashboardContentController extends Controller{
  public $carbonObject;
  public $vendors;
  public $users;
  public $classGetFunction;
  public $env;
  public $products;
  
  public function __construct(){
    $this->carbonObject = new Carbon();
    $this->vendors  = new VendorsController();
    $this->user  = new UserController();
    $this->order  = new OrderController();
    $this->classGetFunction  =  new GetFunction();
    $this->env = App::environment();
    $this->products = new ProductsController();
  }
  /**
  * admin dashboard content
  *
  * @param null
  * @return response view
  */
  public function dashboardContent(){
    $data = array();
    $dashboard             = array();
    $last2DaysData         = array();
    $last2DaysProductsData = array();
    $todaysTotal           = 0;
    
    $common_obj  = new CommonFunction();
    $data = $common_obj->commonDataForAllPages();

	$DepositCount = $this->order->getOrderCount(Session::get('shopist_admin_user_id'),'Deposit');
	$WaitDepositCount = $this->order->getOrderCount(Session::get('shopist_admin_user_id'),'WaitDeposit');
	$data['totalOrderCount'] =  $DepositCount + $WaitDepositCount;
	$data['ShippedCount']=$this->order->getOrderCount(Session::get('shopist_admin_user_id'),'Shipped');
	$data['DeliveredCount']=$this->order->getOrderCount(Session::get('shopist_admin_user_id'),'Delivered');
	$data['CancelCount']=$this->order->getOrderCount(Session::get('shopist_admin_user_id'),'CancelComplete');
	$data['ReturnCount']=$this->order->getOrderCount(Session::get('shopist_admin_user_id'),'ReturnComplete');
	$data['ExchangeCount']=$this->order->getOrderCount(Session::get('shopist_admin_user_id'),'ExchangeComplete');
		
	$data['settlement_data'] = $this->generateSettlement();
	
	if(is_vendor_login() && Session::has('shopist_admin_user_id')){
		
		
		$data['SellerActiveAds']  = DB::table('adv_request')
								->where('seller_id',Session::get('shopist_admin_user_id'))
								->whereIn('status', array('Approved','Running'))
								->where('start_date','<=',date('Y-m-d'))
								->where('end_date','>=',date('Y-m-d'))->select('adv_request.*')->get()->toArray();
								
		
		
		
	}else{
		$data['total_ad_request'] = DB::table('adv_request')->count();
		$data['total_running_ads'] = DB::table('adv_request')->whereIn('status' , array('Approved','Running'))->count();
		$data['total_new_request_ads'] = DB::table('adv_request')->whereIn('status' , array('WaitApproved'))->count();
		$data['total_blank_ads'] = $this->getTotalBlankAdsCount();
		
		
		$data['VBANK__fee'] = DB::table('pg_charges')->where('payment_method','VBANK')->ORDERBY('start_date','DESC')->select(['charge_type','charge_amount'])->first();
		$data['CELLPHONE__fee'] = DB::table('pg_char4ges')->where('payment_method','CELLPHONE')->ORDERBY('start_date','DESC')->select(['charge_type','charge_amount'])->first();
		$data['BANK__fee'] = DB::table('pg_charges')->where('payment_method','BANK')->ORDERBY('start_date','DESC')->select(['charge_type','charge_amount'])->first();
		$data['CARD__fee'] = DB::table('pg_charges')->where('payment_method','CARD')->ORDERBY('start_date','DESC')->select(['charge_type','charge_amount'])->first();
		
		$data['allUsers'] = DB::table('users')
							->join('role_user','users.id','=','role_user.user_id')
							->join('roles', function($join)
							 {
							   $join->on('roles.id', '=', 'role_user.role_id');
								 $join->where('roles.role_name' ,'Site User');
							 })
							->select('users.*')->get()->toArray();
						
		$data['allSellers'] = DB::table('users')
							->join('role_user','users.id','=','role_user.user_id')
							->join('roles', function($join)
							 {
							   $join->on('roles.id', '=', 'role_user.role_id');
								 $join->where('roles.role_name' ,'Vendor');
							 })
							->select('users.*')->get()->toArray();
					
		$data['total_deposit_settlement'] = DB::table('settlement')->where(['settlement_status'=>'deposit' ])->count();
		
		$data['total_tax_invoice_settlement'] = DB::table('settlement')->where(['settlement_status'=>'waitApprove'])->count();
		
		$data['total_completed_settlement'] = DB::table('settlement')->where(['settlement_status'=>'approved'])->count();
		
		$data['total_running_settlement'] = DB::table('settlement')->where(['settlement_status'=>'schedule'])->count();
		
		
	
	}

   /* if(is_vendor_login() && Session::has('shopist_admin_user_id')){
       $totalProducts = Product::where(['author_id' => Session::get('shopist_admin_user_id')])->get();
    }
    else{
      $totalProducts = Product::get();
    }

    if(is_vendor_login() && Session::has('shopist_admin_user_id')){
      $todayOrders  =  DB::table('posts')
                       ->whereDate('posts.created_at', '=', $this->carbonObject->today()->toDateString())
                       ->where(['posts.post_type' => 'shop_order', 'posts.parent_id' => 0, 'vendor_orders.vendor_id' => Session::get('shopist_admin_user_id')])
                       ->join('vendor_orders', 'posts.id', '=', 'vendor_orders.order_id')
                       ->select('posts.*') 
                       ->get();
    }
    else{
      $todayOrders  =  Post::whereDate('created_at', '=', $this->carbonObject->today()->toDateString())
                       ->where(['post_type' => 'shop_order', 'parent_id' => 0])
                       ->get();
    }

    if(is_vendor_login() && Session::has('shopist_admin_user_id')){
      $totalOrders  =  DB::table('posts')
                       ->where(['posts.post_type' => 'shop_order', 'posts.parent_id' => 0, 'vendor_orders.vendor_id' => Session::get('shopist_admin_user_id')])
                       ->join('vendor_orders', 'posts.id', '=', 'vendor_orders.order_id')
                       ->select('posts.*') 
                       ->get();
    }
    else{
      $totalOrders  =  Post::where(['post_type' => 'shop_order', 'parent_id' => 0])
                       ->get();
    }

    if(is_vendor_login() && Session::has('shopist_admin_user_id')){
      $last2DaysOrders  =  DB::table('posts')
                           ->whereBetween('posts.created_at', array($this->carbonObject->yesterday()->toDateString(), $this->carbonObject->today()->toDateString().' 23:59:59')) 
                           ->where(['posts.post_type' => 'shop_order', 'posts.parent_id' => 0, 'vendor_orders.vendor_id' => Session::get('shopist_admin_user_id')])
                           ->join('vendor_orders', 'posts.id', '=', 'vendor_orders.order_id')
                           ->select('posts.*') 
                           ->orderBy('posts.created_at', 'DESC')
                           ->get();
    }
    else{
      $last2DaysOrders  =  Post::whereBetween('created_at', array($this->carbonObject->yesterday()->toDateString(), $this->carbonObject->today()->toDateString().' 23:59:59'))
                           ->where(['post_type' => 'shop_order', 'parent_id' => 0])
                           ->orderBy('created_at', 'DESC')
                           ->get();
    }

    if(is_vendor_login() && Session::has('shopist_admin_user_id')){
      $lastProducts  =  DB::table('products')
                        ->whereBetween('created_at', array($this->carbonObject->yesterday()->toDateString(), $this->carbonObject->today()->toDateString().' 23:59:59'))
                        ->where(['author_id' => Session::get('shopist_admin_user_id')])
                        ->orderBy('created_at', 'DESC')
                        ->take(5)
                        ->get();
    }
    else{
      $lastProducts  =  Product::whereBetween('created_at', array($this->carbonObject->yesterday()->toDateString(), $this->carbonObject->today()->toDateString().' 23:59:59'))
                        ->orderBy('created_at', 'DESC')
                        ->take(5)
                        ->get();
    }


    if($totalProducts && $totalProducts->count() > 0){
      $dashboard['total_products'] = $totalProducts->count();
    }
    else{
      $dashboard['total_products'] = 0;
    }

    if($todayOrders && $todayOrders->count() > 0){
      $dashboard['today_orders'] = $todayOrders->count();

      foreach($todayOrders as $rows){
        $get_order_total = PostExtra::where(['post_id' => $rows->id, 'key_name' => '_order_total'])->first();

        if(!empty($get_order_total->key_value)){
          $todaysTotal += $get_order_total->key_value;
        }
      }
      $dashboard['today_totals_sales'] = $todaysTotal;
    }
    else{
      $dashboard['today_orders'] = 0;
      $dashboard['today_totals_sales'] = $todaysTotal;
    }

    if($totalOrders && $totalOrders->count() > 0){
      $dashboard['total_orders'] = $totalOrders->count();
    }
    else{
      $dashboard['total_orders'] = 0;
    }

    if($last2DaysOrders && $last2DaysOrders->count() > 0){
      foreach($last2DaysOrders as $rows){
        $order_data = array();
        $order_data['order_id']       =   $rows->id;
        $order_data['order_date']     =   $this->carbonObject->parse($rows->created_at)->toDayDateTimeString();

        $order_status                 =   PostExtra::where(['post_id' => $rows->id, 'key_name' => '_order_status'])->first();
        if(!empty($order_status->key_value)){
          $order_data['order_status'] =   $order_status->key_value;
        }

        $order_total                  =   PostExtra::where(['post_id' => $rows->id, 'key_name' => '_order_total'])->first();
        if(!empty($order_total->key_value)){
          $order_data['order_totals'] =   $order_total->key_value;
        }
        else{
          $order_data['order_totals'] =   0;
        }

        $order_currency               =   PostExtra::where(['post_id' => $rows->id, 'key_name' => '_order_currency'])->first();
        if(!empty($order_currency->key_value)){
          $order_data['order_currency'] =   $order_currency->key_value;
        }

        array_push($last2DaysData, $order_data);
      }

      $dashboard['latest_orders'] = $last2DaysData;
    }
    else{
    $dashboard['latest_orders'] = array();
    }

    if($lastProducts && $lastProducts->count() > 0){
      foreach($lastProducts as $rows){
        $products_data = array();
        $products_data['id'] = $rows->id;

        if(!empty(get_product_image($rows->id))){
          $products_data['img_url'] =  get_product_image($rows->id);
        }
        else{
          $products_data['img_url'] = '';
        }

        $products_data['title'] = $rows->title;
        $products_data['price'] = get_product_price( $rows->id );
        $products_data['description'] = $rows->content;

        array_push($last2DaysProductsData, $products_data);
      }

      $dashboard['latest_products'] = $last2DaysProductsData;
    }
    else{
      $dashboard['latest_products'] = array();
    }

    $all_vendors			 =  $this->vendors->getAllVendors( false, null, -1);
    $active_vendors		 =  $this->vendors->getAllVendors( false, null, 1 );
    $pending_vendors   =  $this->vendors->getAllVendors( false, null, 0 );

    $dashboard['total_vendors']			= count($all_vendors);
    $dashboard['active_vendors']		= count($active_vendors);
    $dashboard['pending_vendors']   = count($pending_vendors);

    $dashboard['total_completed'] = count($this->vendors->getVendorWithdrawRequestDataAll('COMPLETED'));
    $dashboard['total_cancelled'] = count($this->vendors->getVendorWithdrawRequestDataAll('CANCELLED'));
    $dashboard['total_pending']   = count($this->vendors->getVendorWithdrawRequestDataAll('ON_HOLD'));


    $dashboard['dashbord_announcement']	 =  $this->vendors->getTopThreeVendorAnnouncementByVendorId( Session::get('shopist_admin_user_id') );

    //overview chart
    $start_date   =  date('Y-m-01');
    $current_date =  date('Y-m-d');

    $dashboard['overview_reports'] =  $this->vendors->getVendorReportsDataForDay(array('target' => 'day', 'start_date'=> $start_date, 'current_date' => $current_date));
    $dashboard['overview_reports_log'] =  $this->vendors->getVendorReportsDayLog(array('target' => 'day', 'start_date'=> $start_date, 'current_date' => $current_date));

    $order_total = 0;
    $total_earning = 0;
    if(count($dashboard['overview_reports_log']) > 0){
      foreach($dashboard['overview_reports_log'] as $report){
        $order_total += $report->order_total;
        $total_earning += ((float)$report->order_total - (float)$report->net_amount);
      }
    }

    $dashboard['overview_reports_total_details'] = array('number_of_order' => $dashboard['overview_reports_log']->count(), 'order_total' => price_html($order_total), 'total_earning' => price_html($total_earning));
    //overview chart end

    $data['dashboard_data'] = $dashboard;*/

    return view('pages.admin.dashboard-content', $data);
  }
  

  /**
   * 
   * Manage quick mail
   *
   * @param null
   * @return void
   */
  public function sendQuickMail(){
    if( Request::isMethod('post') && Session::token() == Input::get('_token') ){
      $input = Input::all();
      $rules = [
       'quickemailto'                  =>  'required',
       'quickmailsubject'              =>  'required',
       'quickmailbody'                 =>  'required',
     ];

     $validator = Validator:: make($input, $rules);

     if($validator->fails()){
      return redirect()-> back()
      ->withInput()
      ->withErrors( $validator );
    }
    else{
      $mailData = array();

        //load mailData Array
      $mailData['source']  =  'quick_mail';
      $mailData['data']    =   array('_mail_to' => Input::get('quickemailto'), '_subject' => Input::get('quickmailsubject'), '_message' => Input::get('quickmailbody'));

      if($this->env === 'production'){
        $this->classGetFunction->sendCustomMail( $mailData );
        Session::flash('success-message', Lang::get('admin.mail_sent_msg'));
      }

      return redirect()->back();
    }
  }
  else {
    return redirect()-> back();
  }
}
public function customerInquiry(){
  $data = array();
  $common_obj  = new CommonFunction();
  $data = $common_obj->commonDataForAllPages();
  $per_page=(isset($_GET['perPage']))?$_GET['perPage']:5;
  $search_term=(isset($_GET['search_term']))?$_GET['search_term']:'';
  $type=(isset($_GET['type']))?$_GET['type']:'';

  if(!empty($search_term) && !empty($type))
  {
   $inquiry_list  = DB::table('support_ticket')
   ->join('users','users.id','=','support_ticket.user_id')
   ->join('products','products.id','=','support_ticket.product_id')
   ->where(['vendor_id' => Session::get('shopist_admin_user_id')])
   ->where(['support_ticket.type' => $type])
   ->where('ticket_name', 'LIKE', '%'.$search_term.'%')
   ->orWhere('ticket_content', 'LIKE', '%'.$search_term.'%')
   ->select('support_ticket.*','users.display_name','products.title')->paginate($per_page)->toArray();

   $data['data']  = array('mode'=>'search','total'=>count($inquiry_list['data']),'per_page'=>$per_page,'last_page'=>'','next_page'=>'');
   $data['inquiry_list']  = json_decode(json_encode($inquiry_list['data']), true);
 }
 else if(!empty($search_term))
 {
   $inquiry_list  = DB::table('support_ticket')
   ->join('users','users.id','=','support_ticket.user_id')
   ->join('products','products.id','=','support_ticket.product_id')
   ->where(['vendor_id' => Session::get('shopist_admin_user_id')])
   ->where('ticket_name', 'LIKE', '%'.$search_term.'%')
   ->orWhere('ticket_content', 'LIKE', '%'.$search_term.'%')
   ->select('support_ticket.*','users.display_name','products.title')->paginate($per_page)->toArray();

   $data['data']  = array('mode'=>'search','total'=>count($inquiry_list['data']),'per_page'=>$per_page,'last_page'=>'','next_page'=>'');
   $data['inquiry_list']  = json_decode(json_encode($inquiry_list['data']), true);
 }
 else if(!empty($type))
 {
   $inquiry_list  = DB::table('support_ticket')
   ->join('users','users.id','=','support_ticket.user_id')
   ->join('products','products.id','=','support_ticket.product_id')
   ->where(['vendor_id' => Session::get('shopist_admin_user_id')])
   ->where(['support_ticket.type' => $type])
   ->select('support_ticket.*','users.display_name','products.title')->paginate($per_page)->toArray();

   $data['data']  = array('mode'=>'','total'=>count($inquiry_list['data']),'per_page'=>$per_page,'last_page'=>'','next_page'=>'');
   $data['inquiry_list']  = json_decode(json_encode($inquiry_list['data']), true);
 }
 else
 {
   $inquiry_list  = DB::table('support_ticket')
   ->join('users','users.id','=','support_ticket.user_id')
   ->join('products','products.id','=','support_ticket.product_id')
   ->where(['vendor_id' => Session::get('shopist_admin_user_id')])
   ->select('support_ticket.*','users.display_name','products.title')
   ->paginate($per_page)->toArray();
   $data['data']  = $inquiry_list;
   $data['inquiry_list']  = json_decode(json_encode($inquiry_list['data']), true);
 }

 return view('pages.admin.customer.inquiry', $data);
}
public function saveInquiryReply()
{ 
  if( Request::isMethod('post') && Session::token() == Input::get('_token') ){
   $input = Input::all();
   DB::table('support_ticket')
   ->where(['id' => $input['_ticket_id']])->update(['ticket_response' => $input['ticket_response'],'status' => 'close','updated_at' => date('Y-m-d h:i:s')]);
   return redirect()-> route('admin.customerInquiry');
 }
}
public function productReview()
{
  $data = array();
  $common_obj  = new CommonFunction();
  $data = $common_obj->commonDataForAllPages();
  $data['review_list']  = array();
  $per_page=(isset($_GET['perPage']))?$_GET['perPage']:5;
  $search_term=(isset($_GET['search_term']))?$_GET['search_term']:'';
  $rate=(isset($_GET['type']))?$_GET['type']:'';
  if(!empty($search_term) && !empty($rate))
  {
   $review_list  = DB::table('comments')
   ->join('users','users.id','=','comments.user_id')
   ->join('products','products.id','=','comments.object_id')
   ->where(['products.author_id' => Session::get('shopist_admin_user_id')])
   ->where(['comments.rating'  => $rate])  
   ->where('comments.content', 'LIKE', '%'.$search_term.'%')  
   ->orWhere('products.title', 'LIKE', '%'.$search_term.'%') 
   ->select('comments.*','users.display_name','products.title','products.image_url')
   ->paginate($per_page)->toArray();
 }
 elseif(!empty($search_term))
 {
   $review_list  = DB::table('comments')
   ->join('users','users.id','=','comments.user_id')
   ->join('products','products.id','=','comments.object_id')
   ->where(['products.author_id' => Session::get('shopist_admin_user_id')])
   ->where(['comments.rating' => $rate])  
   ->where('comments.content', 'LIKE', '%'.$search_term.'%')  
   ->orWhere('products.title', 'LIKE', '%'.$search_term.'%') 
   ->select('comments.*','users.display_name','products.title','products.image_url')
   ->paginate($per_page)->toArray();
 }
 elseif(!empty($rate))
 {
   $review_list  = DB::table('comments')
   ->join('users','users.id','=','comments.user_id')
   ->join('products','products.id','=','comments.object_id')
   ->where(['products.author_id' => Session::get('shopist_admin_user_id')])
   ->where(['comments.rating'  => $rate])  
   ->select('comments.*','users.display_name','products.title','products.image_url')
   ->paginate($per_page)->toArray();
 }
 else
 {
   $review_list  = DB::table('comments')
   ->join('users','users.id','=','comments.user_id')
   ->join('products','products.id','=','comments.object_id')
   ->where(['products.author_id' => Session::get('shopist_admin_user_id')])
   ->select('comments.*','users.display_name','products.title','products.image_url')
   ->paginate($per_page)->toArray();
 }
 $data['data']  = $review_list;
 $data['search_term']  = $search_term;
 $data['review_list']  = json_decode(json_encode($review_list['data']), true);
 return view('pages.admin.customer.product_review', $data);
}
	/**
	* Function : Funttion to load Edit Settlement History page.
	* <ayushma.jain@gaurish.com>
	**/
	public function settlementHistory($type)
	{
		$data = array();
		$per_page = isset($_GET['per_page'])? $_GET['per_page'] : 10;
		$common_obj  = new CommonFunction();
		$data = $common_obj->commonDataForAllPages();
		$settlement_list  = DB::table('settlement')
   ->where(['seller_id' => Session::get('shopist_admin_user_id'),'settlement_status' => $type])
   ->paginate($per_page)->toArray();
   $data['settlement_list']=$settlement_list;
   $data['type']=$type;
   $data['per_page']=$per_page;
   return view('pages.admin.settlement.settlement_history', $data);
 }
	/**
	* Function : Funttion to load tax Invoice management.
	* <ayushma.jain@gaurish.com>
	**/
	public function taxInvoiceManagement()
	{
		$data = array();
		$common_obj  = new CommonFunction();
		$data = $common_obj->commonDataForAllPages();
		
		return view('pages.admin.settlement.tax_invoice', $data);
	}
	/**
	* Function : Funttion to load Edit sales declaration History.
	* <ayushma.jain@gaurish.com>
	**/
	public function salesDeclarationHistory()
	{
		$data = array();
		$common_obj  = new CommonFunction();
		$data = $common_obj->commonDataForAllPages();
		
		return view('pages.admin.settlement.sales_declaration', $data);
	}
	
	/**
	* Function : Funttion to load Edit seller Information page.
	* <ayushma.jain@gaurish.com>
	**/
	public function editSellerInformation()
	{
		$data = array();
		$vendor_details_array = array();
		$common_obj  = new CommonFunction();
		$data = $common_obj->commonDataForAllPages();
		$vendor_details = DB::table('users')->where(['users.id'=> Session::get('shopist_admin_user_id')])
   ->join('users_details','users.id','=','users_details.user_id')->select('users.*','users_details.*')->get()->toArray();
   $data['vendor_details'] = $vendor_details;
   $courier_code =  DB::table('courier_code')->select('*')->get()->toArray();
   $data['courier_code'] = $courier_code;
   $data['bank_name'] = DB::table('bank')->select('*')->get()->toArray();
   return view('pages.admin.seller.edit-seller-information', $data);
 }	

	/**
	* Function : Funttion to save OR upadte seller Information 
	* <ayushma.jain@gaurish.com>
	**/
	public function saveSellerInformation()
	{
		
		$data = array();
		$data = Input::all();
		$other_detail = $data;
		
		//Extend validator with own white spaces rules.
		Validator::extend('without_spaces', function($attr, $value){
			return preg_match('/^\S*$/u', $value);
		});
   $rules = [
     'email'       					    => 'required|email',
     'operator'                          => 'required|without_spaces|min:6|max:10'

   ];
   $messages = [
     'email.required' => Lang::get('validation.email_required'),
     'email.unique' => Lang::get('validation.email_unique'),
     'email.email' => Lang::get('validation.email_is_email'),
     'operator.required' => Lang::get('validation.vendor_id_min'),
     'operator.unique' => Lang::get('validation.vendor_name_unique'),
     'operator.min' => Lang::get('validation.vendor_id_min'),
     'operator.max' => Lang::get('validation.vendor_id_min'),
     'operator.without_spaces' => Lang::get('validation.vendor_id_min')
   ];
   $validator = Validator:: make($data, $rules, $messages);
   if($validator->fails()){
     return redirect()-> back()
     ->withInput()
     ->withErrors( $validator );
   } else{

    $is_user_name_exists = User::where(['name' => Input::get('operator')])->first();
    $is_email_exists     = User::where(['email' => Input::get('email')])->first();

    if($is_user_name_exists && $is_user_name_exists->id != Session::get('shopist_admin_user_id'))
    {
      Session::flash('user-name-error-message', '사용자 이름은 이미 가져갔다.');
      return redirect()->back();
    } 

    if($is_email_exists && $is_email_exists->id != Session::get('shopist_admin_user_id'))
    {
     Session::flash('email-error-message', '이메일 ID는 이미 가져갔다.');
     return redirect()->back();
   } 

   $data['vendor_settlement_contact_number1'] = (!empty($data['vendor_settlement_agent_tel_pin1']) && !empty($data['vendor_settlement_agent_tel_fnum1']) && !empty($data['vendor_settlement_agent_tel_lnum1'])) ? $data['vendor_settlement_agent_tel_pin1'].'-'.$data['vendor_settlement_agent_tel_fnum1'].'-'.$data['vendor_settlement_agent_tel_lnum1'] : '';

   $data['vendor_settlement_contact_number2'] = (!empty($data['vendor_reg_pin2']) && !empty($data['vendor_settlement_agent_tel_fnum2']) && !empty($data['vendor_settlement_agent_tel_lnum2'])) ? $data['vendor_reg_pin2'].'-'.$data['vendor_settlement_agent_tel_fnum2'].'-'.$data['vendor_settlement_agent_tel_lnum2'] : '';

   $data['vendor_fax_number'] = (!empty($data['vendor_reg_fax_pin1']) && !empty($data['vendor_reg_fax1']) && !empty($data['vendor_reg_fax2'])) ? $data['vendor_reg_fax_pin1'].'-'.$data['vendor_reg_fax1'].'-'.$data['vendor_reg_fax2']:'';


   $data['vendor_reg_contact_number1'] = (!empty($data['vendor_reg_pin1']) && !empty($data['vendor_reg_contact_first_number1']) && !empty($data['vendor_reg_contact_last_number1'])) ? $data['vendor_reg_pin1'].'-'.$data['vendor_reg_contact_first_number1'].'-'.$data['vendor_reg_contact_last_number1'] : '';

   $data['vendor_reg_contact_number2'] = (!empty($data['vendor_reg_pin2']) && !empty($data['vendor_reg_contact_first_number2']) && !empty($data['vendor_reg_contact_last_number2'])) ? $data['vendor_reg_pin2'].'-'.$data['vendor_reg_contact_first_number2'].'-'.$data['vendor_reg_contact_last_number2'] : '';

   $data['shipping_contact_number1'] = (!empty($data['shipping_contact_pin1']) && !empty($data['shipping_contact_first_number1']) && !empty($data['shipping_contact_last_number1'])) ? $data['shipping_contact_pin1'].'-'.$data['shipping_contact_first_number1'].'-'.$data['shipping_contact_last_number1'] : '';

   $data['shipping_contact_number2'] = (!empty($data['shipping_contact_pin2']) && !empty($data['shipping_contact_first_number2']) && !empty($data['shipping_contact_last_number2'])) ? $data['shipping_contact_pin2'].'-'.$data['shipping_contact_first_number2'].'-'.$data['shipping_contact_last_number2'] : '';

   $data['product_reg_contact1'] = (!empty($data['product_registration_pin1']) && !empty($data['product_registration_first_number1']) && !empty($data['product_registration_last_number1'])) ? $data['product_registration_pin1'].'-'.$data['product_registration_first_number1'].'-'.$data['product_registration_last_number1'] : '';

   $data['product_reg_contact2'] = (!empty($data['product_registration_pin2']) && !empty($data['product_registration_first_number2']) && !empty($data['product_registration_last_number2'])) ? $data['product_registration_pin2'].'-'.$data['product_registration_first_number2'].'-'.$data['product_registration_last_number2'] : '';

   $data['sales_person_contact1'] = (!empty($data['sales_person_pin1']) && !empty($data['sales_person_first_number1']) && !empty($data['sales_person_last_number1'])) ? $data['sales_person_pin1'].'-'.$data['sales_person_first_number1'].'-'.$data['sales_person_last_number1'] : '';

   $data['sales_person_contact2'] = (!empty($data['sales_person_pin2']) && !empty($data['sales_person_first_number2']) && !empty($data['sales_person_last_number2'])) ? $data['sales_person_pin2'].'-'.$data['sales_person_first_number2'].'-'.$data['sales_person_last_number2'] : '';

   $data['product_reg_contact2'] = (!empty($data['sales_person_pin2']) && !empty($data['sales_person_first_number2']) && !empty($data['sales_person_last_number2'])) ? $data['sales_person_pin2'].'-'.$data['sales_person_first_number2'].'-'.$data['sales_person_last_number2'] : '';

   $data['representative_contact1'] = (!empty($data['representative_pin1']) && !empty($data['representative_first_number1']) && !empty($data['representative_last_number1'])) ? $data['representative_pin1'].'-'.$data['representative_first_number1'].'-'.$data['representative_last_number1'] : '';

   $data['representative_contact2'] = (!empty($data['representative_pin2']) && !empty($data['representative_last_number2']) && !empty($data['representative_first_number2'])) ? $data['representative_pin2'].'-'.$data['representative_first_number2'].'-'.$data['representative_last_number2'] : '';

   $data['contact_1'] = (!empty($data['contact_1_1']) && !empty($data['contact_1_2']) && !empty($data['contact_1_3'])) ? $data['contact_1_1'].'-'.$data['contact_1_2'].'-'.$data['contact_1_3'] : '';

   $data['contact_2'] = (!empty($data['contact_2_1']) && !empty($data['contact_2_2']) && !empty($data['contact_2_3'])) ? $data['contact_2_1'].'-'.$data['contact_2_2'].'-'.$data['contact_2_3'] : '';

   $data['contact_3'] = (!empty($data['contact_3_1']) && !empty($data['contact_3_2']) && !empty($data['contact_3_3'])) ? $data['contact_3_1'].'-'.$data['contact_3_2'].'-'.$data['contact_3_3'] : '';

   $data['contact_4'] = (!empty($data['contact_4_1']) && !empty($data['contact_4_2']) && !empty($data['contact_4_3'])) ? $data['contact_4_1'].'-'.$data['contact_4_2'].'-'.$data['contact_4_3'] : '';

   $sms_email_recieving_status = isset($data['sms_email_recieving_status'])? $data['sms_email_recieving_status'] :'';

   $cs_center_contact1 = isset($data['cs_center_contact1'])? $data['cs_center_contact1'] :'';

   $cs_center_contact2 = isset($data['cs_center_contact2'])? $data['cs_center_contact2'] :'';

   $cs_center_contact3 = isset($data['cs_center_contact3'])? $data['cs_center_contact3'] :'';

   $cs_center_contact4= isset($data['cs_center_contact4'])? $data['cs_center_contact4'] :'';

   $terms_is_selected = (isset($data['terms']) && $data['terms'] == 'on') ? 'yes' :'no';

   $courier_code = (isset($data['shipper']) && $data['shipper'] != 'select') ? $data['shipper'] :'';

   $tax_invoice_issue = isset($data['tax_invoice_issue'])? $data['tax_invoice_issue'] :'';
   $product_return_exchnage_shipping_cost=	!empty($data['product_return_exchnage_shipping_cost']) ? $data['product_return_exchnage_shipping_cost'] : '';
   $vendor_details_array = array();
   if( Request::isMethod('post') && Session::token() == Input::get('_token')){



			//Get data from
     $vendor_details = DB::table('users_details')
     ->where(['user_id'=> Session::get('shopist_admin_user_id')])
     ->select('users_details.*')->get()->toArray();
     $vendor_details_array = isset($vendor_details[0]->details)?json_decode($vendor_details[0]->details) : array();

     $zip_postal_code = isset($vendor_details_array->business_details->zip_postal_code)? $vendor_details_array->business_details->zip_postal_code : '';

     $contact_2 = isset($vendor_details_array->business_details->contact_2)? $vendor_details_array->business_details->contact_2 : '';

     $account_copy_image = isset($vendor_details_array->business_details->account_copy_image)? $vendor_details_array->business_details->account_copy_image : '';

     $license_certificate = isset($vendor_details_array->business_details->license_certificate)? $vendor_details_array->business_details->license_certificate : '';

     $get_available_roles = get_roles_details_by_role_slug('vendor');
     if (!empty($get_available_roles)) {
				//Update vendor data

       DB::table('users')->where(['id'=>Session::get('shopist_admin_user_id')])->update(['display_name'=>$data['seller_name'],'name'=>$data['operator'],'email'=>$data['email']]);

       $Userdetails = new UsersDetail;
       $get_package  = VendorPackage::where(['package_type' => 'Default'])->first();
       if($data['vendor_type']=='single'){
         $vendor_data['profile_details'] = array('store_name' => Input::get('seller_name'),'contact_name'=>Input::get('seller_name'),'contact_email'=>$data['email'],'contact_1' => $data['vendor_reg_contact_number1'] , 'contact_2' => $contact_2,'vendor_notification'=>$sms_email_recieving_status,'terms_is_selected'=>$terms_is_selected);

         $vendor_data['business_details'] = array('zip_postal_code' => $zip_postal_code,'address_line_1' => Input::get('business_loctaion_1'), 'address_line_2' => Input::get('business_loctaion_2'),'account_number'=>Input::get('deposite_account_no'),'account_holder_dob'=>Input::get('account_holder_dob'),'bank_name'=>Input::get('bank_name'),'account_holder'=>Input::get('depositer'),'reception_contact_number'=>$data['vendor_reg_contact_number1'],'vendor_fax_number'=> $data['vendor_fax_number'],'tax_invoice_issue'=>$tax_invoice_issue);

         $vendor_data['settlement_details'] = array();
       }
       else if($data['vendor_type']=='business'){

        $vendor_data['profile_details'] = array('store_name' => Input::get('seller_name'),'contact_name'=>Input::get('seller_name'),'contact_email'=>$data['email'],
          'contact_1' =>$data['vendor_reg_contact_number1'] , 'contact_2' => $contact_2,'vendor_notification'=>$sms_email_recieving_status,'terms_is_selected'=>$terms_is_selected);		

        $vendor_data['business_details'] = array('business_number' => Input::get('comp_reg_number'),'zip_postal_code' => $zip_postal_code,'address_line_1' => Input::get('business_loctaion_1'), 'address_line_2' => Input::get('business_loctaion_2'),'account_number'=>Input::get('deposite_account_no'),'account_holder_dob'=>Input::get('account_holder_dob'),'bank_name'=>Input::get('bank_name'),'account_holder'=>Input::get('depositer'),'vendor_fax_number'=> $data['vendor_fax_number'],'reception_contact_number'=>$data['vendor_reg_contact_number1'],'account_copy_image'=>$account_copy_image,'license_certificate'=>$license_certificate,'tax_invoice_issue'=>$tax_invoice_issue);

        $vendor_data['personnel_details'] = array('name'=> Input::get('representative_contact_person'),'email'=> Input::get('representative_person_mail'),'representative_contact1'=>$data['representative_contact1'],'representative_contact2'=> $data['representative_contact2']);

        $vendor_data['sales_details'] = array('name'=> Input::get('sales_contact_person'),'email'=> Input::get('sales_person_mail'),'sales_person_contact1'=> $data['sales_person_contact1'],'sales_person_contact2'=> $data['sales_person_contact2']);

        $vendor_data['product_reg_details'] = array('name'=> Input::get('product_registration_contact_person'),'email'=> Input::get('product_registration_person_mail'),'product_reg_contact1'=>$data['product_reg_contact1'],'product_reg_contact2'=> $data['product_reg_contact2']);

        $vendor_data['shipping_cont_details'] = array('name'=> Input::get('shipping_contact_person'),'email'=> Input::get('shipping_person_mail'),'shipping_contact_1'=> $data['shipping_contact_number1'],'shipping_contact_2'=> $data['shipping_contact_number1']);

        $vendor_data['settlement_details'] = array('settlement_contact_name' => Input::get('settlement_contact_person'),'sett_contact_1' => $data['vendor_settlement_contact_number1'] , 'sett_contact_2' => $data['vendor_settlement_contact_number1'],'sett_contact_email'=>$data['settlement_person_mail']);

      }
      $vendor_data['cs_center_information'] = array('contact_1'=>$data['contact_1'],'contact_1_status'=>$cs_center_contact1,'contact_2'=>$data['contact_2'],'contact_2_status'=>$cs_center_contact2,'contact_3'=>$data['contact_3'],'contact_3_status'=>$cs_center_contact3,'contact_4'=>$data['contact_4'],'contact_4_status'=>$cs_center_contact4,'weekday_from'=>$data['weekday_from'],'weekday_to'=>$data['weekday_to'],'saturday_time_from'=>$data['saturday_time_from'],'saturday_time_to'=>$data['saturday_time_to'],'lunch_time_from'=>$data['lunch_time_from'],'lunch_time_to'=>$data['lunch_time_to'],'not_available_time_from'=>$data['not_available_time_from'],'not_available_time_to'=>$data['not_available_time_to'],'priority_channel'=>$data['priority_channel'],'courier_code'=>$courier_code);

      $vendor_data['shipping_method'] = $data['product_shipping_cost_section_data'];
      $vendor_data['return_shipping_data'] = $product_return_exchnage_shipping_cost;
      /*$vendor_data['payment_method'] = $vendor_details_array->payment_method;*/

      $vendor_data['seo'] = array('meta_keywords' => '', 'meta_decription' => '');



      if(!empty($get_package)){
       $vendor_data['package'] = array('package_name' => $get_package->id);
     }
     else{
       $vendor_data['package'] = array('package_name' => '');
     }
     $vendor_data['vendor_info'] = array('vendor_info' => $other_detail);


     $Userdetails->where(['user_id' => Session::get('shopist_admin_user_id')])
     ->update(['details'=>json_encode($vendor_data)]);

				 //Add logs
     UserActionLogs::insert(array('action_id'=>Session::get('shopist_admin_user_id'),'action_source'=>'Update Seller Information','action_status'=>'success','affected_columns'=>'','action_time'=>date('Y-m-d h:i:s'),'action_by'=>Session::get('shopist_admin_user_id'),'action_type'=>'SELLER_UPDATE'));

     return redirect()->route('seller.editSellerInfo');
   
   }else {
     Session::flash('error-message', Lang::get('frontend.not_role_selected_label'));
     return redirect()->back();
   }
 }else{
  return redirect()->route('seller.editSellerInfo');
}
}
}	

	/**
	* Function : Funttion to load seller information management page.
	* <ayushma.jain@gaurish.com>
	**/
	public function sellerAccountManagement()
	{
		$data = array();
		$common_obj  = new CommonFunction();
		$data = $common_obj->commonDataForAllPages();
		
		return view('pages.admin.seller.account-mgmt', $data);
	}
	
	/**
	* Function : Funttion to load seller information management page.
	* <ayushma.jain@gaurish.com>
	**/
	public function ruleViolationManagement()
	{
		$data = array();
		$common_obj  = new CommonFunction();
		$data = $common_obj->commonDataForAllPages();
		
		return view('pages.admin.seller.rule-violation-mgmt', $data);
	}
	
	/**
	* Function : Function to load leave seller page.
	* <ayushma.jain@gaurish.com>
	**/
	public function leaveSellerPage()
	{
		$data = array();
		$common_obj  = new CommonFunction();
		$data = $common_obj->commonDataForAllPages();
		$data['ventor_details'] = get_user_details(Session::get('shopist_admin_user_id'));
		return view('pages.admin.seller.leave-seller', $data);
	}
	/**
	* Function : Function to save withdrawal reason for leave seller.
	* <ayushma.jain@gaurish.com>
	**/
	public function saveWithdrawalReason()
	{ 
		$withdrawal_reason = isset($_POST['withdraw_reason']) ? $_POST['withdraw_reason'] : '';
		$vendorWithDrawStatus = User::where('id', Session::get('shopist_admin_user_id'))
   ->update(['user_status' => 2,'withdrawal_reason' => $withdrawal_reason  ]);
   if(empty($vendorWithDrawStatus)){
     return redirect()->back()->with('error','업데이트되지 않음');
   }else{
     return redirect()->route('vendor.logout');
   }
 }


	/**
	* Function : Function to load leave seller page.
	* <ayushma.jain@gaurish.com>
	**/
	public function adRegistrationPage(){
		$data = array();
		$common_obj  = new CommonFunction();
		$data = $common_obj->commonDataForAllPages();
		$ads_id = isset($_GET['ads'])?$_GET['ads']:0;
		$search_term = isset($_GET['search_term']) ? $_GET['search_term'] :0;
		$main_category = isset($_GET['main_category']) ? $_GET['main_category'] :0;
		$middle_class = isset($_GET['middle_class']) ? $_GET['middle_class'] :0;
		$small_class = isset($_GET['small_class']) ? $_GET['small_class'] :0;
		$sub_division = isset($_GET['sub_division']) ? $_GET['sub_division'] :0;
		$author_id = Session::get('shopist_admin_user_id');
		
		if(empty($ads_id))
		{
			$adv_list  = DB::table('advertisement')->get()->toArray();
			$data['adv_list']=$adv_list;
			
			//echo '<pre>';print_r($data);exit;
			return view('pages.admin.seller_advertisement.ad-registration', $data);
		}
		else
		{
			$adv_list  = DB::table('advertisement')->where(['id' => $ads_id])->get()->toArray();
			$data['couponList'] = $this->getCouponList($author_id);
			$usedProductList = DB::table('adv_request')->where(['seller_id'=>$author_id,'adv_id'=>$ads_id])->where('status','!=','Expired')->select('product_id')->get()->toArray();
			
			$data['adv_list']=$adv_list;
			
			// Calling this function to get all categories list by parent cat id.
			$data['mainCategories'] = $this->products->getCategoriesByParentCatId(0);
			$data['categories_lists']  =   $this->products->get_categories( 0, 'product_cat');
			
			//To get Last Available Date
			$data['adsData'] = DB::table('advertisement')->where(['id'=>$ads_id])->select(['maximum_ads','price'])->get()->toArray();
			

			$ad_last_date = DB::table('adv_request')->where(['adv_id'=>$ads_id])->where('adv_request.status','!=','Expired')->select('end_date')->orderBy('end_date','ASC')->get()->toArray();
			$maximum_ads = isset($data['adsData'][0]->maximum_ads)?$data['adsData'][0]->maximum_ads : '' ;
			if(count($ad_last_date) >= $maximum_ads){
				$diff= count($ad_last_date)-$maximum_ads;
				$date =strtotime($ad_last_date[$diff]->end_date);
				
			$date = date("Y-m-d",$date);
		}else{
			$date = date("Y-m-d");	
		}
		$data['adAvailableDate'] = $date;


			//Get Top category Filter Id.
		$getTopCategoryFilterId = (!empty($sub_division)? $sub_division : (!empty($small_class) ? $small_class : (!empty($middle_class) ? $middle_class : (!empty($main_category) ? $main_category : 0))));

		if($getTopCategoryFilterId != 'all'){
		  $getTopCategoryFilterSlug = DB::table('terms')->where(['term_id'=>$getTopCategoryFilterId])->select('slug')->get()->toArray();
		  $getTopCategoryFilterSlug = isset($getTopCategoryFilterSlug[0]->slug) ? $getTopCategoryFilterSlug[0]->slug : '' ;





		  $product_list  =   $this->products->getProductByCatSlug($getTopCategoryFilterSlug, 'product_cat',$search_term,$author_id);

		  $product_list = $product_list['products'];

		}else{
		  $where = ['author_id' => Session::get('shopist_admin_user_id'),'status'=>1];


		  if($search_term != ''){
		   $product_list = Product::where($where)->where('stock_availability','!=','hidden')->where('title','LIKE', '%'.$search_term.'%')->orderBy('id', 'asc')->get()->toArray();
		 }else{
		   $product_list = Product::where($where)->where('stock_availability','!=','hidden')->orderBy('id', 'asc')->get()->toArray();
		 }
	   }
	   $usedProduct =array();
	   if(count($usedProductList)>0){
		foreach($usedProductList as $row){
		 array_push($usedProduct,$row->product_id);
	   }
	}

	 $data['usedProductList']= $usedProduct;
	 $data['product_list']= $product_list;
	 $data['ads_id'] = $ads_id;
	 $data['search_term'] = $search_term;
	 $data['main_category'] = $main_category;
	 $data['middle_class'] = $middle_class;
	 $data['small_class'] = $small_class;
	 $data['sub_division'] = $sub_division;	

	 return view('pages.admin.seller_advertisement.ad-registration-wizard', $data);
	}
}


	/**
	* Function : Function to load leave seller page.
	* <ayushma.jain@gaurish.com>
	**/
	public function adminAdRegistrationPage(){
		$data = array();
		$common_obj  = new CommonFunction();
		$data = $common_obj->commonDataForAllPages();
		$ads_id = isset($_GET['ads'])?$_GET['ads']:0;
		$adv_list  = DB::table('advertisement')->get()->toArray();
		$data['total_ad_request'] = DB::table('adv_request')->count();
		$data['total_running_ads'] = DB::table('adv_request')->whereIn('status' , array('Approved','Running'))->count();
		$data['total_new_request_ads'] = DB::table('adv_request')->whereIn('status' , array('WaitApproved'))->count();
		$data['total_blank_ads'] = $this->getTotalBlankAdsCount();
		$data['adv_list']=$adv_list;
		return view('pages.admin.admin_ads.ad-registration', $data);
	}

	
	/**
	* Function : Function to load Order Management Page.
	* <ayushma.jain@gaurish.com>
	**/
	public function orderMgmt(){
		$data = array();
		$common_obj  = new CommonFunction();
		$data = $common_obj->commonDataForAllPages();
		
		return view('pages.admin.orders.order-list-page', $data);
	}
	
	/**
	* Function : Funttion to load Payment History page.
	* <ayushma.jain@gaurish.com>
	**/
	public function paymentHistoryPage(){
		$data = array();
		$common_obj  = new CommonFunction();
		$data = $common_obj->commonDataForAllPages();

		return view('pages.admin.seller_advertisement.payment-history', $data);
	}
	
	/**
	* Function : Function to load Payment History page.
	* <ayushma.jain@gaurish.com>
	**/
	public function adStatusPage(){
		$data = array();
		$perpage = 10;
		if(isset($_GET['perPage'])){
			$perpage = $_GET['perPage'];
		}
		$common_obj  = new CommonFunction();
		$data = $common_obj->commonDataForAllPages();
		
		
		
		$adsStatusList = DB::table('adv_request')
   ->where(['adv_request.seller_id'=>Session::get('shopist_admin_user_id')])
   ->where('adv_request.status','!=','Expired')
   ->join('advertisement','advertisement.id','=','adv_request.adv_id')
   ->leftjoin('products','products.id','=','adv_request.product_id')
   ->select('adv_request.*','advertisement.name','products.title','products.image_url')->orderBy('created_at','DESC')->paginate($perpage);

   $data['adsList'] = $adsStatusList;
   $data['perpage'] = $perpage;

   return view('pages.admin.seller_advertisement.ad-status', $data);
 }

	/**
	* Function : Function to load Bulk Product Registration page.
	* <ayushma.jain@gaurish.com>
	**/
	public function bulkProductRegistration(){
		$data = array();
		$common_obj  = new CommonFunction();
		$data = $common_obj->commonDataForAllPages();

		return view('pages.admin.product.bulk_product_registration', $data);
	}
	
	
	/**
	* Function : Function to Save FAQ Data .
	* <ayushma.jain@gaurish.com>
	**/
	public function SaveFAQ(){
		if( Request::isMethod('post') && Session::token() == Input::get('_token') ){
			$input = Input::all();
			
			$id = isset($input['row_id'])? $input['row_id'] : null;
			$faq			=  new FaqSearch;
			echo $id;
			$faq->updateOrCreate(
				[
					'bintId' => $id
				],
				[
         'varInquiryType' => $input['faq_type'],
         'txtFaqTitle' =>  $input['faq_title'],
         'txtFaqDescription' => string_encode($input['faq_description_editor']),
         'updated_at' => date('Y-m-d h:i:s')
       ]
     );

			return redirect()-> route('admin.faq-mgmt');
		}
	}
	
	/**
	* Function : Function to load FAQ Management page.
	* <ayushma.jain@gaurish.com>
	**/
	public function faqManagement(){
		$data = array();
		$search_value = '';
		$search_category = '';
		if(isset($_POST['get_search_term']) && $_POST['get_search_term'] != ''){
      $search_value = trim($_POST['get_search_term']); 
    }
    $search_category = isset($_POST['faq_category']) ? $_POST['faq_category'] : 'All';
    $common_obj  = new CommonFunction();
    $data = $common_obj->commonDataForAllPages();
    $data['search_term'] =  $search_value;
    $data['search_category'] =  $search_category;
    $data['faq_result'] = $this->user->getFaqSearchData(true, $search_value,$search_category,'admin');
		//echo '<pre>'; print_r($data['faq_result']);echo '</pre>';exit;
    return view('pages.admin.system_setting.faq_mgmt', $data);
  }


	/**
	* Function : Function to load Notice Management page.
	* <ayushma.jain@gaurish.com>
	**/
	public function noticeManagement(){
		$data = array();
		$search_value = '';
		if(isset($_POST['get_search_term']) && $_POST['get_search_term'] != ''){
      $search_value = trim($_POST['get_search_term']); 
    }

    $common_obj  = new CommonFunction();
    $data = $common_obj->commonDataForAllPages();
    $data['search_term'] =  $search_value;
    $data['notice_result'] = $this->user->getNoticeSearchData(true, $search_value,'admin');

    return view('pages.admin.system_setting.notice_mgmt', $data);
  }
	/**
	* Function : Function to Save Notice Data .
	* <ayushma.jain@gaurish.com>
	**/
	public function SaveNotice(){
		
		if( Request::isMethod('post') && Session::token() == Input::get('_token') ){
			$input = Input::all();
			$id = isset($input['row_id'])? $input['row_id'] : '';
			$notice			=  new NoticeMgmt;
			$notice->updateOrCreate(
				[
          'id' => $id
        ],
        [
          'title' => $input['notice_title'],
          'description' => string_encode($input['notice_description_editor']),
          'updated_at' =>  date('Y-m-d h:i:s')
        ]
      );
			/*$notice->insert([
				'title' =>  $input['notice_title'],
				'description' => string_encode($input['notice_description_editor']),
				'updated_at' => date('Y-m-d h:i:s')
      ]);*/
      return redirect()-> route('admin.notice-mgmt');
    }
  }



	/**
	* Function : Function to load user block id from vendor.
	* <anuj@gaurish.com>
	**/
	public function intruptUserID()
	{
		$data = array();
		$common_obj  = new CommonFunction();
		$data = $common_obj->commonDataForAllPages();
		
		$data['intruped_user_list']  = DB::table('intrupted_user')->get()->toArray();
		
		return view('pages.admin.customer.intrupt_user', $data);
	}
	
	/**
	* Function : Function to load ad Expense Coupon management page.
	* <anuj@gaurish.com>
	**/
	public function adCouponManagement()
	{
		$data = array();
		$common_obj  = new CommonFunction();
		$data = $common_obj->commonDataForAllPages();
		$seller = $common_obj->getAllSeller();
		$seller_autocomplete_array=array();
		$per_page=(isset($_GET['perPage']))?$_GET['perPage']:20;
		$sort=(isset($_GET['coupon_filter']))?$_GET['coupon_filter']:'all';
		$start_date=(isset($_GET['start_date']))?$_GET['start_date']:'';
		$end_date=(isset($_GET['end_date']))?$_GET['end_date']:'';
		$search_term=(isset($_GET['search']))?$_GET['search']:'';
		$seller_data=array();
		if(count($seller)>0)
		{
			foreach($seller as $rr)
			{
				array_push($seller_autocomplete_array,$rr->name);
				$seller_data[$rr->name]=$rr;
			}
		}
		$data['seller_autocomplete_array']=$seller_autocomplete_array;
		$data['seller_data']=$seller_data;
		$whereCondition = array();
		if(!empty($start_date))
		{
			$temp=array('created_at', '>=', $start_date);
			array_push($whereCondition,$temp);
		}
		if(!empty($end_date))
		{
			$temp=array('created_at', '=<', $end_date);
			array_push($whereCondition,$temp);
		}

		$data['coupon_data']=DB::table('coupon')->where($whereCondition)->where(function ($query) use ($search_term) {
      if(!empty($search_term))
      {
       $query->where('amount','LIKE', '%'.$search_term.'%')
       ->orWhere('coupon_number','LIKE', '%'.$search_term.'%')
       ->orWhere('issue_target','LIKE', '%'.$search_term.'%');
     }
   })->select('*')->orderBy('created_at', 'DESC')->paginate($per_page)->toArray();
		$data['perPage']=$per_page;
		$data['start_date']=$start_date;
		$data['end_date']=$end_date;
		$data['search_term']=$search_term;
		$data['sort']=$sort;
		return view('pages.admin.system_setting.coupon-ad-mgmt', $data);
	}
	
	/**
	* Function : Funttion to load user block id from vendor.
	* <ayushma.jain@gaurish.com>
	**/
	public function saveintruptUserID()
	{
		if( Request::isMethod('post') && Session::token() == Input::get('_token') ){
			$input = Input::all();
			$user_id=0;
			$get_user_name = User::where(['display_name' => $input['prohibited_id']])->first(['id']);
			$intrupt_user			=  new IntruptedUser;
			if(!empty($get_user_name))
			{
				$get_user_name = $get_user_name->toArray();
				$user_id = $get_user_name['id'];
			}
			else{
				return redirect()->back()->with('error','사용자를 찾을 수 없음');
			}
			$alreadyExistcheck = IntruptedUser::where(['user_id' => $user_id,'seller_id' =>  Session::get('shopist_admin_user_id')])->get()->toArray();
			if(empty($alreadyExistcheck)){
				$intrupt_user->insert([
					'user_id' => $user_id,
					'seller_id' =>  Session::get('shopist_admin_user_id'),
					'user_name' => $input['prohibited_id'],
					'type' =>    $input['type'],
					'prohibited_reason' => $input['pohibition_reason'],
					'updated_at' => date('Y-m-d h:i:s')
       ]);
			}
			else{
				return redirect()->back()->with('error','이 사용자는 이미 금지된 사용자로 표시됨');
			}
			return redirect()-> route('admin.intruptUserID');
		}
	}
	
	public function deleteintruptUserID($user_id=''){
		DB::table('intrupted_user')->where('user_id',$user_id)->delete(); 
		return redirect()-> route('admin.intruptUserID');
	}
	/**
	* Function : Funttion to download excel for inquiry data.
	* <anuj@gaurish.com>
	**/
	public function downloadInquiryDetail()
	{
		$search_term=(isset($_GET['search_term']))?$_GET['search_term']:'';
		$type=(isset($_GET['type']))?$_GET['type']:'';
		$ids=(isset($_GET['ids']))? explode(",",$_GET['ids']):'';
		if(!empty($search_term) && !empty($type))
		{
			$inquiry_list  = DB::table('support_ticket')
			->join('users','users.id','=','support_ticket.user_id')
			->join('products','products.id','=','support_ticket.product_id')
			->whereIn('support_ticket.id',$ids,$whereType)
			->where(['vendor_id' => Session::get('shopist_admin_user_id')])
			->where(['support_ticket.type' => $type])
			->where('ticket_name', 'LIKE', '%'.$search_term.'%')
			->orWhere('ticket_content', 'LIKE', '%'.$search_term.'%')
			->select('support_ticket.*','users.display_name','products.title')->get()->toArray();
		}
		else if(!empty($search_term))
		{
			$inquiry_list  = DB::table('support_ticket')
			->join('users','users.id','=','support_ticket.user_id')
			->join('products','products.id','=','support_ticket.product_id')
			->whereIn('support_ticket.id',$ids,$whereType)
			->where(['vendor_id' => Session::get('shopist_admin_user_id')])
			->where('ticket_name', 'LIKE', '%'.$search_term.'%')
			->orWhere('ticket_content', 'LIKE', '%'.$search_term.'%')
			->select('support_ticket.*','users.display_name','products.title')->get()->toArray();
		}
		else if(!empty($type))
		{
			$inquiry_list  = DB::table('support_ticket')
			->join('users','users.id','=','support_ticket.user_id')
			->join('products','products.id','=','support_ticket.product_id')
			->whereIn('support_ticket.id',$ids)
			->where(['vendor_id' => Session::get('shopist_admin_user_id')])
			->where(['support_ticket.type' => $type])
			->select('support_ticket.*','users.display_name','products.title')->get()->toArray();
		}
		else
		{
			$inquiry_list  = DB::table('support_ticket')
			->join('users','users.id','=','support_ticket.user_id')
			->join('products','products.id','=','support_ticket.product_id')
			->whereIn('support_ticket.id',$ids)
			->where(['vendor_id' => Session::get('shopist_admin_user_id')])
			->select('support_ticket.*','users.display_name','products.title')
			->get()->toArray();
		}
		$data = array();
		if(count($inquiry_list)>0)
		{
			$type=array('delivery'=>'배송','product'=>'상품(성능/기능)','exchange'=>'교환/환불','cancel'=>'취소','other'=>'기타');
			$a=1;
			foreach($inquiry_list as $list)
			{
				$row['S.No.']=$a;
				$row['제품 제목']=$list->title;
				$row['문의유형']=$type[$list->type];
				$row['제목']=$list->ticket_name;
				$row['내용']=$list->ticket_content;
				$row['댓글']=$list->ticket_response;
				$row['조회수']=0;
				$row['사용자 이름']=$list->display_name;
				$row['지위']=($list->status=='wait')? '답변대기':'답변 완료';
				$row['날짜']=$list->created_at;
				array_push($data,$row);
				$a++;
			}
		}
		// Generate and return the spreadsheet
		return Excel::create('고객문의', function($excel) use ($data) {

			$excel->sheet('고객문의', function($sheet) use ($data)
     {
      $sheet->fromArray($data);
    });
		})->download('xls');
	}
	/**
	* Function : Funttion to download excel for product review data.
	* <anuj@gaurish.com>
	**/
	public function downloadProductReviewDetail()
	{
		$search_term=(isset($_GET['search_term']))?$_GET['search_term']:'';
		$rate=(isset($_GET['type']))?$_GET['type']:'';
		$ids=(isset($_GET['ids']))? explode(",",$_GET['ids']):'';
		if(!empty($search_term) && !empty($rate))
		{
			$review_list  = DB::table('comments')
			->join('users','users.id','=','comments.user_id')
			->join('products','products.id','=','comments.object_id')
			->whereIn('comments.id',$ids)
			->where(['products.author_id' => Session::get('shopist_admin_user_id')])
			->where(['comments.rating'  => $rate])  
			->where('comments.content', 'LIKE', '%'.$search_term.'%')  
			->orWhere('products.title', 'LIKE', '%'.$search_term.'%') 
			->select('comments.*','users.display_name','products.title','products.image_url')
			->get()->toArray();
		}
		elseif(!empty($search_term))
		{
			$review_list  = DB::table('comments')
			->join('users','users.id','=','comments.user_id')
			->join('products','products.id','=','comments.object_id')
			->whereIn('comments.id',$ids)
			->where(['products.author_id' => Session::get('shopist_admin_user_id')])
			->where(['comments.rating' => $rate])  
			->where('comments.content', 'LIKE', '%'.$search_term.'%')  
			->orWhere('products.title', 'LIKE', '%'.$search_term.'%') 
			->select('comments.*','users.display_name','products.title','products.image_url')
			->get()->toArray();
		}
		elseif(!empty($rate))
		{
			$review_list  = DB::table('comments')
			->join('users','users.id','=','comments.user_id')
			->join('products','products.id','=','comments.object_id')
			->whereIn('comments.id',$ids)
			->where(['products.author_id' => Session::get('shopist_admin_user_id')])
			->where(['comments.rating'  => $rate])  
			->select('comments.*','users.display_name','products.title','products.image_url')
			->get()->toArray();
		}
		else
		{
			$review_list  = DB::table('comments')
			->join('users','users.id','=','comments.user_id')
			->join('products','products.id','=','comments.object_id')
			->whereIn('comments.id',$ids)
			->where(['products.author_id' => Session::get('shopist_admin_user_id')])
			->select('comments.*','users.display_name','products.title','products.image_url')
			->get()->toArray();
		}
		$data = array();
		if(count($review_list)>0)
		{
			$a=1;
			foreach($review_list as $list)
			{
				$row['S.No.']=$a;
				$row['제품 제목']=$list->title;
				$row['리뷰 속도']=$list->rating;
				$row['논평']=$list->content;
				$row['조회수']=0;
				$row['날짜']=$list->created_at;
				array_push($data,$row);
				$a++;
			}
		}
		// Generate and return the spreadsheet
		return Excel::create('상품평 관리', function($excel) use ($data) {

			$excel->sheet('상품평 관리', function($sheet) use ($data)
     {
      $sheet->fromArray($data);
    });
		})->download('xls');
	}

   /**
   * Function to load User Account management view page.
   * 
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Created On : 15-May-2019
   *
   * @param null 
   * @return view page
   */
   public function loadUserAccountManagementPage()
   {
     // Display page to pmg master admin only.
     if(is_admin_login())
     {
       $data = array();
       $common_obj  = new CommonFunction();

       $data = $common_obj->commonDataForAllPages();
      $userId = (isset($_REQUEST['_user_id']) && is_numeric($_REQUEST['_user_id']))?$_REQUEST['_user_id'] : 0;
      $userActiveStatus = (isset($_REQUEST['user_status']) && is_numeric($_REQUEST['user_status']))?$_REQUEST['user_status'] : 0;
      $reasonForAccountBan = (isset($_REQUEST['reason_for_account_ban']))?$_REQUEST['reason_for_account_ban'] :'';
     
      // Validate required fields.
      if ($userId > 0 && $reasonForAccountBan != '')
      {
        // Calling this function to save user active/suspend status
         $data['actionStatus']  =   $this->user->saveActiveSuspendedUserInfo($userActiveStatus, $userId, $reasonForAccountBan);
      }
      
       

       $searchTerm = '';

      if(isset($_REQUEST['searchTerm']) && $_REQUEST['searchTerm'] != '')
      {
        $searchTerm = $_REQUEST['searchTerm'];
      }



      $perPage=(isset($_REQUEST['perPage']))?$_REQUEST['perPage']:10;

      // Calling this function to get list of all buyer user data.
      $data['buyerUserList'] = $this->user->getAllUserListData(true, $searchTerm, -1, 'buyer', 'name', $perPage);
    
     
      // Query to get total user count data.
      $totalUserCount = DB::table('users as U')
      ->join('role_user as UR',function($join){
          $join->on("UR.user_id","=","U.id");
        })
      ->join('roles as R',function($join){
          $join->on("R.id","=","UR.role_id");
        })->where(['R.slug' => 'site-user'])->select('id')->count();

      $data['totalUserCount']      =  $totalUserCount;
      $data['search_value']      =  $searchTerm;
      $data['per_page']      =  $perPage;
     
       
      return view('pages.admin.users.user-account-management', $data);
    } else
    {
      return redirect()-> back();
    }
  } 

 /**
   * Function for getting user get user detail by login id.  
   * 
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Created On : 17-May-2019
   *
   * @return array
   */
  public function getUserAccountDetail()
  {
    $userdetails = array();
    if( Request::isMethod('post') && Session::token() == Input::get('_token') )
    {
      // Getting input data.
      $requestId = (Input::has('requestId') && is_numeric(Input::get('requestId'))) ? Input::get('requestId') : 0;
      if ($requestId > 0){
        // Calling this function to get user detail by login id.  
        $userdetails = $this->user->getAllUserListData(false, '', -1, 'buyer', 'name', 5, 'export', $requestId);
      }
    }
     
    //print_r(addslashes(json_encode($consultationRequestData)));
    print_r(json_encode($userdetails));
  }

   /**
   * Function to load 1:1 Consultation management view page.
   * 
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Created On : 13-May-2019
   *
   * @param null 
   * @return view page
   */
   public function adminOneToOneConsultationManagementPage()
   {
     // Display page to pmg master admin only.
     if(is_admin_login())
     {
       $data = array();
       $common_obj  = new CommonFunction();

       $data = $common_obj->commonDataForAllPages();

      // Loading instance of Consultation Model.
       $Consultation = new Consultation;

       $consultationId = 0;
       if(isset($_REQUEST['_consultation_id']) && is_numeric($_REQUEST['_consultation_id']))
       {
        $consultationId = $_REQUEST['_consultation_id'];
      }
      $userInquiryResponse ='';
      if(isset($_REQUEST['user_inquiry_response']))
      {
        $userInquiryResponse = $_REQUEST['user_inquiry_response'];
      }
      
      // Calling this function to save 1:1 consultation reply.
      $data['replyStatus'] =  $Consultation->saveOneToOneConsultationReply($consultationId, $userInquiryResponse);

      
      $searchTerm = '';
      $filterType = '';
      
      if(isset($_REQUEST['searchTerm']) && $_REQUEST['searchTerm'] != '')
      {
        $searchTerm = $_REQUEST['searchTerm'];
      }

      if(isset($_REQUEST['filterType']) && $_REQUEST['filterType'] != '')
      {
        $filterType = $_REQUEST['filterType'];
      }

      $perPage=(isset($_REQUEST['perPage']))?$_REQUEST['perPage']:10;

      
      
      // Calling this function to get all one to one consultaion request(s) data.
      $data['oneToOneconsultationData'] =  $Consultation->getAdminOneToOneCosultaionDataData(true, $searchTerm, $perPage, 'recent', $filterType);

      // Query to fetch all consultation request count data.
      $totalConsultations = DB::table('user_1_1_consultation_inquiry_data')->select('bintInquiryId')->count();

      $data['totalConsultations']      =  $totalConsultations;
      $data['search_value']      =  $searchTerm;
      $data['per_page']      =  $perPage;
      $data['filterType']      =  $filterType;



      return view('pages.admin.admin-1-1-consultation-management', $data);
    } else
    {
      return redirect()-> back();
    }
  } 

  /**
   * Function to export 1:1 Consultation list in excel formate on management view page.
   * 
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Created On : 13-May-2019
   *
   * @param null 
   * @return view page
   */
  public function exportOneToOneConsultationListData()
  {
    // Validte required data.
    if(is_admin_login() && Request::isMethod('post') && Session::token() == Input::get('_token')) 
    {

      $searchTerm = '';
      $filterType = '';

      if(isset($_POST['d_searchTerm']) && $_POST['d_searchTerm'] != '')
      {
        $searchTerm = $_POST['d_searchTerm'];
      }

      if(isset($_POST['d_filterType']) && $_POST['d_filterType'] != '')
      {
        $filterType = $_POST['d_filterType'];
      }

      $perPage=(isset($_POST['d_perPage']))?$_POST['d_perPage']:10;


      $common_obj  = new CommonFunction();

      $data = $common_obj->commonDataForAllPages();

      // Loading instance of Consultation Model.
      $Consultation = new Consultation;

      // Calling this function to get all one to one consultaion request(s) data for logged in user.  
      $oneToOneconsultationData =  $Consultation->getAdminOneToOneCosultaionDataData(true, $searchTerm, $perPage, 'recent', $filterType, 'export');

      $data = array();  
      if(count($oneToOneconsultationData)>0)
        {  $tempCount = 0;
          foreach($oneToOneconsultationData as $list)
          {

            if (isset($list->bintInquiryId) && is_numeric($list->bintInquiryId)) 
            {

              $row['품번']=++$tempCount;
              $row['제목']=$list->txtInquiryTitle;
              $inquiryField = '';

              if(!empty($list->txtUserFieldOfInquiry)){
                $inquiryField =trans('frontend.lable_1_1_consultation_'.$list->txtUserFieldOfInquiry);
              } 
              $row['문의유형']= $inquiryField;
              $row['내용']=$list->txtInquiryContent;
              $row['휴대폰 번호']=$list->varMobilePhoneNumber;
              $row['이메일 주소']=$list->varEmailAddress;
              $answerStatus = '';
              if(!empty($list->varAnswerStatus)){
                $answerStatus.=trans('frontend.lable_1_1_consultation_answer_status_'.$list->varAnswerStatus);
              }
              $row['답변상태']=$answerStatus;

              $createdAtDate = '';
              if ($list->created_at !='' && $list->created_at !='0000-00-00 00:00:00'){
                $createdAtDate = date('Y.m.d',strtotime($list->created_at));
              }
              $row['문의날짜']=$createdAtDate;

              array_push($data, $row);
            } 
          }
        } 

        $filename = '컨설팅 조회 내보내기 - '.date('Y.m.d h:i:s').'-'.mt_rand();
      // Generate and return the spreadsheet
        return Excel::create($filename, function($excel) use ($data) {

          $excel->sheet('컨설팅 조회 내보내기', function($sheet) use ($data)
          {
            $sheet->fromArray($data, null, 'A1', true);

          });
        })->download('xls'); 
      }
    }

  /**
   * Function to load category management view page.
   * 
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Created On : 01-May-2019
   *
   * @param null 
   * @return view page
   */
  public function adminCategoryManagementPage()
  {
     // Display page to pmg master admin only.
   if(is_admin_login())
   {
    $data = array();
    $common_obj  = new CommonFunction();
    $data = $common_obj->commonDataForAllPages();

    $allCategories = array();
      // Calling this function to get all categories data by parent id 0.
    $data['largeCategoryList'] = $this->products->getCategoriesByParentCatId(0, "product_cat", "intPosition", "asc", "all");
    $filterType="totalAmt";
    $data['top100CategoryList'] = $this->products->getCategoriesDataByRating($filterType);
    $data['filterType'] = $filterType;

    return view('pages.admin.admin-category-management', $data);
  } else
  {
    return redirect()-> back();
  }

} 

  /**
   * Function to filter and load top 100 categories on category management view page.
   * 
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Created On : 06-May-2019
   *
   * @param null 
   * @return view page
   */
  public function adminFilterTop100CategoryData()
  {
    // This $htmlData variable holds filtered list of top 100 category html data 
    $htmlData='';

    // Display page to pmg master admin only.
    if(is_admin_login() && Request::isMethod('post') && Session::token() == Input::get('_token')) 
    {

      $filterType = (!empty($_POST['filterType']) && $_POST['filterType']=='sales_quantity')?'totalQty':"totalAmt";

      $top100CategoryList = $this->products->getCategoriesDataByRating($filterType);
      
      $top100CategoriesCount = isset($top100CategoryList)?count($top100CategoryList):0;
      
      if ($top100CategoriesCount > 0) 
      {
        $rowStartAndEnd = 0;  
        foreach ($top100CategoryList as $key => $row) 
        {
          $rowStartAndEnd++;
          if ($rowStartAndEnd == 1)
          {
            $htmlData.='<div class="w-20Percent float-left min-w-300px min-h-725px pt-2 pb-2 pl-4 pr-4">';
          }

          // Top -5
          if ($key < 5)
          {
            $colorCodeClassName = "category-red";
          } else if ($key < 10)
          {
            $colorCodeClassName = "category-yellow";
          } else if ($key < 15)
          {
            $colorCodeClassName = "category-blue";
          } else
          {
            $colorCodeClassName = '';
          }
          $htmlData.='
          <div class="row no-gutters" data-term_id="'.$row->term_id.'" data-quantity="'.$row->totalQty.'" data-amount="'.$row->totalAmt.'">
          <div class="col-1 w-80px "><span class="top100CategoryListTextPoint  '.$colorCodeClassName.'">'.($key+1).'위</span></div>
          <div class="col-11 pl-2"><p class="top100CategoryListText '.$colorCodeClassName.'">'.$row->breadcrumb.'</p></div> 
          </div>';

          if ($rowStartAndEnd == 20)
          {
            $htmlData.='</div>';
            $rowStartAndEnd = 0;
          }
                  # code...
        }

        if (($rowStartAndEnd % 20) != 0)
        {
          $htmlData.='</div>';
          $rowStartAndEnd = 0;
        }
      } else
      {
        $htmlData.="<p class='text-danger'>".trans('admin.no_categories_yet')."</p>";
      }
    } 
    
    print_r($htmlData);
  }  
  
 /**
   * Function to save large category data.
   * 
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Created On : 01-May-2019
   *
   * @param null 
   * @return status array
   */
 public function adminSaveCategoryData()
 {
  $errorStatusCode=0;  $categoryIcon = ''; $categoryName = ''; 

  if(is_admin_login() && Request::isMethod('post') && Session::token() == Input::get('_token')) 
  {
    $post_author_id = 0;
    if(Session::has('shopist_admin_user_id') && is_numeric(Session::get('shopist_admin_user_id'))
  ){
      $post_author_id = Session::get('shopist_admin_user_id');
  }

      // function error/success status code. 
  $errorStatusCode = 0;

      // Getting all input data
  $postData = Input::all();

  $categoryName = (isset($postData['categoryName']))? $postData['categoryName'] : '';
  $categoryIconSelected = (isset($postData['categoryIcon']))? $postData['categoryIcon'] : '';

  $categoryId = (isset($postData['categoryId']) && is_numeric($postData['categoryId']))? $postData['categoryId'] : 0;
  $fileName = (isset($_FILES['categoryIconfile']['name']))? $_FILES['categoryIconfile']['name'] : '';
      //$categoryName = (isset($postData['categoryName']))? $postData['categoryName'] : '';

      // Validate required fields
  if($categoryId > 0 && strlen($categoryName) > 0 && (strlen($fileName) > 0 || strlen($categoryIconSelected) > 0))
  {

    $categoryIcon='';
    if($fileName !='')
    {
      $image = Input::file('categoryIconfile');
      $fileName = time()."-"."h-100-w-100-".$image->getClientOriginalName();

      $width = 100;
      $height = 100;
      $img   = Image::make($image);
      $img->resize($width, $height, function ($constraint) {
             // $constraint->aspectRatio();
      });
      $folderPath = 'category_icon_images/'.$categoryId.'/';
      $targetPath = public_path().'/'.$folderPath;

          //Create Directory
      createDirectoroy($targetPath);

      if ($img->save($targetPath. $fileName)) 
      {
        $categoryIcon= $folderPath . $fileName;
      }   

    } else if($categoryIconSelected!=''){
      $categoryIcon= $categoryIconSelected;
    }

        // Query to get duplicate category count if already exists.
    $duplicateCategoryCount = DB::table('terms')
    ->where(['name' => $categoryName,'parent' => 0, 'type' => 'product_cat', 'status' => '1' , 'author_id' => $post_author_id ])
    ->where('term_id', '!=',$categoryId)
    ->select('terms.name')        
    ->count();

        // Duplicate category not exist.
    if ($duplicateCategoryCount == 0)
    {
          // Create and validate Category Slug url on modify category name.
      $categoryNameSlug = string_slug_format($categoryName,'category');
      $checkCategoryNameSlugCount  =  DB::table('terms')->where('term_id', '!=', $categoryId)
      ->where(function ($query) use ($categoryNameSlug) {
        $query->where('slug', '=', $categoryNameSlug)
        ->orWhere('slug', 'like', '%'.$categoryNameSlug.'%');
      })->get()->count();
      if($checkCategoryNameSlugCount > 0)
      {
        $checkCategoryNameSlugCount = $checkCategoryNameSlugCount + 1;
        $categoryNameSlug = $categoryNameSlug. '-' . $checkCategoryNameSlugCount;
      } 

          // Query to update large category data if already exists.
      $updateCategoryStatus = DB::table('terms')
      ->where(['term_id' => $categoryId, 'terms.type' => 'product_cat', 'status' => '1' , 'author_id' => $post_author_id])
      ->update(['name' => $categoryName,'slug' => $categoryNameSlug,'category_icon' => $categoryIcon,'updated_at' => date('Y-m-d h:i:s')]);

      if($fileName !='')
      {
            // Remove all old category icon except newly uploaded one.
        deleteFilesFromGivenDirectoryWithFilter($targetPath,  array($fileName));
      }
      $errorStatusCode = 1; 

    } else
    {
          //Duplicate category name exist.
      $errorStatusCode = 2;
    }
  } 
}  
print_r(json_encode(array('status'=>$errorStatusCode,'catIcon'=>$categoryIcon,'catName'=>$categoryName)));
}    

 /**
   * Function to save large category ordering data.
   * 
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Created On : 02-May-2019
   *
   * @param null 
   * @return status
   */
 public function adminSaveCategoryOrderingData()
 {
  $errorStatusCode=0;  
  if(is_admin_login() && Request::isMethod('post') && Session::token() == Input::get('_token')) 
  {
    $post_author_id = 0;
    if(Session::has('shopist_admin_user_id') && is_numeric(Session::get('shopist_admin_user_id'))
  ){
      $post_author_id = Session::get('shopist_admin_user_id');
  }

      // function error/success status code. 
  $errorStatusCode = 0;

      // Getting all input data
  $postData = Input::all();

  $categoryOrder = (!empty($postData['categoryOrder']))? explode(",", $postData['categoryOrder']) : array();
  $parentId = (isset($postData['parentId']) && is_numeric($postData['parentId']))? $postData['parentId']: -1;

  $where = ['type' => 'product_cat', 'status' => '1' , 'author_id' => $post_author_id];
  if ($parentId >=0){
    $where = ['type' => 'product_cat', 'status' => '1' , 'author_id' => $post_author_id, 'parent' => $parentId];
  }
      // Validate required fields
  if(count($categoryOrder) >0)
  {

    foreach ($categoryOrder as $key => $value) 
    {
          // Query to update category order data.
      $updateCategoryOrder = DB::table('terms')
      ->where('term_id', $value)
      ->where($where)
      ->update(['intPosition' => $key,'updated_at' => date('Y-m-d h:i:s')]);
    }

    $errorStatusCode = 1;
  } 
}  
print_r(json_encode(array('status'=>$errorStatusCode)));
}

   /**
   * Function to save middle category data.
   * 
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Created On : 03-May-2019
   *
   * @param null 
   * @return status array
   */
   public function adminMiddleSaveCategoryData()
   {
    $responseArray = array('status'=>0,'catName'=>'','catId'=>'');
    if(is_admin_login() && Request::isMethod('post') && Session::token() == Input::get('_token')) 
    {
      // function error/success status code. 
      $errorStatusCode = 0;

      // Getting all input data
      $postData = Input::all();

      
      $middleCategoryName = (isset($postData['middleCategoryName']))? $postData['middleCategoryName'] : '';
      $callType = (isset($postData['callType']))? $postData['callType'] : '';
      $middleCategoryId = (isset($postData['middleCategoryId']) && is_numeric($postData['middleCategoryId']))?  $postData['middleCategoryId']: 0;
      $parentCategoryId = (isset($postData['parentCategoryId']) && is_numeric($postData['parentCategoryId']))?  $postData['parentCategoryId']: 0;
      $postionCount = (isset($postData['postionCount']) && is_numeric($postData['postionCount']))?  $postData['postionCount']: 0;
      
      // Getting category charge price data.
      $categoryType = (isset($postData['categoryType']))? $postData['categoryType'] : '';
      $categoryChargePriceType = (isset($postData['categoryChargePriceType']))? $postData['categoryChargePriceType'] : 'fixed';
      $categoryChargePriceValue = (isset($postData['categoryChargePriceValue']) && is_numeric($postData['categoryChargePriceValue']))? $postData['categoryChargePriceValue'] : 0;

      // Validate required fields
      if(strlen($middleCategoryName) > 0 && $parentCategoryId > 0 && ($callType=='add' || ($callType=='edit' && $middleCategoryId >0)))
      {
        $post_author_id = 0;
        if(Session::has('shopist_admin_user_id') && is_numeric(Session::get('shopist_admin_user_id'))
      ){
          $post_author_id = Session::get('shopist_admin_user_id');
      }

      if ($categoryType == 'middle' && $callType=='add')
      {
        $middleCategoryData = $this->products->getCategoriesByParentCatId($parentCategoryId);
        if (isset($middleCategoryData) && count($middleCategoryData) >=8)
        {
          $responseArray = array('status'=>4,'catName'=>'','catId'=>'');
          print_r(json_encode($responseArray));
          exit;
        }
      }
        // Query to check duplicate category name if already exists.
      $duplicateCategoryCount = DB::table('terms')
      ->where(['name' => $middleCategoryName,'parent' => $parentCategoryId, 'type' => 'product_cat', 'status' => '1', 'author_id' => $post_author_id ])
      ->where('term_id', '!=',$middleCategoryId)
      ->select('term_id')        
      ->count();

        // Duplicate category not exist.
      if ($duplicateCategoryCount == 0)
      {
          // Create and validate Category Slug url on modify category name.
        $middleCategoryNameSlug = string_slug_format($middleCategoryName,'category');
        $checkMiddleCategoryNameSlugCount  =  DB::table('terms')->where('term_id', '!=', $middleCategoryId)
        ->where(function ($query) use ($middleCategoryNameSlug) {
          $query->where('slug', '=', $middleCategoryNameSlug)
          ->orWhere('slug', 'like', '%'.$middleCategoryNameSlug.'%');
        })->get()->count();

        if($checkMiddleCategoryNameSlugCount > 0)
        {
          $checkMiddleCategoryNameSlugCount = $checkMiddleCategoryNameSlugCount + 1;
          $middleCategoryNameSlug = $middleCategoryNameSlug. '-' . $checkMiddleCategoryNameSlugCount;
        } 

          // for adding data
        if ($callType=='add')
        {
         $insertFields = [
          'name' => $middleCategoryName, 
          'slug' => $middleCategoryNameSlug, 
          'type' => 'product_cat', 
          'parent' => $parentCategoryId, 
          'author_id' => $post_author_id, 
          'created_at' => date('Y-m-d h:i:s'), 
          'display_status' => 'all', 
          'status' => '1', 
          'intPosition' => $postionCount
        ];

        if ($categoryType == 'small')
        {
          $insertFields = [
            'name' => $middleCategoryName, 
            'slug' => $middleCategoryNameSlug, 
            'type' => 'product_cat', 
            'parent' => $parentCategoryId, 
            'author_id' => $post_author_id, 
            'created_at' => date('Y-m-d h:i:s'), 
            'display_status' => 'all', 
            'status' => '1', 
            'category_price_type' => $categoryChargePriceType, 
            'category_price' => $categoryChargePriceValue, 
            'intPosition' => $postionCount
          ];
        } 

            // Query to insert category data.
        $lastInsertCategoryId = DB::table('terms')->insertGetId($insertFields);
        $errorStatusCode = 1;
        $middleCategoryId= $lastInsertCategoryId;
      } else if ($callType=='edit')
      {
            // Query to update middle category data
        $updateCategoryStatus = DB::table('terms')
        ->where(['term_id' => $middleCategoryId, 'type' => 'product_cat', 'status' => '1', 'author_id' => $post_author_id , 'parent' => $parentCategoryId])
        ->update(['name' => $middleCategoryName,'slug' => $middleCategoryNameSlug,'category_price_type' => $categoryChargePriceType,'category_price' => $categoryChargePriceValue,'updated_at' => date('Y-m-d h:i:s')]);

        $errorStatusCode = 1;
      }

      if ($categoryType == 'small' && ($callType=='add' || $callType=='edit'))
      {
        $responseArray = array('status'=>$errorStatusCode,'catName'=>$middleCategoryName,'catId'=>$middleCategoryId,'chargeType'=>$categoryChargePriceType,'charge'=>$categoryChargePriceValue);
      } else
      {
       $responseArray = array('status'=>$errorStatusCode,'catName'=>$middleCategoryName,'catId'=>$middleCategoryId);
     }
          //print_r(DB::getQueryLog());
   } else
   {
          //Duplicate category name exist.
    $errorStatusCode = 2;
    if ($categoryType == 'small' && ($callType=='add' || $callType=='edit'))
    {
      $responseArray = array('status'=>$errorStatusCode,'catName'=>'','catId'=>'','chargeType'=>'','charge'=>'');
    } else
    {
     $responseArray = array('status'=>$errorStatusCode,'catName'=>'','catId'=>'');
   }
 }      
} 
}  

print_r(json_encode($responseArray));
} 

   /**
   * Function to delete middle category data.
   * 
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Created On : 03-May-2019
   *
   * @param null 
   * @return status array
   */
   public function adminDeleteMiddleCategoryData()
   {
    $errorStatusCode=0;  $middleCategoryId = ''; 
    if(is_admin_login() && Request::isMethod('post') && Session::token() == Input::get('_token')) 
    {
      // function error/success status code. 
      $errorStatusCode = 0;

      // Getting all input data
      $postData = Input::all();

      $callType = (isset($postData['callType']))? $postData['callType'] : '';
      $middleCategoryId = (isset($postData['middleCategoryId']) && is_numeric($postData['middleCategoryId']))?  $postData['middleCategoryId']: 0;
      $parentCategoryId = (isset($postData['parentCategoryId']) && is_numeric($postData['parentCategoryId']))?  $postData['parentCategoryId']: 0;

      // Validate required fields
      if($parentCategoryId > 0 && $callType=='delete' && $middleCategoryId >0)
      {
        $allCategories =  $this->products->get_categories($middleCategoryId, 'product_cat');
        $allCategoriesSimpleFormate =  $this->products->createCategoriesSimpleList($allCategories);
        
        $catIdsArray = array($middleCategoryId);
        if (isset($allCategoriesSimpleFormate) && count($allCategoriesSimpleFormate) > 0)
        {
          foreach ($allCategoriesSimpleFormate as $row) 
          {
            $catIdsArray[] = (isset($row['id']))?$row['id']:0;
          }
        }

        // Query to check and validate all categories if any product is added or not for same.
        $checkProductDataForAllCategoryCount = DB::table('object_relationships as O')->join('products as P',function($join){
          $join->on("P.id","=","O.object_id")->where('P.status', '1');
        })->whereIn('O.term_id', $catIdsArray)->select('O.object_id')->get()->count();


        // If no product data found for same, do this.
        if ($checkProductDataForAllCategoryCount == 0) 
        {
          $post_author_id = 0;
          if(Session::has('shopist_admin_user_id') && is_numeric(Session::get('shopist_admin_user_id'))
        ){
            $post_author_id = Session::get('shopist_admin_user_id');
        }

          // Query to delete category data from terms table.
        $deleteCategoryData = DB::table('terms')
        ->whereIn('term_id', $catIdsArray)
        ->where(
          [
            'type' => 'product_cat', 
            'status' => '1', 
            'author_id' => $post_author_id, 
          ]
        )->update(['status' => '0']);
              //)->delete();

        $errorStatusCode = 1;   
      } else 
      {
          // Sorry, you can not delete this category, some product already added in this category.
       $errorStatusCode = 3;   
     }
   } 
 }  
 print_r(json_encode(array('status'=>$errorStatusCode, 'catId'=>$middleCategoryId)));
}

  /**
   * Function to load and manage PMG Store Products Page.
   * 
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Created On : 08-May-2019
   *
   */
  public function pmgStoreManagement()
  {
     // Display page to pmg master admin only.
   if(is_admin_login())
   {
    $data = array();
    $common_obj  = new CommonFunction();
    $data = $common_obj->commonDataForAllPages();

    $post_author_id = 0;
    if(Session::has('shopist_admin_user_id') && is_numeric(Session::get('shopist_admin_user_id'))
  ){
      $post_author_id = Session::get('shopist_admin_user_id');
  }

        // Calling this function to get only PMG store products.
  $data['pmgStoreProducts'] = $this->products->pmgStoreProducts();

        // Getting columns from array.
  $ids = array_column($data['pmgStoreProducts'], 'id');

        // Calling this function to get all active and in stock products of PMG master admin.
  $allProductsPMGMaster = $this->products->getProductListViewPageData(false, null, 1, $post_author_id,0,'all','all','pmgstore',$ids);

        /*$finalProductsDisplay = array();
        if (count($allProductsPMGMaster) > 0) 
        {
          foreach ($allProductsPMGMaster as $row) 
          {
            $saleModeStatus = $this->products->check_sale_mode($row->id);
             
            if ($saleModeStatus)
            {
              if(is_frontend_user_logged_in())
              {
                $frontend_user_data = get_current_frontend_user_info();
                $dob =  new \DateTime($frontend_user_data['dob']);
                $now =  new \DateTime();

                //Calculate the time difference between the two dates.
                $difference = $now->diff($dob);
                     
                //Get the difference in years, as we are looking for the user's age.
                $age = $difference->y;
                 
                if($age >= 19 || ($age < 19 && $row->available_for_minors == "Y"))
                {
                  $finalProductsDisplay[] = $row;
                }
              } else
              {
                $finalProductsDisplay[] = $row;
              }
            }
          }
        }*/  

        $data['allProductsPMGMaster']  = $allProductsPMGMaster;
        return view('pages.admin.system_setting.pmg_store_mgmt', $data);
      } else
      {
        return redirect()-> back();
      }
    }


  /**
   * Function to save PMG Store Product ordering data.
   * 
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Created On : 08-May-2019
   *
   * @param null 
   * @return status
   */
  public function adminSavePMGStoreProductOrderingData()
  {
    $errorStatusCode=0;  
    if(is_admin_login() && Request::isMethod('post') && Session::token() == Input::get('_token')) 
    {
      $post_author_id = 0;
      if(Session::has('shopist_admin_user_id') && is_numeric(Session::get('shopist_admin_user_id'))
      ){
          $post_author_id = Session::get('shopist_admin_user_id');
      }

        // function error/success status code. 
      $errorStatusCode = 0;

        // Getting all input data
      $postData = Input::all();

      $productOrder = (!empty($postData['productOrder']))? explode(",", $postData['productOrder']) : array();

      $where = ['author_id' => $post_author_id];

        // Validate required fields
      if(count($productOrder) >0)
      {
        foreach ($productOrder as $key => $value) 
        { 
            // Query to update category order data.
          $updateCategoryOrder = DB::table('pmgstore_products')
          ->where('product_id', $value)
          ->where($where)
          ->update(['intPosition' => $key,'updated_at' => date('Y-m-d h:i:s')]); 
        }

        $errorStatusCode = 1;
      } 
    }  
    print_r(json_encode(array('status'=>$errorStatusCode)));
  }


  /**
   * Function to export User list in excel formate on user account management view page.
   * 
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Created On : 13-May-2019
   *
   * @param null 
   * @return view page
   */
  public function exportUserListData()
  {
    // Validte required data.
    if(is_admin_login() && Request::isMethod('post') && Session::token() == Input::get('_token')) 
    {
      
      $common_obj  = new CommonFunction();
      $data = $common_obj->commonDataForAllPages();

      $searchTerm = '';
      if(isset($_POST['d_searchTerm']) && $_POST['d_searchTerm'] != '')
      {
        $searchTerm = $_POST['d_searchTerm'];
      }
  
      $perPage=(isset($_POST['d_perPage']))?$_POST['d_perPage']:10;
 
 
      // Calling this function to get list of all buyer user data.
      $buyerUserList = $this->user->getAllUserListData(false, $searchTerm, -1, 'buyer', 'name', $perPage,'export');
      $data = array();  
      if(count($buyerUserList)>0)
      {  
        $tempCount = 0;
        foreach($buyerUserList as $list)
        {

          if (isset($list->id) && is_numeric($list->id)) 
          {
            $row['품번']=++$tempCount;
            $row['이름']=$list->display_name;
            $row['계정']=$list->name;
            $row['이메일']=$list->email;

            $createdAtDate = '';
            if ($list->created_at !='' && $list->created_at !='0000-00-00 00:00:00'){
              $createdAtDate = date('Y.m.d',strtotime($list->created_at));
            }
            $row['가입일']=$createdAtDate;

            $points = (isset($list->my_wallet) && $list->my_wallet != '')?$list->my_wallet:0;
            $row['포인트']=$points;

            $gender ='';
            if(!empty($list->gender))
            {
              $gender = Lang::get('frontend.signup_form_gender_'.$list->gender);
               
            }
            $row['성']=$gender;

            $userStatus = (isset($list->user_status) && $list->user_status == 1)?trans('admin.user_status_active'):trans('admin.user_status_suspended');
            $row['상태']=$userStatus;

            $userType= (isset($list->slug) && $list->slug =='site-user')?'구매자':'';
            $row['유형']=$userType;

            array_push($data, $row);
          } 
        }
      } 

      $filename = '사용자 목록 내보내기 - '.date('Y.m.d h:i:s').'-'.mt_rand();
      // Generate and return the spreadsheet
      return Excel::create($filename, function($excel) use ($data) {

        $excel->sheet('사용자 목록 내보내기', function($sheet) use ($data)
        {
          $sheet->fromArray($data, null, 'A1', true);

        });
      })->download('xls'); 
    }
  }


  /**
   * Function to add/delete PMG Store Products.
   * 
   * Created By : Deepak Goswami < deepak.goswami0143@gmail.com >
   * Created On : 08-May-2019
   * LastUpdated On : 09-May-2019
   *
   */
  public function pmgStoreAddDeleteProduct()
  {
    $errorStatusCode=0;  
    if(is_admin_login() && Request::isMethod('post') && Session::token() == Input::get('_token')) 
    {
      $post_author_id = 0;
      if(Session::has('shopist_admin_user_id') && is_numeric(Session::get('shopist_admin_user_id'))
    ){
        $post_author_id = Session::get('shopist_admin_user_id');
    }
      // Getting all input data
    $postData = Input::all();

    $productId = (isset($postData['pid']) && is_numeric($postData['pid']))? $postData['pid'] : 0;
    $selectedProducts = (isset($postData['selectedProducts']))? $postData['selectedProducts'] : '';
    $callType = (isset($postData['callType']))? $postData['callType'] : '';
    $selectedProducts = explode(",", $selectedProducts);

      // Add new products to PMG Store.
    if ($callType =='add' && count($selectedProducts)> 0) 
    {
      $position = (isset($postData['position']) && is_numeric($postData['position']))? $postData['position'] : 0;
      $data = array();
      foreach($selectedProducts as $pid)
      {
        if(!empty($pid))
        {

          $data[] =[
            'product_id' => $pid,
            'author_id' => $post_author_id,
            'intPosition' => $position,
            'created_at' => date('Y-m-d h:i:s')
          ]; 
          $position++;
        }
      } 

        // Query to insert data into pmgstore_products table.
      $errorStatusCode = DB::table('pmgstore_products')->insert($data);

    } else if ($callType =='delete' && $productId > 0 && $post_author_id > 0) 
    {
          // Query to delete PMG Store Products data from terms table.
      $deleteCategoryData = DB::table('pmgstore_products')
      ->where(
        [
          'product_id' => $productId, 
          'author_id' => $post_author_id, 
        ]
      )->delete();

      $errorStatusCode = 1; 
    }
  }

  print_r(json_encode(array('status'=>$errorStatusCode)));
}

 /**
   * Function to Get Coupon List.
   * 
   * Created By : Ayushma jain < ayushma.jain@gaurish.com >
   * Created On : 03-May-2019
   *
   * @param null 
   * @return status array
   */
 public function getCouponList($user_id = 0){
   $vendorType = DB::table('users')->where(['id'=>$user_id])->select('vendor_type')->get()->toArray();
   $getCouponCondition = ['all','select_seller'];
   $couponArrayList = array();
   if(isset($vendorType[0]->vendor_type) && $vendorType[0]->vendor_type == 'business'){
    array_push($getCouponCondition,'all_business');
  }
  if(isset($vendorType[0]->vendor_type) && $vendorType[0]->vendor_type == 'single'){
   array_push($getCouponCondition,'all_personal');
 }

 $current_date = date('Y-m-d');

 $getUsedCoupons = DB::table('coupon_used')->where(['user_id' =>$user_id] )->select(DB::raw('group_concat(coupon_id) as coupon_id'))->get()->toArray();

 $usedCoupon = array();
 if(isset($getUsedCoupons[0]->coupon_id))
 {
  $usedCoupon = explode(',',$getUsedCoupons[0]->coupon_id);
}


$getCoupons = DB::table('coupon')
->whereIn('issue_target',$getCouponCondition)
->where('start_date','<=',$current_date)
->where('end_date','>=',$current_date)
->whereNOTIn('id',$usedCoupon)->get()->toArray();

foreach($getCoupons as $coupon){
  if($coupon->issue_target == 'select_seller'){
   $selected_seller = json_decode($coupon->selected_user);
   if(count($selected_seller)>0){
    foreach($selected_seller as $seller){
     if($seller->id == $user_id){
      array_push($couponArrayList,$coupon);
    }
  }
}
}else{
  array_push($couponArrayList,$coupon);
}
}

return $couponArrayList;
}


public function generateSettlement()
{

  $end_date=date('Y-m-d');
  $start_date=date('Y-m-d',strtotime('-7 days'));
  $categories_fee = $this->getAllCategoryFee();

				//select all vendor's order from 
  $order_data = DB::table('order_detail')->where(['seller_id'=>Session::get('shopist_admin_user_id')])->where('created_at','>=',$start_date)->where('created_at','<=',$end_date)->select('order_detail.*',DB::raw('DATE(created_at) as dated'))->ORDERBY('created_at','DESC')->get()->toArray();
  $data =array();

  if(count($order_data)>0)
  {
   foreach($order_data as $order)
   {
    if(!isset($data[$order->dated]))
    {
     $data[$order->dated]=array();
     $data[$order->dated]['points']=0;
     $data[$order->dated]['sales']=0;
     $data[$order->dated]['qty']=0;
     $data[$order->dated]['fee']=0;
   }
   $total_fee = 0;

						//Get product category id
   $is_term_object_exist = ObjectRelationship::where('object_id', $order->product_id)->where('terms.type', 'product_cat')->join('terms',function($join){
     $join->on("terms.term_id","=","object_relationships.term_id");
   })->select('terms.term_id', 'terms.parent')->get();
   if(count($is_term_object_exist)>0)
   {
     $last_updated_term_id = isset($is_term_object_exist[0]->term_id) ? $is_term_object_exist[0]->term_id : 0;
     $parentID= isset($is_term_object_exist[0]->parent) ? $is_term_object_exist[0]->parent: 0;
   }

						//echo $last_updated_term_id." ".$parentID;
   if(isset($categories_fee[$last_updated_term_id]))
   {


     if($categories_fee[$last_updated_term_id]->category_price_type=='fixed')
     {
      $total_fee = $categories_fee[$last_updated_term_id]->category_price;
    }
    else
    {
      $total_fee = round(($total_supply_value*$categories_fee[$last_updated_term_id]->category_price)/100); 
    }
  }
  if(isset($categories_fee[$parentID]))
  {
   if($categories_fee[$parentID]->category_price_type=='fixed')
   {
    $total_fee = $categories_fee[$parentID]->category_price;
  }
  else
  {
    $total_fee = round(($total_supply_value*$categories_fee[$parentID]->category_price)/100); 
  }
}
$produtc_details = json_decode($order->product_detail);
$order_qty = isset($produtc_details->order_qty) ? $produtc_details->order_qty :0;

$data[$order->dated]['points']=$data[$order->dated]['points']+$order->pointGain;
$data[$order->dated]['sales']=$data[$order->dated]['sales']+$order->total_pay_amt;
$data[$order->dated]['qty']=$data[$order->dated]['qty']+$order_qty;
$data[$order->dated]['fee']=$data[$order->dated]['fee']+$total_fee;
}
}

return $data;

}

public function getAllCategoryFee()
{
  $category=array();
		//Get all category charges
  $result = DB::table('terms')->where('category_price','>',0)->select('term_id','category_price_type','category_price')->get()->toArray();
  if(count($result)>0)
  {
   foreach($result as $row)
   {
    $category[$row->term_id]=$row;
  }
}

return $category;
}
	/**
   * Function to Get Total Blank Ads Count.
   * 
   * Created By : Ayushma jain < ayushma.jain@gaurish.com >
   * Created On : 14-May-2019
   *
   */
	public function getTotalBlankAdsCount(){
		$total_ad_request = DB::table('adv_request')->where('status','!=','Expired')->count();
		$total_ads = DB::table('advertisement')->where('id','!=',7)->sum('maximum_ads');
		$total_category_ads = DB::table('advertisement')->where('id','=',7)->select('maximum_ads')->first();
		$total_category_ads = isset($total_category_ads->maximum_ads) ? (int)$total_category_ads->maximum_ads : 0;
		
		$total_admin_ads = (int)$total_ads + (13 * $total_category_ads);
		$total_blank_ads = $total_admin_ads - (int)$total_ad_request;
		return $total_blank_ads;
	}
	public function partnerSettlement($type)
	{
		$per_page = isset($_GET['per_page'])? $_GET['per_page'] : 10;
		$common_obj  = new CommonFunction();
		$data = $common_obj->commonDataForAllPages();
		$settlement_list  = DB::table('settlement')->join('users','users.id','=','settlement.seller_id')->where(['settlement_status' => $type])->select('settlement.*','users.display_name','users.vendor_type')->paginate($per_page)->toArray();
		$data['settlement_list']=$settlement_list;
		$data['type']=$type;
		$data['per_page']=$per_page;
		return view('pages.admin.settlement.partner-settlement-page', $data);
	}
	
	/**
   * Function to get PMG Profit loss Mgmt page.
   * 
   * Created By : Ayushma jain < ayushma.jain@gaurish.com >
   * Created On : 14-May-2019
   *
   */
	public function pmgAccountingMgmt(){
		$data = array();
		$common_obj  = new CommonFunction();
		$data = $common_obj->commonDataForAllPages();
		
		
		return view('pages.admin.pmg_account_mgmt.pmg-profit-loss-mgmt', $data);
	}
	
	
	/**
   * Function to get Partner Inquiry page Content.
   * 
   * Created By : Ayushma jain < ayushma.jain@gaurish.com >
   * Created On : 22-May-2019
   *
   */
	public function partnerInquiry(){
		$data = array();
		$common_obj  = new CommonFunction();
		$data = $common_obj->commonDataForAllPages();
		$filterType = isset($_GET['filterType']) ? $_GET['filterType'] : 'Reviews';
		$searchVal = isset($_GET['searchVal']) ? $_GET['searchVal'] : '';
		$searchSellers = array();
		if(!empty($searchVal)){
			
			$searchSellers  = DB::table('users')->where('users.vendor_type','!=',NULL)
								->where(function ($query) use ($searchVal) {
									$query->where('users.name', 'LIKE', '%'. $searchVal .'%')
								   ->orwhere('users.contact_number', 'like', '%' . $searchVal . '%')
								   ->orWhere('users.email', 'like', '%' . $searchVal . '%');
								})
								   
							   ->join('users_details','users_details.user_id','=','users.id')
							   ->select('users.*','users_details.details')->get()->toArray();
							 
		}
		if($filterType == 'ads'){
			
			$sellerList = DB::table('users')->where('vendor_type','!=',NULL)
							->leftjoin('adv_request','adv_request.seller_id','=','users.id')
							->select('users.id','users.display_name',DB::raw("count('*') as rowCount"))
							->groupby('id')->limit(100)->ORDERBY('rowCount','DESC')->get()->toArray();
		}else if($filterType == 'sales'){
			
			$sellerList = DB::table('users')->where('vendor_type','!=',NULL)
							->leftjoin('order_detail','order_detail.seller_id','=','users.id')
							->select('users.id','users.display_name',DB::raw("SUM(total_pay_amt) as total"))
							->groupby('id')->limit(100)->ORDERBY('total','DESC')->get()->toArray();
						
		}else{
			
			$sellerList = DB::table('users')->where('vendor_type','!=',NULL)
							->leftjoin('comments','comments.seller_id','=','users.id')
							->select('users.id','users.display_name',DB::raw('sum(comments.rating)/count(comments.object_id) as average'))
							->groupby('id')->limit(100)->ORDERBY('average','DESC')->get()->toArray();
							
		}
		
		$data['sellerList'] = $sellerList;
		$data['filterType'] = $filterType;
		$data['searchVal']  = $searchVal;
		$data['searchSellers']  = $searchSellers;
		return view('pages.admin.partner_mgmt.partner-inquiry', $data);
	}
	
}